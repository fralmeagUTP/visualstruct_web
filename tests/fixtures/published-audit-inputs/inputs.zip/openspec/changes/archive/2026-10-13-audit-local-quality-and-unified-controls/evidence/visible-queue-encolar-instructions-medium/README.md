# Encolar MEDIUM: evidencia finita actual

Proyecto canónico D:\MisProyectos\Web_VisualEstruct. Nuevo motor cola_encolar, sesión preparada exclusiva y renderer para ambas vistas. C/H intactos. Baseline histórico19pass14fail/133 artefactos conservado; fuente original de tests archivada en original/. Los33IDs originales siguen presentes y verdes;3nuevosIDs de sesión,36pass0fail0xfail.

QA propia: tests/_audit_queue_encolar_medium.py compara140eventos/35condiciones/14llamadas C conservadas con8APIactuales+6fallosprivados (5mallocNULL,1qNULL), masks/valor/sgte/roots/aux/console/return. C no reejecutado: native-reuse.json prueba bytesidénticos. report.json/40observaciones0divergencias. Browser-accepted-run.log y browser/report.json:8operaciones2vistas192forward176back4reloadexactos;Siguiente real tras recargar,0POSTextra/0JSerrors/5secciones. Los144/128 antiguos son historia, no se suman.

Caller-reuse.json contrasta bytes de4mainDOMactuales; son idénticos a los originales. C17/12alloc12free0live/12NULLposiciones/Doxygen6inputs0warnings4main documentados son evidencia reutilizada, sin nueva compilación/casos. HTTPqueue/main404 se conserva.

resources.json mide8llamadas actuales: máximo2,173,488bytes picoPython/157,734bytesrespuesta/0.0673815s instrumentado frente658,901/42,055/0.0462116 antiguos. La traza y sesión preparada más detalladas aumentan los tamaños; no implica RSS/Cheap/leak/SLA/OOM ni escala universal. No se ejecutó suite global.

Correcciones observadas duranteQA: primera conexiónrechazada por preview5050,restaurado5051;callbacksselection borraban cursor,usar savedPresentation previo;payloadDOMstring frenteint comparado porvalor;restaurar modo y visibilidad/ARIA de navegación exclusivamenteEncolar. Logs fallidos se conservan. Nueva prueba de invalidación usaba operación inexistentefrente, corregida al catálogorealdesencolar;regressions-first-run.log preservado.

product-before/after/protected-check capturanSHAactuales. Sharedtrace cambia sólohookEncolar;rendererclosedfunctions idénticas;RN/Hash/Sorting/Pila/limpiar ytodosC/Hprotegidos. Manual actualizado sólo conEncolar. SDDlogs/handoffspermisopendiente no tocados. Finito implementado;volverLOW para revisión, sin ampliarbloque/archivo/cierreglobal/Graph/publish.
