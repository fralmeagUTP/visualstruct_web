
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "tad_ordenamiento.h"
static int *root,*counts,minv,maxv,have_min,have_max,case_id,comparisons,moves,allocs,frees;static size_t count,range,wi,hi,output;static int iw,ih,ir,io;
static void emit(const char*t,int condition){
 printf("{\"case\":%d,\"token\":\"%s\",\"condition\":",case_id,t);if(condition<0)printf("null");else printf(condition?"true":"false");printf(",\"array\":[");for(size_t z=0;z<count;z++){if(z)printf(",");printf("%d",root[z]);}printf("],\"minimo\":");if(have_min)printf("%d",minv);else printf("null");printf(",\"maximo\":");if(have_max)printf("%d",maxv);else printf("null");printf(",\"i\":");if(iw)printf("%zu",wi);else printf("null");printf(",\"helper_i\":");if(ih)printf("%zu",hi);else printf("null");printf(",\"rango\":");if(ir)printf("%zu",range);else printf("null");printf(",\"indice\":");if(io)printf("%zu",output);else printf("null");printf(",\"conteo\":");if(counts){printf("[");for(size_t z=0;z<range;z++){if(z)printf(",");printf("%d",counts[z]);}printf("]");}else printf("null");printf(",\"comparisons\":%d,\"moves\":%d,\"allocations\":%d,\"frees\":%d}\n",comparisons,moves,allocs,frees);
}
static int cond(const char*t,int r){if(!strcmp(t,"min_compare")||!strcmp(t,"max_compare"))comparisons++;emit(t,r);return r;}

static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry",-1);
	return cond("valid_ptr",arreglo!=NULL) && cond("valid_n",n>0);
}
static int obtener_minimo_maximo(const int arreglo[], size_t n, int *minimo, int *maximo) {emit("minmax_entry",-1);
	size_t i;emit("helper_i_declare",-1);
	if(cond("minmax_guard",!arreglo_valido(arreglo,n) || minimo==NULL || maximo==NULL))return ORDENAMIENTO_ERROR;
	*minimo=arreglo[0];minv=*minimo;have_min=1;emit("min_init",-1);*maximo=arreglo[0];maxv=*maximo;have_max=1;emit("max_init",-1);
	for(i=1,hi=i,ih=1,emit("scan_init",-1);cond("scan_test",i<n);++i,hi=i,emit("scan_increment",-1)) {
		if(cond("min_compare",arreglo[i]<*minimo)){*minimo=arreglo[i];minv=*minimo;emit("min_assign",-1);}
		if(cond("max_compare",arreglo[i]>*maximo)){*maximo=arreglo[i];maxv=*maximo;emit("max_assign",-1);}
	}
	ih=0;emit("minmax_return",-1);return ORDENAMIENTO_OK;
}
int ordenar_counting_sort(int arreglo[], size_t n) {emit("sort_entry",-1);
	int minimo,maximo;size_t rango,i,indice;int *conteo;emit("declare",-1);
	emit("valid_call",-1);if(cond("sort_guard",!arreglo_valido(arreglo,n)))return ORDENAMIENTO_ERROR;
	emit("minmax_call",-1);if(cond("minmax_status",!obtener_minimo_maximo(arreglo,n,&minimo,&maximo)))return ORDENAMIENTO_ERROR;
	rango=(size_t)((long long)maximo-(long long)minimo+1LL);range=rango;ir=1;emit("range_compute",-1);
	if(cond("range_guard",cond("range_limit",rango>ORDENAMIENTO_RANGO_MAX) || cond("size_guard",rango>SIZE_MAX/sizeof(int))))return ORDENAMIENTO_ERROR;
	conteo=(int*)calloc(rango,sizeof(int));counts=conteo;if(conteo)allocs++;emit("count_init",-1);
	if(cond("allocation_guard",conteo==NULL))return ORDENAMIENTO_ERROR;
	for(i=0,wi=i,iw=1,emit("fill_init",-1);cond("fill_test",i<n);++i,wi=i,emit("fill_increment",-1)){++conteo[arreglo[i]-minimo];moves++;emit("count_fill",-1);}
	indice=0;output=indice;io=1;emit("output_init",-1);
	for(i=0,wi=i,emit("rebuild_init",-1);cond("rebuild_test",i<rango);++i,wi=i,emit("rebuild_increment",-1))
		while(cond("bucket_test",conteo[i]>0)){arreglo[indice++]=(int)i+minimo;output=indice;moves++;emit("array_write",-1);--conteo[i];moves++;emit("count_write",-1);}
	free(conteo);counts=NULL;frees++;emit("count_free",-1);
	iw=ir=io=have_min=have_max=0;emit("sort_return",-1);return ORDENAMIENTO_OK;
}
int main(void){
{int a[]={7};root=a;count=sizeof(a)/sizeof(a[0]);case_id=0;counts=NULL;have_min=have_max=iw=ih=ir=io=comparisons=moves=allocs=frees=0;emit("initial",-1);if(ordenar_counting_sort(a,count)!=ORDENAMIENTO_OK)return 2;}
{int a[]={1,2,3,4};root=a;count=sizeof(a)/sizeof(a[0]);case_id=1;counts=NULL;have_min=have_max=iw=ih=ir=io=comparisons=moves=allocs=frees=0;emit("initial",-1);if(ordenar_counting_sort(a,count)!=ORDENAMIENTO_OK)return 2;}
{int a[]={4,3,2,1};root=a;count=sizeof(a)/sizeof(a[0]);case_id=2;counts=NULL;have_min=have_max=iw=ih=ir=io=comparisons=moves=allocs=frees=0;emit("initial",-1);if(ordenar_counting_sort(a,count)!=ORDENAMIENTO_OK)return 2;}
{int a[]={2,2,2};root=a;count=sizeof(a)/sizeof(a[0]);case_id=3;counts=NULL;have_min=have_max=iw=ih=ir=io=comparisons=moves=allocs=frees=0;emit("initial",-1);if(ordenar_counting_sort(a,count)!=ORDENAMIENTO_OK)return 2;}
{int a[]={-3,0,-1,0};root=a;count=sizeof(a)/sizeof(a[0]);case_id=4;counts=NULL;have_min=have_max=iw=ih=ir=io=comparisons=moves=allocs=frees=0;emit("initial",-1);if(ordenar_counting_sort(a,count)!=ORDENAMIENTO_OK)return 2;}
{int a[]={-2147483647,-2147483648};root=a;count=sizeof(a)/sizeof(a[0]);case_id=5;counts=NULL;have_min=have_max=iw=ih=ir=io=comparisons=moves=allocs=frees=0;emit("initial",-1);if(ordenar_counting_sort(a,count)!=ORDENAMIENTO_OK)return 2;}
return 0;}
