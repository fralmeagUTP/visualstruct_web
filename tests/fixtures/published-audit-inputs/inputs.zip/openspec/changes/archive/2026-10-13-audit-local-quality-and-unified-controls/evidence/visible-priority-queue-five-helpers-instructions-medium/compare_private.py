"""Compare typed private helper boundaries to independently executed native hooks."""
from pathlib import Path
import json,time,tracemalloc,sys
sys.path.insert(0,str(Path.cwd()))
from app.domain.sequential.priority_queue_helpers_instruction import build_priority_helper_trace
from app.services.c_code_service import CCodeService
R=Path.cwd();E=R/'openspec/changes/audit-local-quality-and-unified-controls/evidence/visible-priority-queue-five-helpers-instructions-medium';L=E.parent/'visible-priority-queue-five-helpers-baseline-low'
def save(name,d):(E/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def make_trace(row):
 cfg=row['fixture'];items=[{'value':v,'priority':p} for v,p in cfg['nodes']];mode=cfg['mode'];count=cfg['count'];method=row['method'];op=method.removeprefix('cp_')
 state={'kind':'priority','title':'Cola de prioridad (orden de llegada)','items':items,'size':count,'empty':not items,'out_index':-1}
 heap=[{'id':f'N{i+1}','type':'CPNodo','alive':True,'allocated':True,'freed':False,'status':'borrowed','initialized_mask':7,'fields_valid':True,'field_validity':{'valor':True,'prioridad':True,'sgte':True},'fields':{'valor':x['value'],'prioridad':x['priority'],'sgte':f'N{i+2}' if i+1<len(items) else None}} for i,x in enumerate(items)]
 memory={'nodes':heap,'fields':{'delante':heap[0]['id'] if heap and mode!=3 else None,'atras':heap[-1]['id'] if heap and mode!=2 else None,'cantidad':count},'initialized_mask':0 if mode==4 else 7}
 payload={'capacity':cfg['capacity'],'null_cola':mode==1,'null_valores':cfg['NULL_values_or_dest'] if op=='copiar_items' else False,'null_prioridades':cfg['NULL_priorities'],'null_destino':cfg['NULL_values_or_dest'] if op=='formatear' else False,'caller_values':[123456]*6,'caller_priorities':[654321]*6,'caller_bytes':[90]*130}
 source=CCodeService._build_priority_queue_data()['operations'][op]
 return build_priority_helper_trace(operation_name=op,payload=payload,source_code=source,code_title='Codigo C',before_state=state,after_state=state,success=True,message='Private helper fixture',borrowed_memory=memory)
def normalized(step):
 m=step['pedagogy']['helper_memory'];local=m['locals'];helper=m['helper_locals'];root=m['root'];o=m['outputs'];condition=step['pedagogy']['condition']
 node_id=lambda n:-1 if n is None else int(n.removeprefix('N'))-1
 return {'function':step['function_name'],'event':step['event_type'],'condition':step['condition_result'],'operands':[] if condition is None else condition['evaluated_operands'],'root':{'mask':root['initialized_mask'],'front':node_id(root['fields']['delante']),'rear':node_id(root['fields']['atras']),'count':root['fields']['cantidad']},'scope':m['scope']=='active','helper_scope':m['helper_scope']=='active','aux_initialized':local.get('aux',{}).get('initialized',False),'aux':node_id(local.get('aux',{}).get('value')),'count_initialized':local.get('usados',{}).get('initialized',False),'count':local.get('usados',{}).get('value'),'used_initialized':local.get('usado',{}).get('initialized',False),'used':local.get('usado',{}).get('value'),'args_live':helper.get('args',{}).get('valid',False),'escritos_initialized':helper.get('escritos',{}).get('initialized',False),'escritos':helper.get('escritos',{}).get('value'),'result':m['result'],'values':o['values'],'priorities':o['priorities'],'bytes':o['bytes'],'values_written':o['values_written'],'priorities_written':o['priorities_written'],'bytes_written':o['bytes_written']}
def compare(row,trace,inventory):
 events=[json.loads(x) for x in (R/inventory['events_path']).read_text().splitlines()];actual=[normalized(x) for x in trace['steps']]
 expected=[{k:v for k,v in x.items() if k!='C_line'} for x in events]
 assert len(actual)==len(expected),(row['ID'],len(actual),len(expected))
 for i,(a,n) in enumerate(zip(actual,expected)):
  assert a==n,(row['ID'],i,{k:[a[k],n[k]] for k in a if a[k]!=n[k]})
  step=trace['steps'][i];assert step['line_text']==trace['source_code'].splitlines()[step['line_index']]
  # Hook source location must be an exact original target/helper executable line.
  c_lines=(E/'tad_cola_prioridad.c').read_text(encoding='utf-8-sig').splitlines();assert step['line_text'].strip()==c_lines[events[i]['C_line']-1].strip(),(row['ID'],i,step['line_text'],c_lines[events[i]['C_line']-1])
  assert step['console']==[] and step['pedagogy']['heap_transition']['before']==step['pedagogy']['heap_transition']['after']
  assert step['pedagogy']['helper_memory']['allocations']==step['pedagogy']['helper_memory']['frees']==0
 return len(events),sum(x['condition'] is not None for x in events)
if __name__=='__main__':
 rows=json.loads((L/'report.json').read_text());inventory=json.loads((E/'native-event-inventory.json').read_text());results=[];resources=[];traces=E/'private-traces';traces.mkdir(exist_ok=True)
 for i,(row,inv) in enumerate(zip(rows,inventory)):
  tracemalloc.start();start=time.perf_counter();trace=make_trace(row);elapsed=time.perf_counter()-start;_,peak=tracemalloc.get_traced_memory();tracemalloc.stop();serialized=json.dumps(trace,ensure_ascii=False);count,guards=compare(row,trace,inv);(traces/('%03d.json'%i)).write_text(serialized,encoding='utf-8');results.append({'ID':row['ID'],'method':row['method'],'events':count,'conditions':guards,'divergences':0});resources.append({'ID':row['ID'],'method':row['method'],'seconds':elapsed,'Python_tracemalloc_peak_bytes':peak,'JSON_UTF8_bytes':len(serialized.encode('utf-8'))})
 save('private-native-comparison.json',results);save('resources.json',{'samples':resources,'limits':'148 finite private builders+source extraction+serialization; no accepted HTTPsession, RSS/browser memory/unbounded queue/OOM/SLA guarantee'});print('Typed148fixture comparison',sum(x['events'] for x in results),'events',sum(x['conditions'] for x in results),'conditions; zero divergence')
