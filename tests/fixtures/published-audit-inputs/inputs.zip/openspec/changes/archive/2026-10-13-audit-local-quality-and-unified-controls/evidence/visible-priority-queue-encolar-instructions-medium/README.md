# Prioridad Encolar MEDIUM: implementación finita actual

Nuevo motor cp_encolar/cp_crear_nodo exclusivo, malloc opaco, locals homónimos por scope, mask0→1→3→7, mismo nodo temporal/publicado sinduplicación/freeficticio, roots/cantidad/boolreturn/caller vivos. Nueva sesiónpriority_queue_enqueue_prepared_v1 conhistorydigest+sourcecompatible yrenderer propioincluyendo funciones/contador/locales/dosvistas; restoreinputs/cursor/mode/navigation/selectionkeyreal yNextsinredispatch. Manual actualizado. C/H/algoritmos/main ycierresprevios intactos.

46pass0fail0xfail:42IDsbaseline preservadosuna vez(legacy1)+4sesión. ID-overlap/sourceSHA/originals/regressions actuales guardados. Baseline131artefactos42IDs20/22 permanece inmutable. Legacyselector actualizadoal evento allocator_success_return, conmismaaserciónreserva/temporal/no-publicación, porque el motor ahoraexponeenter/return separados; otrosmétodosdelegacyfile no cambiados. PrimerGETtest nuevo usabarutaCola en vezPriority, falloQA conservado ycorregido; primerdraft motor corrigióbracketcomprehension de scopes antesverification. No testxfail ni declaraciónfakepass.

current-native-compare-run.log/full-event-comparison.json/fault-traces.json:8APIactuales+6privatefaulttraces comparancompleto242events14calls48conditionsC reutilizados. C/HbytesD iguales antesreusar; no nuevaejecuciónC.72obs0divs,consoleC vacía real,mallocNULL/colaNULL sinpublicfaultflag niOOMreal.

Browserprimario8calls2vistas21framesporcall336forward320back,4trace/history/cursor/modeexactreload/Siguientereal0POST/0JSerrors/5secciones. Verifica número de objetos,labelscontador/función,y0is-freed en cadaframe. API-UI-projection.json:8traces tienenmismos21debug/state/source events queAPI. Tras añadir compatibilidaddefuente sóloGET, previewactualizado yQAadicional4reload+Next enmismosfixtures(8setupenqueues)sinrepetirfullviews ni añadirconteos de navegación. Los240/224old15frames yrepeticiones no se suman.

4mainDOMprimarios ycurrent-sourceQA sonidénticos a baseline;caller-reuse.json conservaC17/Dox6inputs0warnings4symbols/12alloc12free0live12controlledNULLexit1sinfalseapplied. No nueva compilación/reescritura/mainendpoint. HTTPmain404, C/H200igualD. Ckernel false/NULL silencioso,cuerpo main reportastderr.

8resourcesfinitemeasured,max4,978,137bytesPythonpeak/367,728bytesJSON/0.1476205s instrumentado; antes979,576/85,753/0.0819748. Incremento cuantificado portraza/sesión detalladas; noRSS/browser/Cheap/universalquantitydepthhistory/OOM/leak/SLA/sanitizer garantía. No suiteglobal.

product228SHA yQAsources6SHA finales contemporáneos. protected-check: sólo routes/trace facade/JS/manualgatespropios más2módulosnuevos; closed renderer functions exactas,C/Htodos yotherproductsunchanged. ManifestfrozenEXCLUYEpreviewstdout/stderrvivos paraevitarstalehashporrequests. After/checkpoint terminaMEDIUM paraLOWreview, nofunctional/globalclosure/archive/ampliaciónfamilia/Graph/SDDblocked/publish.
