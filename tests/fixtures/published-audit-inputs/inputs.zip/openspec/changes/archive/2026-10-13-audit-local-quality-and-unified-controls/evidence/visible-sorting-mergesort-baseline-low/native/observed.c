
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tad_ordenamiento.h"
typedef struct {const char *function;size_t left,right,mid,i,j,k;int has_mid,has_indices;} Frame;
static Frame frames[20];static int depth;
static int *root,*aux;static size_t count;static int initialized[80],live,comparisons,moves,allocs,frees,fixture,fail;
#define F frames[depth-1]
static void emit(const char*t,const char*f,int condition){
 printf("{\"case\":%d,\"event\":{\"token\":\"%s\",\"function\":",fixture,t);
 if(f)printf("\"%s\"",f);else printf("null");
 printf(",\"comparisons\":%d,\"moves\":%d,\"aux_live\":%s,\"allocations\":%d,\"frees\":%d,\"frames\":[",comparisons,moves,live?"true":"false",allocs,frees);
 for(int z=0;z<depth;z++){Frame q=frames[z];if(z)printf(",");printf("{\"function\":\"%s\",\"izquierda\":%zu,\"derecha\":%zu,\"medio\":",q.function,q.left,q.right);if(q.has_mid)printf("%zu",q.mid);else printf("null");printf(",\"i\":");if(q.has_indices)printf("%zu",q.i);else printf("null");printf(",\"j\":");if(q.has_indices)printf("%zu",q.j);else printf("null");printf(",\"k\":");if(q.has_indices)printf("%zu",q.k);else printf("null");printf("}");}
 printf("]},\"condition\":");if(condition<0)printf("null");else printf(condition?"true":"false");
 printf(",\"array\":[");for(size_t z=0;z<count;z++){if(z)printf(",");printf("%d",root[z]);}printf("],\"auxiliary\":[");
 for(size_t z=0;z<count;z++){if(z)printf(",");if(live && initialized[z])printf("%d",aux[z]);else printf("null");}puts("]}");
}
static int cond(const char*t,const char*f,int r){if(!strcmp(t,"merge_compare"))comparisons++;emit(t,f,r);return r;}
static int checked(int r){emit("valid_return","arreglo_valido",-1);return cond("sort_guard","ordenar_mergesort",!r);}
static void push(const char*f,size_t l,size_t r){frames[depth++]=(Frame){.function=f,.left=l,.right=r};}
static void *reserve(size_t n){if(fail)return NULL;void*p=malloc(n);if(p)allocs++;return p;}

static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry","arreglo_valido",-1);
	return cond("valid_ptr","arreglo_valido",arreglo!=NULL) && cond("valid_n","arreglo_valido",n>0);
}
static void mezclar(int arreglo[], int auxiliar[], size_t izquierda, size_t medio, size_t derecha) {push("mezclar",izquierda,derecha);F.mid=medio;F.has_mid=1;emit("merge_entry","mezclar",-1);
	size_t i=izquierda,j=medio+1,k=izquierda;F.i=i;F.j=j;F.k=k;F.has_indices=1;emit("merge_init","mezclar",-1);
	while(cond("merge_while","mezclar",cond("merge_left","mezclar",i<=medio) && cond("merge_right","mezclar",j<=derecha))) {
		if(cond("merge_compare","mezclar",arreglo[i]<=arreglo[j])) {auxiliar[k++] = arreglo[i++];initialized[k-1]=1;moves++;F.i=i;F.k=k;emit("aux_left_write","mezclar",-1);}
		else {auxiliar[k++] = arreglo[j++];initialized[k-1]=1;moves++;F.j=j;F.k=k;emit("aux_right_write","mezclar",-1);}
	}
	while(cond("left_tail_test","mezclar",i<=medio)){auxiliar[k++] = arreglo[i++];initialized[k-1]=1;moves++;F.i=i;F.k=k;emit("left_tail_write","mezclar",-1);}
	while(cond("right_tail_test","mezclar",j<=derecha)){auxiliar[k++] = arreglo[j++];initialized[k-1]=1;moves++;F.j=j;F.k=k;emit("right_tail_write","mezclar",-1);}
	for(i=izquierda,F.i=i,emit("copy_init","mezclar",-1);cond("copy_test","mezclar",i<=derecha);++i,F.i=i,emit("copy_increment","mezclar",-1)){arreglo[i] = auxiliar[i];moves++;emit("copy_write","mezclar",-1);}
emit("merge_body_exit","mezclar",-1);depth--;emit("merge_return","mezclar",-1);}
static void mergesort_recursivo(int arreglo[], int auxiliar[], size_t izquierda, size_t derecha) {push("mergesort_recursivo",izquierda,derecha);emit("rec_entry","mergesort_recursivo",-1);
	if(cond("rec_guard","mergesort_recursivo",izquierda>=derecha)){depth--;emit("rec_return","mergesort_recursivo",-1);return;}
	size_t medio = izquierda + (derecha - izquierda) / 2;F.mid=medio;F.has_mid=1;emit("split","mergesort_recursivo",-1);
	emit("rec_left_call","mergesort_recursivo",-1);mergesort_recursivo(arreglo, auxiliar, izquierda, medio);emit("rec_left_resume","mergesort_recursivo",-1);
	emit("rec_right_call","mergesort_recursivo",-1);mergesort_recursivo(arreglo, auxiliar, medio + 1, derecha);emit("rec_right_resume","mergesort_recursivo",-1);
	emit("merge_call","mergesort_recursivo",-1);mezclar(arreglo, auxiliar, izquierda, medio, derecha);emit("merge_resume","mergesort_recursivo",-1);
emit("rec_body_exit","mergesort_recursivo",-1);depth--;emit("rec_return","mergesort_recursivo",-1);}
int ordenar_mergesort(int arreglo[], size_t n) {emit("sort_entry","ordenar_mergesort",-1);
	int *auxiliar;emit("aux_declare","ordenar_mergesort",-1);
	emit("valid_call","ordenar_mergesort",-1);if(checked(arreglo_valido(arreglo,n))){emit("guard_error","ordenar_mergesort",-1);return ORDENAMIENTO_ERROR;}
	auxiliar=(int*)reserve(n*sizeof(int));aux=auxiliar;live=aux!=NULL;emit("aux_reserve","ordenar_mergesort",-1);
	if(cond("allocation_guard","ordenar_mergesort",auxiliar==NULL)){emit("allocation_error","ordenar_mergesort",-1);return ORDENAMIENTO_ERROR;}
	emit("recursive_call","ordenar_mergesort",-1);mergesort_recursivo(arreglo, auxiliar, 0, n - 1);emit("recursive_resume","ordenar_mergesort",-1);
	free(auxiliar);live=0;aux=NULL;frees++;emit("aux_free","ordenar_mergesort",-1);
	emit("sort_return","ordenar_mergesort",-1);return ORDENAMIENTO_OK;
}
int main(void){int status;
{int a[]={7};root=a;count=sizeof(a)/sizeof(a[0]);fixture=0;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(a,count);if(status!=ORDENAMIENTO_OK)return 2;}
{int a[]={1,2,3,4};root=a;count=sizeof(a)/sizeof(a[0]);fixture=1;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(a,count);if(status!=ORDENAMIENTO_OK)return 2;}
{int a[]={4,3,2,1};root=a;count=sizeof(a)/sizeof(a[0]);fixture=2;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(a,count);if(status!=ORDENAMIENTO_OK)return 2;}
{int a[]={2,2,2};root=a;count=sizeof(a)/sizeof(a[0]);fixture=3;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(a,count);if(status!=ORDENAMIENTO_OK)return 2;}
{int a[]={-3,0,-1,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=4;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(a,count);if(status!=ORDENAMIENTO_OK)return 2;}
{int a[]={2147483647,-2147483648,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=5;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(a,count);if(status!=ORDENAMIENTO_OK)return 2;}
{int a=42;root=&a;count=0;fixture=6;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(&a,0);if(status!=ORDENAMIENTO_ERROR || a!=42)return 3;}
{root=NULL;count=0;fixture=7;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=0;emit("initial",NULL,-1);status=ordenar_mergesort(NULL,1);if(status!=ORDENAMIENTO_ERROR)return 4;}
{int a[]={2,1};root=a;count=2;fixture=8;depth=live=comparisons=moves=allocs=frees=0;aux=NULL;memset(initialized,0,sizeof(initialized));fail=1;emit("initial",NULL,-1);status=ordenar_mergesort(a,2);if(status!=ORDENAMIENTO_ERROR || a[0]!=2 || a[1]!=1)return 5;}return 0;}
