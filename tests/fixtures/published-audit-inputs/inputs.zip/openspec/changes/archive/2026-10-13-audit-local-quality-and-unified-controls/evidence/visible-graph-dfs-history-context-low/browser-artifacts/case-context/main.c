/** @file main.c @brief Historial de operaciones; BFS/DFS imprimen su resultado C y libera su lista propia. */
#include "tad_grafo.h"
#include <stdio.h>
#include <stdlib.h>
/** @brief Ejecuta el historial. @return 0 tras liberar el grafo final. */
int main(void) {
    Grafo g = grafo_crear();

    // Historial de ejecucion del usuario
    /* TAD nuevo: reinicio del grafo (dirigido=true didáctico). */ g = grafo_crear();
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, -1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, 2);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_arco(g, -1, 2, 1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    ListaVertice rec_5 = grafo_dfs(g, -1); printf("DFS:"); for (ListaVertice it_5 = rec_5; it_5 != NULL; it_5 = it_5->sig) printf(" %d", it_5->dato); printf("\n"); while (rec_5 != NULL) { ListaVertice next_5 = rec_5->sig; free(rec_5); rec_5 = next_5; }
    ListaVertice rec_6 = grafo_dfs(g, -1); printf("DFS:"); for (ListaVertice it_6 = rec_6; it_6 != NULL; it_6 = it_6->sig) printf(" %d", it_6->dato); printf("\n"); while (rec_6 != NULL) { ListaVertice next_6 = rec_6->sig; free(rec_6); rec_6 = next_6; }
    g = grafo_insertar_vertice(g, 99);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    ListaVertice rec_8 = grafo_dfs(g, 99); printf("DFS:"); for (ListaVertice it_8 = rec_8; it_8 != NULL; it_8 = it_8->sig) printf(" %d", it_8->dato); printf("\n"); while (rec_8 != NULL) { ListaVertice next_8 = rec_8->sig; free(rec_8); rec_8 = next_8; }
    while (g.a != NULL) { ListaArco next = g.a->sig; free(g.a); g.a = next; }
    while (g.v != NULL) { ListaVertice next = g.v->sig; free(g.v); g.v = next; }
    return 0;
}