#include "tad_cola_prioridad.h"
#include <stddef.h>
void qa_event(const char*,ColaPrioridad*,int);int qa_guard(const char*,ColaPrioridad*,int);void qa_capture(void*,int);void qa_field(void*,int);void qa_helper_scope(int);void*qa_malloc(size_t);void qa_free(void*);
