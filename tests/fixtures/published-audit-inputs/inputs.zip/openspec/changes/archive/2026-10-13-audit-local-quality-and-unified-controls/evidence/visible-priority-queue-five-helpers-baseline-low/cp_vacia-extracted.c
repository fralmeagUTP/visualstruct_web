/**
 * @brief Indica si la cola de prioridad no contiene ningún elemento.
 *
 * @param[in] cola Puntero constante a la ColaPrioridad a consultar.
 *
 * @return @c true si @p cola es NULL, @c delante es NULL o @c cantidad es cero.
 * @return @c false si la cola tiene al menos un elemento.
 *
 * @note Complejidad temporal: O(1).
 */
bool cp_vacia(const ColaPrioridad *cola) {
    return cola == NULL || cola->delante == NULL || cola->cantidad == 0;
}