#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
static void *ptrs[8192];static int live[8192],total,allocs,frees,attempts;
static void *track(void*p){if(p){assert(total<8192);ptrs[total]=p;live[total++]=1;allocs++;}return p;}
void *owned_malloc(size_t n){attempts++;return track(malloc(n));}
void *owned_calloc(size_t n,size_t z){attempts++;return track(calloc(n,z));}
void owned_free(void*p){if(p){int found=0;for(int i=0;i<total;i++){if(live[i]&&ptrs[i]==p){live[i]=0;found=1;break;}}assert(found);frees++;}free(p);}
static void ownership_done(void){for(int i=0;i<total;i++){assert(!live[i]);}assert(allocs==frees);printf("OWNERSHIP %d %d 0 ATTEMPTS %d\n",allocs,frees,attempts);}
int downloaded_main(void);
int main(void){int status=downloaded_main();ownership_done();return status;}
