#include <stddef.h>
struct NodoPila;
void qa_event(const char*,struct NodoPila**,int);
int qa_guard(const char*,struct NodoPila**,int);
void qa_capture(struct NodoPila*);
void qa_field(struct NodoPila*,int);
void*qa_malloc(size_t);
void qa_free(void*);
int qa_printf(const char*,...);
