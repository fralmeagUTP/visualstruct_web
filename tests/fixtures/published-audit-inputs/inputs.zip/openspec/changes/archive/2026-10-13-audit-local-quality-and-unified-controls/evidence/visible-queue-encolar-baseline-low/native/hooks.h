#include <stddef.h>
struct NodoCola;struct Cola;
void qa_event(const char*,struct Cola*,int);
int qa_guard(const char*,struct Cola*,int);
void qa_capture(struct NodoCola*);
void qa_field(struct NodoCola*,int);
void*qa_malloc(size_t);
void qa_free(void*);
int qa_printf(const char*,...);
