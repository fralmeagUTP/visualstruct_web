/**
 * @brief Copia el valor y prioridad de cada elemento en arreglos externos.
 *
 * @details
 * Recorre la cola de frente a fondo. Por cada nodo, copia su @c valor
 * en @p valores[@c i] y su @c prioridad en @p prioridades[@c i].
 * Se copian como máximo @p capacidad elementos. La cola no se modifica.
 *
 * @param[in]  cola        Puntero constante a la ColaPrioridad de origen.
 * @param[out] valores     Arreglo donde se almacenarán los valores copiados.
 * @param[out] prioridades Arreglo donde se almacenarán las prioridades.
 * @param[in]  capacidad   Número máximo de elementos a copiar.
 *
 * @return Número de elementos efectivamente copiados.
 *         Retorna 0 si algún parámetro es inválido.
 *
 * @pre  @p valores y @p prioridades deben apuntar a bloques con espacio
 *       para al menos @p capacidad enteros cada uno.
 * @note Complejidad temporal: O(min(n, capacidad)).
 */
int cp_copiar_items(const ColaPrioridad *cola, int *valores, int *prioridades, int capacidad) {
    int usados = 0;
    CPNodo *aux;

    if (cola == NULL || valores == NULL || prioridades == NULL || capacidad <= 0) {
        return 0;
    }

    aux = cola->delante;
    while (aux != NULL && usados < capacidad) {
        valores[usados] = aux->valor;
        prioridades[usados] = aux->prioridad;
        usados++;
        aux = aux->sgte;
    }
    return usados;
}