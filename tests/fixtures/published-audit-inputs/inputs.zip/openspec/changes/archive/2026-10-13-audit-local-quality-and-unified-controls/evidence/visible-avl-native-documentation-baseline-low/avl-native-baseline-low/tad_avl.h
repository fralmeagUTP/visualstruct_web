#ifndef TAD_AVL_H
#define TAD_AVL_H

/**
 * @file tad_avl.h
 * @brief TAD Arbol AVL de enteros.
 */

/** @brief Nodo de arbol AVL. */
typedef struct nodoAVL {
    int nro; /**< Dato entero almacenado. */
    int FE; /**< Factor de equilibrio: altura del hijo derecho menos altura del izquierdo. */
    struct nodoAVL *der; /**< Hijo derecho. */
    struct nodoAVL *izq; /**< Hijo izquierdo. */
    struct nodoAVL *padre; /**< Enlace al padre del nodo. */
} nodoAVL;

/** @brief Alias de puntero al nodo AVL. */
typedef nodoAVL* AVL;

/**
 * @brief Muestra el árbol AVL de forma visual (rotado 90°).
 * @param arbol Raíz del árbol a mostrar.
 * @param n Nivel de profundidad actual (usar 0 al invocar).
 */
void avl_verArbol(AVL arbol, int n);
/**
 * @brief Indica si un nodo es hoja.
 * @param nodo Nodo a evaluar (puede ser NULL).
 * @return 1 si no tiene hijos, 0 en otro caso.
 */
int avl_esHoja(AVL nodo);
/**
 * @brief Calcula la avl_altura del árbol (número de niveles).
 * @param arbol Raíz del árbol.
 * @return Altura del árbol (0 si está vacío).
 */
int avl_altura(AVL arbol);
/**
 * @brief Rotación simple derecha (avl_RSD).
 * @param r Referencia a la raíz del árbol.
 * @param nodo Nodo desequilibrado (caso IZQUIERDA-IZQUIERDA o punto de rotación).
 */
void avl_RSD(AVL *r, AVL nodo);
/**
 * @brief Rotación simple izquierda (avl_RSI).
 * @param r Referencia a la raíz del árbol.
 * @param nodo Nodo desequilibrado (caso DERECHA-DERECHA o punto de rotación).
 */
void avl_RSI(AVL *r, AVL nodo);
/**
 * @brief Rotación doble derecha (avl_RDD).
 * @param r Referencia a la raíz del árbol.
 * @param nodo Nodo desequilibrado (caso IZQUIERDA-DERECHA).
 */
void avl_RDD(AVL *r, AVL nodo);
/**
 * @brief Rotación doble izquierda (avl_RDI).
 * @param r Referencia a la raíz del árbol.
 * @param nodo Nodo desequilibrado (caso DERECHA-IZQUIERDA).
 */
void avl_RDI(AVL *r, AVL nodo);
/**
 * @brief Inserta un valor en el árbol AVL.
 * @param raiz Referencia a la raíz del árbol.
 * @param x Valor a avl_insertar (no se insertan duplicados).
 */
void avl_insertar(AVL *raiz, int x);
/**
 * @brief Elimina el valor indicado del árbol AVL (con rebalanceo).
 * @param raiz Referencia a la raíz del árbol.
 * @param x Valor a avl_eliminar.
 */
void avl_eliminar(AVL *raiz, int x);
/**
 * @brief Busca un valor en el árbol AVL.
 * @param raiz Raíz del árbol.
 * @param x Valor a avl_buscar.
 * @return Puntero al nodo con el valor o NULL si no se encuentra.
 */
AVL avl_buscar(AVL raiz, int x);
/**
 * @brief Obtiene el nodo con el valor mínimo del subárbol dado.
 * @param nodo Raíz del subárbol.
 * @return Puntero al nodo con el valor mínimo.
 * @pre nodo debe ser distinto de NULL.
 */
AVL avl_minimo(AVL nodo);
/**
 * @brief Libera toda la memoria del árbol AVL (postorden).
 * @param raiz Raíz del árbol a liberar.
 */
void avl_liberarAVL(AVL raiz);

#endif
