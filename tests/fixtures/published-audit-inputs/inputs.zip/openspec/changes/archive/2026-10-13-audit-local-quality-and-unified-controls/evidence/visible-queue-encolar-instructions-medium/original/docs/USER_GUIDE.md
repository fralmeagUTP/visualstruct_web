# Manual de Usuario

Ultima actualizacion: **2026-05-21**.

## 1. Objetivo

El Visualizador Web de Estructuras de Datos permite practicar TAD mediante:

- operaciones interactivas,
- visualizacion del estado interno,
- apoyo didactico con codigo C real de los TAD nuevos (`docs/tads_C`) y fallback de pseudocodigo cuando aplique.

Modulos disponibles:

- Secuencial
- Jerarquico
- Grafos
- Hash

## 2. Requisitos

- Windows 10/11
- Python 3.10+
- Navegador moderno
- Acceso local a `127.0.0.1`

## 3. Instalacion y arranque

Desde `C:\Users\fralm\Desktop\Web_VisualEstruct`:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
.\start_local.bat
```

Abrir:

```text
http://127.0.0.1:5050/
```

## 4. Navegacion

Barra superior:

- Inicio
- Manual de uso
- Modulo Secuencial
- Modulo Jerarquico
- Modulo Grafos
- Modulo Hash
- Secciones de ayuda
- `Mostrar codigo y detalles tecnicos`
- `Exportar JPG` (descarga el panel de estado visual activo del modulo actual)
- `Calidad` y `Escala` para definir compresion y resolucion del JPG exportado.

Acceso directo al manual:

- `http://127.0.0.1:5050/help/manual`

## 5. Flujo de uso

1. Entrar a un modulo.
2. Elegir una estructura.
3. Seleccionar una operacion.
4. Completar inputs.
5. Ejecutar.
6. Revisar resultado en:
   - mensaje didactico,
   - panel visual,
   - estructura/codigo C o pseudocodigo,
   - historial.
7. Usar `Reiniciar` para limpiar el estado de esa estructura.

## 5.1 Controles de ejecucion paso a paso

En secuencial, jerarquico y hash los controles se muestran asi:

- fila superior: `Reproducir`, `Reiniciar`.
- fila inferior: `Anterior paso`, `Siguiente paso`.

Comportamiento esperado:

- `Reproducir`: ejecuta la traza completa automaticamente.
- `Anterior paso`: retrocede una linea/paso en la traza.
- `Siguiente paso`: avanza una linea/paso en la traza.
- `Reiniciar`: limpia el estado de la estructura actual.

En grafos:

- la simulacion esta integrada en `Paso 3: Ejecutar algoritmo`;
- controles: `Reproducir`, `Anterior paso`, `Siguiente paso`;
- `Siguiente paso` avanza linea a linea la traza del algoritmo;
- `Accion actual` indica `Evaluando condicion` o `Aplicando cambio`.

Checkbox comun en todos los modulos:

- `Interpretar codigo paso a paso` activado: reproduce la traza completa.
- `Interpretar codigo paso a paso` desactivado: aplica solo el resultado final.
- Con el checkbox desactivado, `Anterior paso` y `Siguiente paso` quedan deshabilitados.
- En grafos, el resultado final en modo rapido debe coincidir con el ultimo estado visual del modo interpretado
  (mismos resaltados de recorrido, camino minimo o expansion minima).
- En grafos, al desactivar el checkbox se ocultan los controles de navegacion por paso
  (`Anterior paso`, `Siguiente paso`, velocidad, contador y accion actual).

## 6. Modo interprete C

Hay cobertura C para:

- Secuenciales (`stack`, `queue`, `priority_queue`, `linked_list`, `circular_list`, `sublist`)
- Jerarquicas (`abb`, `avl`, `red_black`, `binary_heap`)
- Grafos (`graph`)

Cuando aplica:

- `Estructura del TAD` muestra el `record` C.
- `Codigo C: <Operacion>` muestra funciones C por operacion.
- El historial se presenta como programa principal (`main`) coherente con la sesion.
- `hash_table` tambien usa contrato C (por ejemplo `th_insertar`, `th_buscar`, `th_estadisticas`).

La app no mantiene compatibilidad con nombres legacy de TAD anteriores.

## 6.1 Especificacion obligatoria de simulacion didactica

La simulacion debe representar visualmente la ejecucion real del metodo en C y el efecto sobre la estructura de datos.

Reglas de cumplimiento:

1. El interprete visual debe respetar estructuras de control (`if/else`, ciclos y retornos tempranos); no debe ejecutar ni animar ramas no tomadas.
2. En operaciones mutantes, la animacion debe mostrar al menos estas etapas:
   - estado inicial,
   - creacion de estructura temporal (ej. nodo `aux`),
   - asignaciones intermedias de punteros/enlaces,
   - reasignacion a la estructura principal,
   - estado final.
3. Las estructuras temporales deben verse como elementos separados de la estructura principal hasta el paso de reasignacion.
4. La linea activa de `Codigo C` y el estado visual deben permanecer sincronizados en cada paso.
5. La `Consola C (printf)` debe mostrar los mensajes de la ruta realmente ejecutada, evitando duplicados consecutivos.
6. El `Programa principal (main)` del historial debe ser consistente con las operaciones ejecutadas, con el estado final mostrado y conservando cada ejecucion exitosa, incluidas repeticiones iguales.
7. Esta especificacion aplica a toda la app y unicamente a los TAD nuevos ubicados en `docs/tads_C`.

## 7. Reglas de entrada

- Secuencial/Jerarquico: valores numericos enteros.
- Grafos:
  - `vertex`, `origin`, `target`, `start`, `end`: enteros.
  - `weight`: numerico (int/float).
  - `directed`: booleano (`true/false`, `1/0`, `si/no`).
- Hash: `key` y `value` como texto.

Si un dato no cumple validacion, la operacion no se ejecuta y se devuelve mensaje de error didactico.

## 8. Funcionalidad por modulo

### 8.1 Secuencial

Incluye operaciones de insercion, eliminacion, busqueda y limpieza para:

- Pila
- Cola
- Cola de prioridad
- Lista enlazada
- Lista circular
- Sublista

En la Lista enlazada, `limpiar` ejecuta `lista_limpiar(Tlista *lista)`: mientras
`*lista` no sea `NULL`, guarda el nodo cabeza en `q`, actualiza
`*lista = q->sgte` y ejecuta `free(q)`. La pantalla, la ayuda y la descarga del
TAD muestran este mismo método.

En Sublista cada padre es un nodo independiente, aunque varios almacenen el
mismo valor. Las operaciones por valor actúan sobre la primera coincidencia de
padre o hijo, igual que las funciones C. `hijos_de` muestra la función real
`sublista_obtener_hijos` y sus recorridos auxiliares; al eliminar un padre o
limpiar, primero se desconectan los enlaces y luego se libera cada hijo y padre.
La traza enseña esos estados temporales junto con el código C y la estructura.

### 8.2 Jerarquico

Estructuras:

- ABB
- AVL
- Rojo-Negro
- Monticulo binario

Puntos visuales:

- AVL muestra `balance_factor` por nodo.
- Rojo-Negro renderiza color por nodo (`RED`/`BLACK`).
- Monticulo muestra arreglo y arbol sincronizados.

En Rojo-Negro, Insertar acepta los enteros de C de 32 bits: desde `-2147483648`
hasta `2147483647`. Un valor fuera de ese rango se rechaza antes de cambiar
el arbol o guardar historial; no se convierte ni trunca silenciosamente.
El programa principal conserva las operaciones exitosas, incluidas repeticiones.
Al finalizar ejecuta `rbt_liberar(arbol); arbol = NULL;` fuera del historial,
sin agregar una operacion del estudiante ni salida `printf`. Liberar recibe
la raiz por valor: asignar NULL despues permite limpiar otra vez con seguridad.
Las hojas negras del C son enlaces NULL; no son reservas NIL que deban liberarse.

### 8.3 Grafos

Permite:

- crear grafo dirigido o no dirigido,
- insertar/eliminar vertices y aristas con peso,
- listar vertices/aristas/vecinos,
- ejecutar BFS, DFS, Dijkstra, Bellman-Ford, Prim y Kruskal.

Recomendaciones:

- Prim y Kruskal solo aplican a grafos no dirigidos.
- Dijkstra no acepta pesos negativos; para ese caso usar Bellman-Ford.
- Usa el flujo visual 1) tipo de grafo, 2) construir/editar, 3) ejecutar y depurar paso a paso.
- Si desactivas la interpretacion paso a paso, `Reproducir` aplica directamente el resultado final del algoritmo.

### 8.4 Hash

Permite:

- crear tabla con capacidad inicial,
- insertar/actualizar (`key`, `value`),
- buscar, verificar existencia y eliminar claves,
- listar claves/valores/items,
- ver metricas (`size`, `capacity`, `load_factor`) y colisiones.

## 9. Solucion de problemas

### `ERR_CONNECTION_REFUSED`

1. Confirmar que la consola del servidor siga abierta.
2. Validar URL: `http://127.0.0.1:5050/`.
3. Reiniciar con `.\start_local.bat`.
4. Si persiste, usar:

```powershell
.\run_server_debug.bat
```

### Puerto ocupado

Si `5050` esta ocupado, cerrar procesos Python en ejecucion y volver a iniciar.

## 10. Ejecutar pruebas

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```


### BFS: instruccion, cola y programa principal

La linea resaltada acaba de ejecutarse; el frame inicial es anterior a cualquier
llamada. BFS muestra las funciones C reales de grafo y cola, variables por ambito,
reservas temporales separadas del grafo, enlaces parciales y marcas compartidas.
Se marca al encolar, no al extraer; descubrir un vertice no significa que ya este
en el recorrido devuelto. `-1` es un identificador valido. El recorrido solo cubre
la componente alcanzable y depende del orden de insercion de arcos. Ignora pesos:
minimiza cantidad de arcos, no costo. El C de este TAD hace barridos de listas;
su cota es O(V*(V+E)), distinta de la BFS ideal O(V+E) con acceso directo.

`Paso anterior` restaura el frame y oculta resultados futuros; no ejecuta otro
POST ni vuelve a liberar nodos. Una declaracion o condicion puede no alterar el
dibujo del grafo: observe variables, cola y memoria. Las identidades mostradas son
simbolicas, no direcciones de una ejecucion nativa real. Tras free, el registro
historico no se puede usar como puntero. En la ruta normal BFS no imprime printf;
la consola no debe inventar visitas. La confirmacion de la app aparece al completar
la traza y es distinta del printf del programa principal.

Cada BFS exitoso, tambien dos llamadas iguales consecutivas, queda en el historial.
Recargar reconstruye la topologia sin volver a ejecutar consultas BFS historicas;
sus marcas/cola son efectos temporales de la ejecucion, no nueva topologia persistida.
Un inicio inexistente se rechaza en la app y no se agrega al main. En C crudo, BFS
desmarca primero y retorna NULL si inicio falta; son guardas distintas.

El main incluye `tad_grafo.h`, stdio y stdlib, ejecuta cada llamada guardada, imprime
los datos realmente devueltos y libera cada lista BFS y el grafo final. Descargue
tad_grafo.c/.h y su dependencia tad_cola.c/.h y compile juntos con C17. La falta de
memoria nativa puede producir listas parciales/NULL o marcas de vertices no procesados;
la simulacion actual modela asignaciones normales, sin inyectar esos fallos.


## DFS: contrato del C y caller descargado
DFS comprueba primero si existe el inicio; una llamada C con inicio inexistente
retorna NULL sin limpiar las marcas anteriores. La UI rechaza ese inicio antes
de ejecutar el TAD. Un inicio válido (también -1) limpia marcas y visita usando
recursión real y el orden de la lista de arcos, no orden numérico. Los nodos de
resultado son nuevos y tienen marcado=0, distintos de las marcas del grafo.
Cada frame libera sus sucesores temporales; el caller libera el resultado.
Dos llamadas iguales consecutivas exitosas se conservan; recargar reconstruye
topología sin ejecutar consultas históricas. El main imprime el resultado
calculado por grafo_dfs y libera su lista, en lugar de imprimir texto precalculado.
La cota del C de listas es O(V*(V+E)), además de profundidad recursiva hasta V.
Las reservas pueden fallar y producir resultados parciales; los casos de QA
normales no simulan esas fallas. La revisión por instrucción y reproducción
se verificó en diez casos nativos y ocho casos de navegador registrados; no
abarca todos los grafos, todos los caminos ni fallos de reserva de memoria.
Al recargar, las consultas nuevas conservan sus marcas mediante efectos
capturados y validados, sin volver a ejecutar consultas del historial. Las
mutaciones posteriores conservan las marcas de los vértices existentes; un
vértice recién creado empieza sin marcar. Un historial antiguo sin esos efectos
no permite recuperar marcas anteriores: no se inventan ni se repiten consultas.
Después de ejecutar en modo rápido puede abrir Paso a paso para recorrer la
misma ejecución hacia adelante o atrás; eso no ejecuta otra operación.


## Dijkstra: contrato nativo del C descargado
Dijkstra requiere pesos enteros no negativos en el C; cualquier arco negativo,
aunque esté desconectado del inicio, hace que el C retorne NULL. Un camino
al mismo vértice no necesita arcos y también se representa con NULL; no debe
confundirse por sí solo con un error. El resultado no vacío contiene arcos
nuevos y corresponde al llamador liberarlos. El grafo conserva sus marcas.

INT_MAX (2147483647) representa infinito: un costo total igual o mayor no se
publica como camino; las sumas fuera del rango se descartan antes de sumar.
Cuando dos vértices tienen la misma distancia, el C elige el primero en el
orden de su lista almacenada, no necesariamente el menor identificador.
Una distancia igual no sustituye el predecesor. La aplicación actual rechaza
pesos con parte fraccionaria; el archivo C de enteros no ofrece semántica decimal.
La especificación canónica aún admite decimales: esa contradicción requiere
una decisión, no una conversión silenciosa.

La comparación QA actual registró diferencias de empate y límite entre C y
aplicación. Los casos por instrucción de sus arreglos, condiciones y memoria
siguen pendientes; no se garantiza aquí paridad completa. El historial ya
conserva cada consulta exitosa sin repetirla al recargar; los fallos se omiten.
El programa generado imprime el camino y costo que devuelve el C y libera
sus arcos. Un retorno NULL se muestra como resultado ambiguo: sin arcos,
sin ruta o error de entrada/memoria, sin inventar un camino calculado.
Los casos normales no inyectan fallos de reserva de memoria.


## Bellman-Ford: negativos y límites del C descargado
Bellman-Ford admite pesos enteros negativos. Un ciclo negativo sólo se detecta
si es alcanzable desde el inicio; los ciclos desconectados no invalidan el
camino de otra componente. El C valida inicio y llegada antes de relajar.
Cuando detecta una mejora adicional dentro del rango entero, imprime
"Se detecto un ciclo negativo." y retorna NULL. La aplicación actual informa
la bandera de ciclo con success=true; su estatus frente a la spec sigue pendiente.

El C usa INT_MAX como infinito y calcula cada candidata en long long antes
de comprobar si cabe en INT_MIN..INT_MAX. Las candidatas fuera del rango se
ignoran, también en la comprobación de ciclo. QA observó que dos arcos de
peso INT_MIN pueden formar un ciclo negativo alcanzable que ese C no reconoce.
Es un defecto pendiente del algoritmo, no un resultado matemático confiable.
Las sumas descartadas por la guarda no son desbordamientos ejecutados.

El resultado no vacío es una lista nueva de arcos que libera el llamador; el
grafo conserva su memoria y marcas. NULL también puede indicar camino sin
arcos, destino inalcanzable, entrada inválida o fallo de reserva. No debe
inferirse su causa sin el contexto. Las consultas exitosas repetidas se conservan al recargar sin volver a
ejecutarlas; las fallidas se omiten. El programa generado imprime el resultado
C y libera sus arcos. La fidelidad por instrucción sigue sin verificar.
Los casos normales no inyectan fallos de reserva; no se cambió el contrato decimal.


## Prim: bosque y límites del C descargado
La API exige un grafo no dirigido y clasifica el resultado desconectado como
bosque, con número de componentes. El C no tiene bandera de dirección:
la representación no dirigida necesita arcos simétricos. El main generado
inserta/elimina ambos sentidos por operación; un bucle se escribe una sola vez.
Prim C reinicia en otros componentes y puede devolver un bosque completo,
no solamente el árbol del inicio. El grafo y sus marcas permanecen intactos.

El C omite pesos negativos; la API actual los selecciona. INT_MAX funciona
como centinela y un arco de ese costo queda omitido en C, aunque la API lo
selecciona. Empates también pueden escoger aristas distintas con igual costo.
Son divergencias pendientes, no una equivalencia demostrada. No se cambia
el contrato compartido entero/decimal durante esta revisión.

Las consultas exitosas repetidas se conservan sin redispatch al recargar;
las rechazadas se omiten. El main imprime arcos/costo devueltos por C y libera
su lista propia y el grafo final. La suma de salida usa long long para evitar
sumar costos int en un acumulador int. NULL no diferencia bosque sin arcos,
inicio ausente y fallo de memoria. QA acotada usa memoria normal, sin inyección
de fallos ni firma de fidelidad por instrucción.


## Kruskal: contrato del C descargado
Kruskal admite pesos enteros negativos y extremos INT_MIN/INT_MAX. No usa
INT_MAX como infinito ni suma costos dentro del algoritmo: devuelve arcos.
El main acumula su costo en long long. El C ordena punteros a los arcos mediante
burbuja estable; no implementa el ordenamiento O(E log E) del modelo ideal.
Con búsquedas lineales de índices y padres, una cota conservadora de este C
es O(E²+EV+V). Los empates conservan orden de la lista de arcos y pueden
seleccionar un MST diferente del backend, aunque el costo coincida.

Union-Find rechaza bucles y el segundo sentido de un arco simétrico cuando
sus extremos ya están unidos. El resultado desconectado es un bosque; la API
actual informa componentes y clasificación. El C considera conexiones sin
bandera de dirección; la API exige no dirigido. El resultado es una lista
nueva propia del caller, mientras los arcos fuente y las marcas se conservan.
NULL puede significar ningún arco seleccionado o error de reserva; no permite
deducir la causa sin contexto. Ante fallo al reservar resultado, el C libera
la lista parcial. QA normal no inyectó dichos fallos.

Historial conserva consultas exitosas repetidas sin redispatch al recargar;
fallos dirigidos se omiten. El main imprime arcos/costo calculados por C y
libera resultado/grafo. No se cambió política decimal, empates ni dirección.
La fidelidad de arrays, Union-Find y memoria por instrucción sigue abierta.


## Ordenamientos: baseline C y límites actuales
Hay once métodos:intercambio,seleccion,insercion,burbuja,shell,quicksort,
mergesort,heapsort,counting_sort,binsort,radixsort. Todos trabajan sobre int;
API admite1..80elementos int32 yrechaza vacío antes del algoritmo. Cvoid
ignora NULL/n0;Merge/Counting/Bin/Radix retornan ERROR en esa entrada. Counting
usa k=max-min+1 computado enlong long,limita k a1000000 antes de reservar;
Binsort delega exactamente. Radix usa magnitudes uint32_t yprotege INT_MIN:
no se reproduce el desbordamiento histórico enel C actual de QA.

Inserción/burbuja/mezcla son estables por comparaciones estrictas/elección
izquierda;intercambio,selección,Shell,Quick,Heap no garantizan estabilidad.
Counting/Bin reconstruyen frecuencias,sinidentidad de registros iguales;
Radix tiene pasadas estables pero revierte elgrupo negativo completo: no
prometer estabilidad general de registros negativos iguales. Un array int
con duplicados sólo prueba resultado/multiconjunto, no identidad estable.

Heap usa stack O(log n) por heapify recursivo;Quick pila O(log n) promedio y
O(n) peor;Merge auxiliar O(n). Los restantes directos sonO(n²) peor,Shelldepende
de gaps;Counting/Bin O(n+k),Radix base10 O(d(n+10)). Las notasC/H concretan
cada contrato;no confundir cota teórica con métricas observadas o tiempo real.

Las ejecuciones exitosas se conservan con efecto de arreglo validado:GET
restaura resultado sin volver a ordenar;repetir Ejecutar ordena el estado
actual. Fallos no seagregan. APIstep reconstruye la última traza desde su
entrada original;UI usa la traza local. Historiales antiguos sin efecto no
pueden recuperar ejecuciones perdidas. No existe main de historial en laUI
actual:es un faltante,los callers equivalentes nativos deQA no lo sustituyen.
Fidelidad por instrucción permanece abierta ylos numéricos deGrafos pendientes.


### Main reproducible de Ordenamientos

En la quinta seccion, **Resultados de ejecucion**, activa los detalles tecnicos y abre el historial. Alli puedes copiar o descargar `main.c`, `tad_ordenamiento.c` y `tad_ordenamiento.h`. Los enlaces usan las descargas existentes; no hay otro boton de ejecucion. Compila el programa completo:

```sh
gcc -std=c17 -Wall -Wextra -pedantic main.c tad_ordenamiento.c -o ordenamiento
```

El programa reproduce solo creaciones y runs aceptados, en orden: una recreacion reemplaza los datos y dos ejecuciones iguales siguen siendo dos llamadas. Seleccionar un metodo sin ejecutar deja un comentario; los fallos de entrada no agregan llamadas. GET, recarga y navegacion no vuelven a ordenar ni a generar aleatorios guardados. Los valores aleatorios estan materializados; no se usa rand de C para reproducir una semilla Python. La exportacion JSON existente incluye el mismo main.

El arreglo del caller tiene almacenamiento automatico para80elementos, sin malloc/free. Los metodos del TAD liberan sus auxiliares cuando aplica. Siete firmas son void; Merge/Counting/Bin/Radix retornan int: el main comprueba ORDENAMIENTO_OK y termina con codigo1 ante un fallo nativo, incluida memoria, sin imprimir un arreglo exitoso futuro. Las salidas se calculan mediante las llamadas C reales, no son textos copiados del resultado de Python. Dominio de la aplicacion: enteros int32 y1..80elementos; Counting/Bin rechazan rango mayor que1000000. El main vacio imprime[]. La compilacion exige int32 para reproducir limitesINT_MIN/INT_MAX.

Verificar este caller no verifica las instrucciones internas de los once metodos. Intercambio, Seleccion e Insercion tienen verificaciones por instruccion acotadas a seis entradas de hasta cuatro valores y sus guardas registradas; Burbuja mejorada tiene siete entradas de hasta cuatro valores y sus guardas registradas. Shell tiene seis entradas registradas de hasta cuatro valores con verificacion por instruccion. Quick sort tiene seis entradas registradas de hasta cuatro valores con verificacion por instruccion. Merge sort tiene seis entradas registradas con verificacion por instruccion. Los otros cuatro metodos requieren bloques propios. Esto no declara cobertura de todas las entradas ni estabilidad de identidades etiquetadas.


### Leer los desplazamientos de Insercion

Durante `arreglo[j] = arreglo[j - 1]`, el arreglo conserva los dos valores reales que quedan tras la escritura; no hay una celda vacia. El valor desplazado que falta en ese estado permanece en el local `int clave`, visible en temporales y variables. La estrategia muestra **Clave** e **Indice j** del frame actual. `--j` es un paso separado y no cambia el arreglo; `arreglo[j] = clave` completa la insercion.

La condicion `j > 0 && arreglo[j - 1] > clave` muestra sus operandos en orden y el resultado compuesto. Si `j==0`, no se consulta `arreglo[j - 1]`. Al cerrar la pasada desaparecen sus locales `clave/j`; `i` continua hasta el retorno. El prefijo de pasadas terminadas esta ordenado, pero una clave futura aun puede desplazarlo. Avanzar, retroceder y cambiar de modo restauran la misma traza sin nueva ejecucion.


### Burbuja mejorada y sus metricas

El catalogo de Ordenamientos contiene una variante de Burbuja: **Burbuja mejorada**, `ordenar_burbuja`. Compara vecinos y reduce el segmento pendiente tras cada pasada. Si una pasada termina sin intercambios, la bandera `hubo_intercambio` queda en cero y el C sale mediante `break`.

Cada intercambio contabiliza tres movimientos: guardar `temporal`, escribir `*a` y escribir `*b`. La metrica cambia al ejecutar cada asignacion, tambien durante el estado duplicado provisional. Una pasada sin intercambio aporta comparaciones pero cero movimientos. La verificacion por instruccion de Burbuja cubre siete entradas registradas de hasta cuatro valores. Las 330 observaciones del C coinciden con los estados de la traza, incluyendo controles, locales y escrituras parciales. Este cierre es acotado; no afirma cobertura de todas las entradas ni de identidades etiquetadas.

La bandera se declara sin inicializar y se asigna cero al iniciar cada pasada. Durante el primer intercambio sigue en cero: solo pasa a uno tras retornar del helper y ejecutar su asignacion C. Los indices pasada y j y la bandera permanecen en su scope de funcion entre pasadas. El helper muestra los dos punteros reales a vecinos y su local temporal; estos locales desaparecen al retornar. Una prueba interna falsa no muestra vecinos fuera de limites. Tras una pasada sin intercambios, break termina el bucle exterior sin incrementar pasada ni evaluar otra condicion exterior. El retorno retira los locales. Avanzar, retroceder y cambiar de modo restauran los mismos estados sin agregar ejecuciones.


### Leer la traza de Shell

Shell usa intervalos n/2, n/4 y asi hasta uno, insertando cada elemento dentro de su grupo por intervalo. La estrategia muestra el intervalo numerico, i, j, temporal y los indices del grupo activo. La declaracion de intervalo y la de i muestran sin inicializar hasta ejecutar su asignacion C; el retorno retira los locales.

Durante arreglo[j] = arreglo[j - intervalo] se muestran valores duplicados reales. El valor pendiente permanece en int temporal; no hay una celda vacia. j -= intervalo es otra instruccion, sin escribir el arreglo. La condicion j >= intervalo && arreglo[j - intervalo] > temporal muestra primero el indice y solo consulta el arreglo si ese operando es verdadero. La comparacion se contabiliza solo cuando se ejecuta.

j y temporal pertenecen al cuerpo de i y desaparecen antes de ++i. i pertenece al cuerpo del intervalo y desaparece antes de intervalo /= 2. Al terminar ese cuerpo todos sus grupos estan ordenados por el intervalo; sus valores aun pueden cambiar con un intervalo posterior. Los colores de valores definitivos se reservan para el retorno final. Avance, retroceso y cambio de modo restauran la misma traza sin otra ejecucion.

El cierre registrado de Shell comprende seis entradas de hasta cuatro valores y sus guardas nativas,322observacionesC. No afirma cobertura de todas las entradas ni estabilidad de identidades etiquetadas. Se conservan los cuatro cierres acotados anteriores; Quick sort tambien tiene su cierre acotado; Merge sort tambien tiene cierre acotado; los otros cuatro metodos requieren bloques propios.


### Leer la recursion de Quick sort

Quick sort usa un pivote entero local y dos indices int. La estrategia muestra los parametros primero/ultimo, i/j, el valor local de pivote y profundidad de la activacion actual. La particion esta dentro de quicksort_recursivo; no hay una funcion particion aparte. La pila muestra cada activacion con sus propios parametros y los scopes numerados distinguen locales de padres e hijos. El caller conserva sus variables mientras el hijo ejecuta; el retorno retira solo los locales del hijo.

Los scans muestran la comparacion real con el pivote guardado, seguido de ++i o --j cuando corresponde. El while exterior y el if i<=j se representan separadamente. Despues de intercambiar, ++i y --j son dos instrucciones; j puede valer -1 como int, sin que ese estado autorice consultar arreglo[-1]. Las guardas primero<j e i<ultimo deciden las llamadas recursivas.

Cada intercambio ejecuta tres asignaciones, incluso si a y b apuntan al mismo entero. Ambos alias se muestran en la pila y punteros; temporal permanece disponible durante las escrituras parciales y se retira al retornar. Con [7], el C y la traza llaman al helper, realizan el auto-intercambio y cuentan tres comparaciones, un intercambio y tres movimientos. No se imprime una salida printf del TAD. Los programas descargados calculan sus salidas mediante C.

Avance, retroceso y cambios de modo restauran la misma traza sin nuevas llamadas. El cierre registrado comprende seis entradas de hasta cuatro valores,386observacionesC y sus guardas nativas; no afirma todas las entradas ni estabilidad de identidades etiquetadas. Se conservan los cinco cierres anteriores; Merge sort tambien tiene cierre acotado; quedan cuatro metodos por verificar por instruccion. El dominio de aplicacion1..80 evita cast y suma de indices no representables; no se ha auditado huge-n fuera de ese dominio.


### Merge sort: baseline LOW histórico (2026-10-02)

El baseline conservado registró seis resultados/métricas coincidentes, pero una traza de63cuadros frente652observacionesC. Mostraba valores prematuros del auxiliar y omitía activaciones recursivas y escrituras individuales. Las once regresiones causales originales y sus logs se preservan. Ese baseline no constituía cierre por instrucción; el bloque posterior se describe a continuación.

### Merge sort: reserva, recursión y mezcla por instrucción

La vista representa los parámetros size_t de cada activación, el medio declarado después de la guarda y los locales i/j/k de mezclar. Conserva ancestros suspendidos, llamadas, retornos y retirada de scopes. El caso n1 también reserva, llama al caso base y libera. Las condiciones && respetan cortocircuito; <= elige la rama izquierda al empatar.

El auxiliar tiene tamaño n y empieza con celdas «sin inicializar»; cada escritura define únicamente su destino. Cada asignación con postincrementos se presenta completa, sin atribuir un orden de evaluación no fijado por C. La copia de vuelta modifica una celda por cuadro. free termina la vida de la reserva sin afirmar que C asigna NULL, y el retorno final confirma el resultado. La UI indica «sin contador ordinal» porque estos ciclos no declaran tal contador; i/j/k muestran sus valores C. El TAD no produce printf en esta ruta.

Avance, retroceso, fast->step y recarga conservan la misma ejecución sin redispatch y mantienen el caller descargado. Los siete programas únicos registrados (seis entradas +vacío) compilan en C17 y generan Doxygen sin advertencias; las seis llamadas equilibran una reserva/liberación cada una. Los callers manejan ORDENAMIENTO_ERROR ante fallo de primera reserva sin imprimir éxito. Guardas nativas n0/NULL y fallo de reserva se verificaron por separado de la UI vacía rechazada; el backend normal no simula agotamiento real de malloc.

El cierre comprende exclusivamente seis entradas de hasta cuatro valores,652observacionesC y1304restauracionesUI. No demuestra todas las entradas, estabilidad de identidades etiquetadas ni huge-n fuera del dominio1..80. Evidencia: openspec/changes/audit-local-quality-and-unified-controls/evidence/visible-sorting-mergesort-instructions/README.md. Siete métodos tienen cierres de casos registrados; pendientes Heap sort,Counting sort,Binsort,Radix sort.


### Heap sort: alcance del baseline LOW

Heap sort es ordenar_heapsort del TAD de Ordenamientos, con helpers heapify e intercambiar; es independiente del TAD Heap binario. Los seis casos registrados coinciden en resultado, comparaciones, intercambios y movimientos. Se contabilizan tres movimientos por llamada al helper incluso con valores iguales, sin salida printf del TAD. Los alias de la guarda y los parámetros del helper se representan desde sus índices reales. No usa memoria dinámica; el espacio auxiliar pertenece a la pila recursiva.

La traza actual todavía omite controles for, asignaciones de mayor, activaciones/retornos recursivos y scopes. La estrategia dibuja también el sufijo ya extraído dentro del árbol; no debe tomarse como certificado del heap activo. Hay doce regresiones causales permanentes y un bloque MEDIUM delimitado, aún sin ejecutar. Coincidir en métricas no convierte Heap sort en el octavo cierre por instrucción.

Los cuatro callers descargados actuales compilan en C17 y pasan Doxygen, con tres llamadas reales y cero reservas dinámicas. Guardas nativas n0/NULL y aNULL/bNULL se probaron por separado de la UI vacía rechazada. Detalle y límites: openspec/changes/audit-local-quality-and-unified-controls/evidence/visible-sorting-heapsort-baseline-low/README.md.


### Heap sort: instrucciones verificadas en seis casos (2026-10-02)

El bloque MEDIUM muestra los controles reales de ordenar_heapsort, las activaciones recursivas de heapify y las tres asignaciones de intercambiar. El árbol usa solo heap_n; el sufijo confirmado se presenta aparte tras cada extracción terminada. La propiedad max-heap refleja el estado actual y puede incumplirse durante construcción o intercambio parcial. Temporal permanece sin inicializar hasta su lectura real; no hay printf ni reserva dinámica en este TAD. Replay y JSON preservan cursor/estado/main sin ejecutar de nuevo; cursor -1 representa el estado previo. El baseline LOW anterior es histórico. Cierre limitado a los seis casos y evidencia visible-sorting-heapsort-instructions; no prueba universal para todos los arreglos.


### Counting sort: baseline LOW (2026-10-02)

El TAD acepta rango max-min+1 hasta1000000, reserva frecuencias con calloc y libera conteo al terminar; devuelve ERROR ante rango rechazado o reserva fallida. En los seis casos pequeños registrados, la traza agregada cuenta ambas comparaciones de mínimo/máximo y las escrituras de frecuencia, resultado y consumo (2(n-1)comparaciones/3nmovimientos). No hay printf en el TAD. Fast->step,replay/JSON/historial reutilizan la misma ejecución. La traza aún agrupa escritura ydecremento yno expone todos los controles/scopes ni free: fidelidad porinstrucción pendiente, doce regresiones activas. Las fronteras grandes se verificaron solo en Csize_t64; no se ejecutó variante32bit potencialmente insegura. Ver evidencia visible-sorting-counting-baseline-low yplan sorting-counting-instruction-review-plan.md; no cierre universal.


### Counting sort: MEDIUM verificado en seis casos (2026-10-02)

En seis casos n<=4/rango<=4, la nueva traza muestra 416 eventos C: mínimo/máximo mediante aliases a locales, controles reales, calloc con frecuencias cero, escritura con indice++ ydecremento posterior separados, free yretirolexical. Las doce regresiones del baseline se resolvieron sin modificar tests originales. La UI distingue sin declarar/sin inicializar/fuera de alcance y restaura estado/main/JSON sin ejecutar otra vez. El frame parcial de escritura conserva frecuencia hasta --conteo[i].

Este cierre no cubre todoel dominio. Para evitar copias O(k²), fuera de n<=4/rango<=4 se mantiene la traza agregada existente; la app sigueaceptando hasta80elementos y rango1000000. Recorder escalable y fidelidad de entradasamplias pendientes. El oráculo estáverificado con size_t64; no se ejecutó variante32bit potencialmente insegura ni ramo SIZE_MAXverdadero. Ver evidence/visible-sorting-counting-instructions ysorting-counting-resource-bound-decision.md; no prueba universal de memoriaagotada/estabilidad.


### Fotografía anterior de Counting: parcial antes de integración ampliada

La verificación de seis casos pequeños no completa la fidelidad del método. El corte interno n<=4/rango<=4 no es un límite UI aprobado: entradas ordinarias admitidas fuera de él siguen usando traza agregada. La app conserva hasta80enteros int32 y rangoCounting<=1000000. La revisión actual reconoce Counting parcial y propone representación exacta escalable (frecuencias sparse/deltas/eventos paginados/ventana de buckets), sin rechazar entradas válidas. No se ha implementado aún; ver sorting-counting-scope-correction-decision.md ysorting-counting-expanded-fidelity-plan.md.


### Counting: navegación ampliada implementada (2026-10-02)

La integración nueva sustituye la fotografía anterior del corte de cuatro: todas las entradas admitidas usan el mismo núcleo por instrucción. Se conservan1..80enteros int32 y rango max-min+1<=1000000. Las trazas pequeñas conservan el transporte completo; las grandes cargan páginas de eventos exactos sin volver a ordenar. En modo paso a paso, Counting permite Ir al paso (0 es antes de la llamada), Anterior/Siguiente yReproducir traza/Pausar. El contador incluye todos los eventos del rango, también controles de frecuencias cero.

Conteo se muestra en ventana64celdas: el campo Ir al índice de conteo permite consultar cualquier índice real, incluido un hueco grande cuyo valor implícito es cero; Seguir índice activo vuelve a la ventana de la instrucción. No se confunde memoria liberada con una frecuencia cero. La variable i, la pila/helper, alias, condición ylíneaC corresponden al evento activo; escritura del arreglo ydecremento de frecuencia siguen separados.

La recarga en la misma pestaña recupera cursor/modo yreferencia de traza sin nueva operación; Exportar resumenJSON agrega representación compacta completa ymain, evitando listar millones de snapshots. No hay importadorJSON nuevo. El almacenamiento de trazas es local al proceso, acotado, por sesión yconTTL15min desde su creación; expiración/evicción o reinicio del servidor puede dejar una referencia indisponible yse informa sin volver a ejecutar Counting. La historia/resultados aceptados siguen disponibles. GET de página ylegacy /step no agregan llamadas al main ni entradas dehistorial.

Integración verificada en35IDs locales ydos casos browser k1000000/n2,n80; el método permanece parcial para auditoría global, pendientes oráculosC completos fuera4 yfault probes. No demuestra todoslos caminos ni C32bit. Evidencia: openspec/changes/audit-local-quality-and-unified-controls/evidence/visible-sorting-counting-integration/README.md. Los apartados anteriores fechados se conservan como historia, no como estado vigente.


### Counting: verificación posterior de oráculos yfallos (2026-10-02)

La evidenciaLOW posterior completa ocho oráculosC fuera4 yverifica losmáximos mediante digeststreaming con muestras; checksum dearrays/frecuencias tiene límite decolisiones yno acredita todoslosinputs. Fallos de reserva simulada yalmacén devuelven400/estado/historial/mainprevios; un fallo de página noavanza cursor ySiguiente reintenta la misma instrucción. Respuestas detracesanteriores en vuelo no sustituyen unanueva. Counting sigueparcial: la respuesta deerror controlada noexpone todavía su traza didáctica deguardas/retornoC. MEDIUM delimitado en sorting-counting-error-instruction-gap-low.md; evidencia visible-sorting-counting-native-fault-low. Las notas de pendientes anteriores se conservan como fotografía fechada, no estado vigente.


### Counting: inspeccionar una llamada fallida (2026-10-02T19:57:09.908110+00:00)

Si el rango se rechaza, Counting conserva el arreglo aceptado, el historial y el main. La traza permite recorrer la guarda verdadera y el retorno ORDENAMIENTO_ERROR (0), con los parámetros y locales retirados. El aviso identifica que se está viendo una llamada fallida. La exportación JSON separa el estado aceptado del estado de ese intento; navegar o recargar no ejecuta otra llamada.

La reservaNULL de QA usa una inyección aislada y lleva el rótulo «Fallo simulado de calloc»; no representa agotamiento real de memoria. Un fallo del modelo Python se identifica por separado y no afirma ejecutar el allocator C. Los fallos de transporte/almacenamiento de la traza tampoco se presentan como un retorno nativo.

Los caminos/casos de error registrados están verificados; no es certificación exhaustiva de toda entrada, plataforma32bit ni OOMglobal. Evidencia y alcance: openspec/changes/audit-local-quality-and-unified-controls/sorting-counting-error-instructions-checkpoint.md. Los checkpoints anteriores se conservan como fotografías fechadas.


### Counting: revisión consolidada (2026-10-02T20:08:31.886208+00:00)

Counting queda verificado en el dominio UI de1..80 enterosint32 sobre el entorno size_t64 observado: conserva instrucciones para rangos de éxito hasta1000000, con transporte denso o paginado según presupuesto. El corte antiguo de cuatro valores/rango cuatro está retirado. La representación dispersa conserva ceros implícitos y cada control de bucket vacío; el rechazo de rango y la reservaNULL controlada permiten inspeccionar la llamada fallida sin alterar el estado aceptado.

Este es el noveno método de once bajo alcance y casos explícitos; Binsort y Radix permanecen pendientes. No es prueba exhaustiva de entradas, soporte32bit ni recuperación de OOMglobal; los fallos de reserva usados en QA se identifican como simulados. Decisión y trazabilidad: openspec/changes/audit-local-quality-and-unified-controls/sorting-counting-consolidated-closure-decision.md. Las declaracionesPARCIAL anteriores permanecen como fotografías históricas y quedan superadas por esta revisión.


### Binsort: baseline y frontera de fidelidad (2026-10-02T20:48:10.676126+00:00)
Binsort en este TAD devuelve el resultado de Counting Sort; no implementa buckets independientes. UI admite1..80enterosint32 yhereda rango máximo1000000, con rechazo superior. El baseline confirma resultados y métricasC para ocho entradas, incluidasn80 yrangosmayoresque4. Comparaciones son2(n-1) y movimientos3n; el códigoC del método no imprime mensajes. El main conserva ejecuciones repetidas yexcluye fallos; rápido→pasos conserva la misma traza.
La traza actual deBinsort sigue agregada: helper/scopes/guardas/free yretornos completos están pendientes. Tambiénretiene frecuenciasporframe; no se ha certificado una ejecuciónAPIcompleta del límite1m yla correcciónsparse requiereMEDIUM, sinreducireldominio admitido. Cnative límite síverificado ensize_t64seguro. Unfallode reserva del modeloPython se distingue de unfallo realC; QAcallocNULL es inyecciónaislada, noOOMglobal.
Estado:baselineLOWcompleto, Bin/Radixinstrucciónpendiente yCounting9/11vigente. Fuentes: openspec/changes/audit-local-quality-and-unified-controls/sorting-binsort-baseline-checkpoint-low.md ysorting-binsort-instruction-review-plan.md.


## Hash H1: creación e inserción, actualización 2026-10-02

Para estas dos operaciones Hash, este apartado sustituye las indicaciones históricas de 5.1: Ejecutar operación crea una ejecución; Paso a paso permite revisar la misma traza con Paso anterior y Siguiente paso. Cerrar y reactivar el modo, navegar y recargar conservan la ejecución sin enviar otra operación. Reiniciar borra su estado/traza. Cinco secciones organizan los datos, visualización, código, explicación y resultados.

La capacidad es fija y acepta colisiones/carga mayor que1 sin resize. Actualizar una clave conserva cantidad y no reserva un nodo. Las variables tipadas y máscaras muestran los campos aún indeterminados; después de publicar la cabecera puede estar pendiente cantidad++. Las identidades de memoria son simbólicas dentro de la operación.

Descargar main.c reproduce el historial mutante confirmado, incluidas llamadas iguales consecutivas; informa resultados C calculados y libera memoria también ante fallos de reserva. No incluye consultas ni operaciones rechazadas. La consola de la traza del TAD permanece sin printf porque estas funciones C no imprimen; los mensajes del caller son salida de ese programa independiente. Véase [guía de creación/inserción Hash](qa/hash-creation-insertion-guide.md) para ownership, errores y límites verificados.


## Consultas Hash: checkpoint MEDIUM

Get ausente responde HTTP400; contains ausente retorna false. Las consultas observadas se conservan para main.c en un journal separado del historial mutante. Scopes, salida y replay: [guía de consultas](qa/hash-query-guide.md). Retención y recursos arbitrarios siguen sin certificar.


## Remove Hash: instrucciones y memoria

La traza distingue desvincular, free y cantidad--. Tras free conserva identidad histórica con valor de puntero/campos indeterminados y no utilizables; JSONnull no simula asignaciónNULL de C. Reproducción no vuelve a eliminar. [Guía técnica remove](qa/hash-remove-guide.md), casos finitos/límites; checkpointMEDIUM pendiente revisiónLOW.


### Listados Hash: proyección API y texto C

Las consultas keys/values/items muestran la proyección API por separado del texto de th_formatear. El panel C incluye el helper real, scopes y buffer con bytes indeterminados; retroceder reproduce frames sin enviar otra consulta. Las consultas repetidas quedan en el caller descargado tras recarga. Véase [guía de listados Hash](qa/hash-listings-guide.md) para el alcance finito y las guardas de truncamiento.


### Stats Hash: cálculo C y cociente API

La traza muestra los cuerpos C reales, dos invocaciones y copias distintas de THEstadisticas, y el buffer acotado. El panel separa float C del cociente API existente y de sus formatos; el caller conserva consultas repetidas y calcula ambas representaciones. Véase [guía stats Hash](qa/hash-stats-guide.md) para el alcance registrado y sus límites.


### Hash: vida de memoria al vaciar y destruir

Vaciar conserva capacidad y buckets; destruir libera también ese array, pero el objeto TablaHash sigue vivo. La traza distingue free, puntero indeterminado y escritura NULL; la cantidad sólo cambia al ejecutar su store C. El replay muestra los cinco paneles sin repetir la operación. Véase [guía de vaciado y destrucción](qa/hash-clear-destroy-guide.md) para límites y estados intermedios.


### Validar Rojo-Negro completo (contrato V3 aprobado, 2026-10-03)

La consulta utiliza `int rbt_validar(RBT raiz)` del TAD descargable y devuelve
1/True sólo si cumple las cinco reglas RN: colores rojo/negro, raíz negra,
hojas conceptuales NULL negras, ausencia de rojo-rojo y altura negra uniforme.
También exige orden ABB estricto sin duplicados, padre de raíz NULL y enlaces
por identidad sin ciclos ni nodos compartidos. Valida el modelo nativo original;
la vista NIL reconstruida es presentación y no corrige ni valida los padres.

NULL es válido y su altura negra interna vale 1. Las cotas opcionales no usan
INT_MIN/INT_MAX como centinelas ni suman/restan uno a las claves. La suma de
altura negra tiene guarda de overflow. Todas las referencias no NULL examinadas
deben ser objetos vivos y legibles: no se inspeccionan punteros colgantes.
El validador no modifica, reserva, libera, imprime ni repara; False/0 es un
resultado de consulta exitosamente ejecutada, no un error HTTP.

El main llama a la función pública y calcula su salida; no la redefine.
Los auxiliares Inorden y Altura siguen perteneciendo a la aplicación/main.
El caller conserva la propiedad del árbol y lo libera fuera del historial.
El rebalanceo puede infringir propiedades temporalmente: las invariantes se
exigen al terminar inserciones/eliminaciones completas desde un árbol válido,
no después de una rotación aislada. La traza muestra los frames nativos,
cotas, padre esperado, alturas de hijos y retornos sin fabricar mutaciones.
