#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tad_cola_prioridad.h"
struct cp_nodo {
    int valor; /**< Dato almacenado. */
    int prioridad; /**< Prioridad del elemento. */
    struct cp_nodo *sgte; /**< Enlace al siguiente nodo. */
};
_Static_assert(_Generic(&cp_vaciar,void(*)(ColaPrioridad*):1,default:0),"destructor signature");
static void*obj[64];static int alive[64],used,allocs,frees,active,sid,target_free,aux_init,aux_valid,aux_id,next_init,next_valid,next_id;
static int id(void*p){if(!p)return -1;for(int j=0;j<used;j++)if(alive[j]&&obj[j]==p)return j;assert(0);return -1;}
void*qa_malloc(size_t size){void*p=malloc(size);assert(p&&used<64);obj[used]=p;alive[used++]=1;allocs++;return p;}
void qa_free(void*p){if(!p)return;int j=id(p);if(active){assert(aux_valid&&aux_id==j);aux_valid=aux_init=0;target_free++;}alive[j]=0;obj[j]=NULL;frees++;free(p);}
void qa_aux(CPNodo*p){if(active){aux_init=aux_valid=1;aux_id=id(p);}}
void qa_next(CPNodo*p){if(active){next_init=next_valid=1;next_id=id(p);}}
void qa_event(const char*e,ColaPrioridad*q,int condition){if(!active)return;
 printf("{\"sample\":%d,\"event\":\"%s\",\"condition\":%d,\"root_argument_NULL\":%d,\"quantity\":%d,\"aux_initialized\":%d,\"aux_valid\":%d,\"aux_id\":%d,\"next_initialized\":%d,\"next_valid\":%d,\"next_id\":%d,\"rear_id\":%d,\"frees\":%d,\"root_ids\":[",sid,e,condition,q==NULL,q?q->cantidad:-1,aux_init,aux_valid,aux_valid?aux_id:-1,next_init,next_valid,next_valid?next_id:-1,q?id(q->atras):-1,target_free);
 CPNodo*n=q?q->delante:NULL;int comma=0;while(n){if(comma++)putchar(',');int j=id(n);printf("%d",j);n=n->sgte;}fputs("],\"root_values\":[",stdout);n=q?q->delante:NULL;comma=0;while(n){assert(id(n)>=0);if(comma++)putchar(',');printf("%d",n->valor);n=n->sgte;}fputs("],\"root_priorities\":[",stdout);n=q?q->delante:NULL;comma=0;while(n){assert(id(n)>=0);if(comma++)putchar(',');printf("%d",n->prioridad);n=n->sgte;}fputs("],\"live\":[",stdout);comma=0;for(int j=0;j<used;j++)if(alive[j]){if(comma++)putchar(',');CPNodo*n=obj[j];printf("{\"id\":%d,\"value\":%d,\"priority\":%d,\"next_id\":%d}",j,n->valor,n->prioridad,id(n->sgte));}puts("]}");}
int qa_guard(const char*e,ColaPrioridad*q,int value){qa_event(e,q,value);return value;}
static void sample(ColaPrioridad*q){target_free=aux_init=aux_valid=next_init=next_valid=0;aux_id=next_id=-1;active=1;cp_vaciar(q);active=0;sid++;}
int main(void){{ColaPrioridad p;cp_inicializar(&p);sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);cp_vaciar(&p);}{ColaPrioridad p;cp_inicializar(&p);assert(cp_encolar(&p,-1,2));sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);cp_vaciar(&p);}{ColaPrioridad p;cp_inicializar(&p);assert(cp_encolar(&p,7,3));assert(cp_encolar(&p,-2,1));assert(cp_encolar(&p,7,1));sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);cp_vaciar(&p);}{ColaPrioridad p;cp_inicializar(&p);assert(cp_encolar(&p,7,3));assert(cp_encolar(&p,-2,1));assert(cp_encolar(&p,7,1));sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);assert(cp_encolar(&p,8,-1));sample(&p);assert(p.delante==NULL&&p.atras==NULL&&p.cantidad==0);cp_vaciar(&p);}sample(NULL);assert(allocs==frees);for(int j=0;j<used;j++)assert(!alive[j]);fprintf(stderr,"OWNERSHIP %d %d 0\n",allocs,frees);return 0;}