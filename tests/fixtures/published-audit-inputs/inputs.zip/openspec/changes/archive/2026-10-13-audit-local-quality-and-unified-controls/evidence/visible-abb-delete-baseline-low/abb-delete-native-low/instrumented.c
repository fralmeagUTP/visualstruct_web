/**
 * @file tad_abb.c
 * @brief Implementación de un Árbol Binario de Búsqueda (ABB) en C estándar.
 */

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#ifdef _WIN32
#include <windows.h>
#endif

/**
 * @struct ABBNodo
 * @brief Estructura para un nodo del árbol binario de búsqueda.
 */
typedef struct ABBNodo {
    int valor; /**< Dato almacenado. */
    struct ABBNodo* izquierdo; /**< Hijo izquierdo; NULL si no existe. */
    struct ABBNodo* derecho; /**< Hijo derecho; NULL si no existe. */
} ABBNodo; /**< Alias del nodo del árbol binario. */

/**
 * @brief Inserta un valor en el árbol binario de búsqueda.
 * @param nodo Puntero a la raíz del árbol.
 * @param valor Valor entero.
 * @return Raíz actualizada; NULL si el árbol estaba vacío y malloc falla.
 * @note Si falla la reserva en un subárbol, se conserva la raíz existente sin insertar el valor.
  * @note El arbol debe ser un ABB valido y aciclico. Un duplicado conserva la misma raiz sin reservar otro nodo. Asigne el retorno a la raiz del llamador; los enlaces internos se modifican. El nuevo nodo se inicializa antes de enlazarlo.
 */

#include <stdarg.h>
#include <stdint.h>
static ABBNodo *audit_nodes[128];static int audit_live[128],audit_mask[128],audit_left[128],audit_right[128],audit_root_id,audit_count,audit_depth=-1,audit_case,audit_active;
static const char *audit_function[128];static int audit_alias[128][3],audit_arg[128],audit_low[128],audit_high[128];static int audit_local_state[128][2],audit_local_value[128][2];static int audit_operand_state[128][2],audit_operand_value[128][2];static char audit_console[8192];static int audit_console_size;
static int audit_id(const ABBNodo*p){if(!p)return 0;for(int i=0;i<audit_count;i++)if(audit_live[i]&&audit_nodes[i]==p)return i+1;return -1;}
static void audit_register(ABBNodo*p){if(p){int i=audit_count++;audit_nodes[i]=p;audit_live[i]=1;audit_mask[i]=0;}}
static void audit_mark(ABBNodo*p,int mask){int id=audit_id(p);if(id>0){audit_mask[id-1]|=mask;if(mask&2)audit_left[id-1]=audit_id(p->izquierdo);if(mask&4)audit_right[id-1]=audit_id(p->derecho);}}
static void audit_enter(const char*fn,ABBNodo*nodo,int arg,int low,int high){audit_depth++;audit_operand_state[audit_depth][0]=audit_operand_state[audit_depth][1]=0;audit_local_state[audit_depth][0]=audit_local_state[audit_depth][1]=0;audit_function[audit_depth]=fn;audit_alias[audit_depth][0]=audit_id(nodo);audit_alias[audit_depth][1]=-2;audit_alias[audit_depth][2]=-2;audit_arg[audit_depth]=arg;audit_low[audit_depth]=low;audit_high[audit_depth]=high;}
static void audit_retire(int id){if(id>0){audit_live[id-1]=0;if(audit_root_id==id)audit_root_id=-100-id;for(int f=0;f<=audit_depth;f++)for(int k=0;k<3;k++)if(audit_alias[f][k]==id)audit_alias[f][k]=-100-id;}}
static int audit_printf(const char*fmt,...){va_list args;va_start(args,fmt);int n=vsnprintf(audit_console+audit_console_size,sizeof(audit_console)-(size_t)audit_console_size,fmt,args);va_end(args);audit_console_size+=n;return n;}
static void audit_emit(int line,const char*phase,int result){if(!audit_active)return;
 printf("AUDIT {\"case\":%d,\"line\":%d,\"phase\":\"%s\",\"result\":%d,\"root\":%d,\"frames\":[",audit_case,line,phase,result,audit_root_id);
 for(int f=0;f<=audit_depth;f++){if(f)printf(",");printf("{\"function\":\"%s\",\"nodo\":%d,\"nuevo\":%d,\"temp\":%d,\"arg\":%d,\"low\":%d,\"high\":%d,\"height_locals\":[[%d,%d],[%d,%d]],\"leaf_operands\":[[%d,%d],[%d,%d]]}",audit_function[f],audit_alias[f][0],audit_alias[f][1],audit_alias[f][2],audit_arg[f],audit_low[f],audit_high[f],audit_local_state[f][0],audit_local_state[f][0]==2?audit_local_value[f][0]:0,audit_local_state[f][1],audit_local_state[f][1]==2?audit_local_value[f][1]:0,audit_operand_state[f][0],audit_operand_state[f][0]==2?audit_operand_value[f][0]:0,audit_operand_state[f][1],audit_operand_state[f][1]==2?audit_operand_value[f][1]:0);}
 printf("],\"nodes\":[");int printed=0;
 for(int i=0;i<audit_count;i++)if(audit_live[i]){if(printed++)printf(",");ABBNodo*p=audit_nodes[i];printf("{\"id\":%d,\"mask\":%d,\"value\":%d,\"left\":%d,\"right\":%d}",i+1,audit_mask[i],audit_mask[i]&1?p->valor:0,audit_mask[i]&2?audit_left[i]:-2,audit_mask[i]&4?audit_right[i]:-2);}
 printf("],\"console_hex\":\"");for(int i=0;i<audit_console_size;i++)printf("%02x",(unsigned char)audit_console[i]);printf("\"}\n");
}
static int audit_condition(int line,int value){audit_emit(line,"condition",value);return value;}
/* Observer-only wrapper: each operand call remains indeterminately sequenced
   relative to the other; original pure C helper and sum are not reordered. */
int abb_contarHojas(ABBNodo* nodo);
static int audit_leaf_operand(ABBNodo*nodo,int line,int side){
 int parent=audit_depth;audit_operand_state[parent][side]=1;
 audit_emit(line,side==0?"call_left":"call_right",-2);
 int result=abb_contarHojas(nodo);
 audit_operand_state[parent][side]=2;audit_operand_value[parent][side]=result;
 audit_emit(line,side==0?"operand_left":"operand_right",result);return result;
}


#define printf audit_printf
ABBNodo* abb_insertar(ABBNodo* nodo, int valor) {audit_enter("abb_insertar",nodo,valor,0,0);audit_emit(31,"enter",-2);
if(audit_condition(32,(nodo == NULL))){{
ABBNodo * nuevo = malloc ( sizeof * nuevo ) ;audit_register(nuevo);audit_alias[audit_depth][1]=audit_id(nuevo);audit_emit(33,"after",-2);
if(audit_condition(34,(nuevo == NULL))){{
{ABBNodo* audit_result=NULL;audit_emit(35,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}}
nuevo -> valor = valor ;audit_mark(nuevo,1);audit_emit(37,"after",-2);
nuevo -> izquierdo = nuevo -> derecho = NULL ;audit_mark(nuevo,2);audit_mark(nuevo,6);audit_emit(38,"after",-2);
{ABBNodo* audit_result=nuevo;audit_emit(39,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}}
if(audit_condition(41,(valor < nodo -> valor))){audit_emit(42,"call",-2);nodo -> izquierdo = abb_insertar ( nodo -> izquierdo , valor ) ;audit_mark(nodo,2);audit_emit(42,"after",-2);}else{if(audit_condition(43,(valor > nodo -> valor))){audit_emit(44,"call",-2);nodo -> derecho = abb_insertar ( nodo -> derecho , valor ) ;audit_mark(nodo,4);audit_emit(44,"after",-2);}}
{ABBNodo* audit_result=nodo;audit_emit(45,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}

/**
 * @brief Busca un valor en el árbol binario de búsqueda.
 * @param nodo Puntero a la raíz del árbol.
 * @param valor Valor entero.
 * @return Puntero al nodo encontrado o NULL si no existe.
  * @note Consulta sin mutacion. El retorno es un alias prestado de un nodo existente, no una copia ni una reserva nueva. NULL tambien representa un arbol vacio.
 */
ABBNodo* abb_buscar(ABBNodo* nodo, int valor) {audit_enter("abb_buscar",nodo,valor,0,0);audit_emit(55,"enter",-2);
if(audit_condition(56,(nodo == NULL || nodo -> valor == valor))){{ABBNodo* audit_result=nodo;audit_emit(57,"return",audit_id(audit_result));audit_depth--;return audit_result;}}
if(audit_condition(58,(valor < nodo -> valor))){{audit_emit(59,"call",-2);ABBNodo* audit_result=abb_buscar ( nodo -> izquierdo , valor );audit_emit(59,"return",audit_id(audit_result));audit_depth--;return audit_result;}}else{{audit_emit(61,"call",-2);ABBNodo* audit_result=abb_buscar ( nodo -> derecho , valor );audit_emit(61,"return",audit_id(audit_result));audit_depth--;return audit_result;}}
}

/**
 * @brief Encuentra el nodo con el valor mínimo en el árbol.
 * @param nodo Puntero a la raíz del árbol.
 * @return Puntero al nodo con el valor mínimo, o NULL si el árbol está vacío.
  * @note Consulta sin mutacion: sigue enlaces izquierdos y retorna un alias prestado, no una reserva nueva. NULL representa el arbol vacio.
 */
ABBNodo* abb_encontrarMinimo(ABBNodo* nodo) {audit_enter("abb_encontrarMinimo",nodo,0,0,0);audit_emit(70,"enter",-2);
if(audit_condition(71,(nodo == NULL))){{
{ABBNodo* audit_result=NULL;audit_emit(72,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}}
while(audit_condition(75,(nodo -> izquierdo != NULL))){nodo = nodo -> izquierdo ;audit_alias[audit_depth][0]=audit_id(nodo);audit_emit(76,"after",-2);}
{ABBNodo* audit_result=nodo;audit_emit(77,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}

/**
 * @brief Encuentra el nodo con el valor máximo en el árbol.
 * @param nodo Puntero a la raíz del árbol.
 * @return Puntero al nodo con el valor máximo, o NULL si el árbol está vacío.
  * @note Consulta sin mutacion: sigue enlaces derechos y retorna un alias prestado, no una reserva nueva. NULL representa el arbol vacio.
 */
ABBNodo* abb_encontrarMaximo(ABBNodo* nodo) {audit_enter("abb_encontrarMaximo",nodo,0,0,0);audit_emit(86,"enter",-2);
while(audit_condition(87,(nodo != NULL && nodo -> derecho != NULL))){nodo = nodo -> derecho ;audit_alias[audit_depth][0]=audit_id(nodo);audit_emit(88,"after",-2);}
{ABBNodo* audit_result=nodo;audit_emit(89,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}

/**
 * @brief Elimina un valor del árbol binario de búsqueda.
 * @param nodo Puntero a la raíz del árbol.
 * @param valor Valor entero.
 * @return Puntero a la raíz actualizada.
  * @note Un valor ausente conserva la raiz. Asigne el retorno a la raiz del llamador. Con cero o un hijo se libera el nodo encontrado y se retorna el reemplazo. Con dos hijos se copia el valor del sucesor, se conserva la reserva del nodo encontrado y se elimina el sucesor. Los alias al nodo liberado dejan de ser validos.
 */
ABBNodo* abb_eliminar(ABBNodo* nodo, int valor) {audit_enter("abb_eliminar",nodo,valor,0,0);audit_emit(99,"enter",-2);
if(audit_condition(100,(nodo == NULL))){{ABBNodo* audit_result=nodo;audit_emit(100,"return",audit_id(audit_result));audit_depth--;return audit_result;}}
if(audit_condition(101,(valor < nodo -> valor))){audit_emit(102,"call",-2);nodo -> izquierdo = abb_eliminar ( nodo -> izquierdo , valor ) ;audit_mark(nodo,2);audit_emit(102,"after",-2);}else{if(audit_condition(103,(valor > nodo -> valor))){audit_emit(104,"call",-2);nodo -> derecho = abb_eliminar ( nodo -> derecho , valor ) ;audit_mark(nodo,4);audit_emit(104,"after",-2);}else{{
if(audit_condition(106,(nodo -> izquierdo == NULL))){{
ABBNodo * temp = nodo -> derecho ;audit_alias[audit_depth][2]=audit_id(temp);audit_emit(107,"after",-2);
{int audit_freed=audit_id(nodo);free ( nodo ) ;audit_retire(audit_freed);audit_emit(108,"after",-2);}
{ABBNodo* audit_result=temp;audit_emit(109,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}}else{if(audit_condition(110,(nodo -> derecho == NULL))){{
ABBNodo * temp = nodo -> izquierdo ;audit_alias[audit_depth][2]=audit_id(temp);audit_emit(111,"after",-2);
{int audit_freed=audit_id(nodo);free ( nodo ) ;audit_retire(audit_freed);audit_emit(112,"after",-2);}
{ABBNodo* audit_result=temp;audit_emit(113,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}}}
audit_emit(115,"call",-2);ABBNodo * temp = abb_encontrarMinimo ( nodo -> derecho ) ;audit_alias[audit_depth][2]=audit_id(temp);audit_emit(115,"after",-2);
nodo -> valor = temp -> valor ;audit_mark(nodo,1);audit_emit(116,"after",-2);
audit_emit(117,"call",-2);nodo -> derecho = abb_eliminar ( nodo -> derecho , temp -> valor ) ;audit_mark(nodo,4);audit_emit(117,"after",-2);
}}}
{ABBNodo* audit_result=nodo;audit_emit(119,"return",audit_id(audit_result));audit_depth--;return audit_result;}
}

/**
 * @brief Realiza un recorrido preorden del árbol.
 * @param nodo Puntero a la raíz del árbol.
  * @note Imprime raiz, izquierdo y derecho en stdout con formato "%d " por nodo, incluido el espacio final y sin agregar salto de linea. NULL no imprime nada. No modifica enlaces ni reserva memoria.
 */
void abb_preorden(ABBNodo* nodo) {audit_enter("abb_preorden",nodo,0,0,0);audit_emit(127,"enter",-2);
if(audit_condition(128,(nodo != NULL))){{
printf ( "%d " , nodo -> valor ) ;audit_emit(129,"after",-2);
audit_emit(130,"call",-2);abb_preorden ( nodo -> izquierdo ) ;audit_emit(130,"after",-2);
audit_emit(131,"call",-2);abb_preorden ( nodo -> derecho ) ;audit_emit(131,"after",-2);
}}
audit_emit(133,"return",-2);audit_depth--;}

/**
 * @brief Realiza un recorrido inorden del árbol.
 * @param nodo Puntero a la raíz del árbol.
  * @note Imprime izquierdo, raiz y derecho en stdout con formato "%d " por nodo, incluido el espacio final y sin agregar salto de linea. NULL no imprime nada. No modifica enlaces ni reserva memoria.
 */
void abb_inorden(ABBNodo* nodo) {audit_enter("abb_inorden",nodo,0,0,0);audit_emit(140,"enter",-2);
if(audit_condition(141,(nodo != NULL))){{
audit_emit(142,"call",-2);abb_inorden ( nodo -> izquierdo ) ;audit_emit(142,"after",-2);
printf ( "%d " , nodo -> valor ) ;audit_emit(143,"after",-2);
audit_emit(144,"call",-2);abb_inorden ( nodo -> derecho ) ;audit_emit(144,"after",-2);
}}
audit_emit(146,"return",-2);audit_depth--;}

/**
 * @brief Realiza un recorrido postorden del árbol.
 * @param nodo Puntero a la raíz del árbol.
  * @note Imprime izquierdo, derecho y raiz en stdout con formato "%d " por nodo, incluido el espacio final y sin agregar salto de linea. NULL no imprime nada. No modifica enlaces ni reserva memoria.
 */
void abb_postorden(ABBNodo* nodo) {audit_enter("abb_postorden",nodo,0,0,0);audit_emit(153,"enter",-2);
if(audit_condition(154,(nodo != NULL))){{
audit_emit(155,"call",-2);abb_postorden ( nodo -> izquierdo ) ;audit_emit(155,"after",-2);
audit_emit(156,"call",-2);abb_postorden ( nodo -> derecho ) ;audit_emit(156,"after",-2);
printf ( "%d " , nodo -> valor ) ;audit_emit(157,"after",-2);
}}
audit_emit(159,"return",-2);audit_depth--;}

/**
 * @brief Libera toda la memoria del árbol (abb_postorden).
 * @param nodo Raíz del árbol o subárbol a liberar.
  * @note Libera cada nodo en orden izquierdo, derecho y raiz; NULL no hace nada. El parametro se recibe por valor: no pone a NULL la raiz del llamador. Despues de la llamada, asigne NULL a esa raiz y no use los alias a las reservas liberadas.
 */
void abb_liberarArbol(ABBNodo* nodo) {audit_enter("abb_liberarArbol",nodo,0,0,0);audit_emit(166,"enter",-2);
if(audit_condition(167,(nodo == NULL))){audit_emit(167,"return",-2);audit_depth--;return;}
audit_emit(168,"call",-2);abb_liberarArbol ( nodo -> izquierdo ) ;audit_emit(168,"after",-2);
audit_emit(169,"call",-2);abb_liberarArbol ( nodo -> derecho ) ;audit_emit(169,"after",-2);
{int audit_freed=audit_id(nodo);free ( nodo ) ;audit_retire(audit_freed);audit_emit(170,"after",-2);}
audit_emit(171,"return",-2);audit_depth--;}

/**
 * @brief Muestra el árbol en forma jerárquica.
 * @param nodo Puntero a la raíz del árbol.
 * @param espacio Espacio de indentación para la visualización.
  * @note Imprime primero el subarbol derecho, luego el valor y luego el izquierdo. En cada nivel aumenta espacio en cinco y emite saltos de linea; NULL no imprime. No modifica el arbol. Para la presentacion habitual use espacio igual a cero.
 */
void abb_mostrarArbol(ABBNodo* nodo, int espacio) {
	int i;
    if (nodo == NULL) return;
    espacio += 5;
    abb_mostrarArbol(nodo->derecho, espacio);
    printf("\n");
    for (i = 5; i < espacio; i++) printf(" ");
    printf("%d\n", nodo->valor);
    abb_mostrarArbol(nodo->izquierdo, espacio);
}

/**
 * @brief Calcula la abb_altura del árbol binario de búsqueda.
 * @param nodo Puntero a la raíz del árbol.
 * @return Altura del árbol (número de niveles).
  * @note Cuenta niveles: NULL retorna cero y una hoja retorna uno. No cuenta aristas, no modifica el arbol y recorre ambos subarboles.
 */
int abb_altura(ABBNodo* nodo) {audit_enter("abb_altura",nodo,0,0,0);audit_emit(196,"enter",-2);
if(audit_condition(197,(nodo == NULL))){{int audit_result=0;audit_emit(198,"return",audit_result);audit_depth--;return audit_result;}}
int altIzq=(audit_local_state[audit_depth][0]=1,audit_emit(199,"call",-2),abb_altura ( nodo -> izquierdo ));audit_local_value[audit_depth][0]=altIzq;audit_local_state[audit_depth][0]=2;audit_emit(199,"after",-2);
int altDer=(audit_local_state[audit_depth][1]=1,audit_emit(200,"call",-2),abb_altura ( nodo -> derecho ));audit_local_value[audit_depth][1]=altDer;audit_local_state[audit_depth][1]=2;audit_emit(200,"after",-2);
{int audit_result=( audit_condition(201,altIzq > altDer) ? altIzq : altDer ) + 1;audit_emit(201,"return",audit_result);audit_depth--;return audit_result;}
}

/**
 * @brief Cuenta la cantidad de niveles (profundidad) de un árbol binario de búsqueda.
 * @param nodo Puntero a la raíz del árbol.
 * @return Número de niveles del árbol (0 si está vacío).
  * @note Retorna el mismo numero de niveles que abb_altura: cero para NULL y uno para una hoja. No modifica el arbol.
 */
int abb_contarNiveles(ABBNodo* nodo) {
    if (nodo == NULL)
        return 0;
    int nivelesIzq = abb_contarNiveles(nodo->izquierdo);
    int nivelesDer = abb_contarNiveles(nodo->derecho);
    return (nivelesIzq > nivelesDer ? nivelesIzq : nivelesDer) + 1;
}


/**
 * @brief Cuenta hojas sin modificar el arbol ni imprimir.
 * @param nodo Raiz prestada del subarbol, o NULL.
 * @return 0 para NULL, 1 para una hoja, o la suma de ambos subarboles.
 * @note Helper mostrado por la aplicacion; no incluido en el C/H descargado.
 * C no fija el orden de evaluacion de las dos llamadas sumadas.
 * No declara locales para sus resultados parciales; son operandos de la expresion.
 * Tiempo O(n), pila recursiva O(h); no reserva ni libera nodos.
 */
int abb_contarHojas(ABBNodo* nodo) {audit_enter("abb_contarHojas",nodo,0,0,0);audit_emit(228,"enter",-2);
if(audit_condition(229,(nodo == NULL))){{
{int audit_result=0;audit_emit(230,"return",audit_result);audit_depth--;return audit_result;}
}}
if(audit_condition(232,(nodo -> izquierdo == NULL && nodo -> derecho == NULL))){{
{int audit_result=1;audit_emit(233,"return",audit_result);audit_depth--;return audit_result;}
}}
{int audit_result=audit_leaf_operand(nodo->izquierdo,235,0) + audit_leaf_operand(nodo->derecho,235,1);audit_emit(235,"return",audit_result);audit_depth--;return audit_result;}
}
int abb_validar_rango(ABBNodo* nodo, int minimo, int maximo) {audit_enter("abb_validar_rango",nodo,0,minimo,maximo);audit_emit(237,"enter",-2);
if(audit_condition(238,(nodo == NULL))){{
{int audit_result=1;audit_emit(239,"return",audit_result);audit_depth--;return audit_result;}
}}
if(audit_condition(241,(nodo -> valor <= minimo || nodo -> valor >= maximo))){{
{int audit_result=0;audit_emit(242,"return",audit_result);audit_depth--;return audit_result;}
}}
if(audit_condition(244,(! abb_validar_rango ( nodo -> izquierdo , minimo , nodo -> valor )))){{
{int audit_result=0;audit_emit(245,"return",audit_result);audit_depth--;return audit_result;}
}}
if(audit_condition(247,(! abb_validar_rango ( nodo -> derecho , nodo -> valor , maximo )))){{
{int audit_result=0;audit_emit(248,"return",audit_result);audit_depth--;return audit_result;}
}}
{int audit_result=1;audit_emit(250,"return",audit_result);audit_depth--;return audit_result;}
}

#undef printf

int main(void){ABBNodo*root=NULL;
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
audit_root_id=audit_id(root);audit_active=1;audit_case=0;
root=abb_eliminar(root,7);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,7);
audit_root_id=audit_id(root);audit_active=1;audit_case=1;
root=abb_eliminar(root,7);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,7);
audit_root_id=audit_id(root);audit_active=1;audit_case=2;
root=abb_eliminar(root,9);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,15);
audit_root_id=audit_id(root);audit_active=1;audit_case=3;
root=abb_eliminar(root,5);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,15);
audit_root_id=audit_id(root);audit_active=1;audit_case=4;
root=abb_eliminar(root,15);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,15);
audit_root_id=audit_id(root);audit_active=1;audit_case=5;
root=abb_eliminar(root,10);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,3);
audit_root_id=audit_id(root);audit_active=1;audit_case=6;
root=abb_eliminar(root,5);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,7);
audit_root_id=audit_id(root);audit_active=1;audit_case=7;
root=abb_eliminar(root,5);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,20);
root=abb_insertar(root,15);
root=abb_insertar(root,25);
root=abb_insertar(root,12);
root=abb_insertar(root,17);
root=abb_insertar(root,13);
audit_root_id=audit_id(root);audit_active=1;audit_case=8;
root=abb_eliminar(root,10);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,20);
root=abb_insertar(root,15);
root=abb_insertar(root,25);
root=abb_insertar(root,12);
root=abb_insertar(root,17);
root=abb_insertar(root,13);
audit_root_id=audit_id(root);audit_active=1;audit_case=9;
root=abb_eliminar(root,20);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
audit_active=0;root=NULL;audit_count=0;audit_depth=-1;audit_console_size=0;
root=abb_insertar(root,10);
root=abb_insertar(root,5);
root=abb_insertar(root,15);
audit_root_id=audit_id(root);audit_active=1;audit_case=10;
root=abb_eliminar(root,99);
audit_root_id=audit_id(root);audit_emit(0,"caller",audit_root_id);
audit_active=0;abb_liberarArbol(root);
return 0;}