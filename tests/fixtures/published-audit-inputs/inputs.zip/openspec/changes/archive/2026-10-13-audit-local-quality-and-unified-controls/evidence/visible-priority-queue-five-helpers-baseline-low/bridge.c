
#include <limits.h>
#include <string.h>
#include "tad_cola_prioridad.c"
int audit_allocations=0, audit_frees=0;
/* All native fixtures use automatic borrowed nodes; target helpers allocate nothing. */
int audit_target(int method,int mode,int n,int count,const int *vals,const int *pris,int cap,int nv,int np,int *ov,int *op,char *text,int *readonly) {
 CPNodo nodes[4]; CPNodo saved[4]; ColaPrioridad q; ColaPrioridad before;
 int result=0;
 if(n<0 || n>4) return -99;
 for(int i=0;i<n;i++){nodes[i].valor=vals[i];nodes[i].prioridad=pris[i];nodes[i].sgte=i+1<n?&nodes[i+1]:NULL;}
 /* mode 0 normal, 1 NULL queue, 2 front-only, 3 rear-only. */
 if(method==0 && mode==4) {
  /* q fields are uninitialized: NEVER read them before cp_inicializar writes. */
  cp_inicializar(&q); ov[0]=q.delante==NULL;ov[1]=q.atras==NULL;ov[2]=q.cantidad;*readonly=1;return 0;
 }
 q.delante=n && mode!=3 ? &nodes[0]:NULL;q.atras=n && mode!=2 ? &nodes[n-1]:NULL;q.cantidad=count;
 before=q;for(int i=0;i<n;i++)saved[i]=nodes[i];
 ColaPrioridad *arg=mode==1?NULL:&q;
 switch(method) {
 case 0: cp_inicializar(arg);ov[0]=q.delante==NULL;ov[1]=q.atras==NULL;ov[2]=q.cantidad;break;
 case 1: result=cp_vacia(arg);break;
 case 2: result=cp_contar(arg);break;
 case 3: result=cp_copiar_items(arg,nv?NULL:ov,np?NULL:op,cap);break;
 case 4: cp_formatear(arg,nv?NULL:text,(size_t)cap);break;
 default:return -99;
 }
 *readonly=(method==0 ? 1:(q.delante==before.delante && q.atras==before.atras && q.cantidad==before.cantidad));
 for(int i=0;i<n;i++)if(nodes[i].valor!=saved[i].valor || nodes[i].prioridad!=saved[i].prioridad || nodes[i].sgte!=saved[i].sgte)*readonly=0;
 return result;
}
