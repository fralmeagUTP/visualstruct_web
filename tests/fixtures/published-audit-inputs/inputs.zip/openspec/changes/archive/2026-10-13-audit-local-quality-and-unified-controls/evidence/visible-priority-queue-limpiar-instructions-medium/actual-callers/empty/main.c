#include <stdio.h>
#include "tad_cola_prioridad.h"
/** @file main.c @brief Reproduce el historial de Prioridad y libera su propiedad. */
/** @brief Ejecuta el historial y comprueba cada reserva antes de anunciar éxito. @return 0 en éxito, 1 ante reserva fallida o entero fuera de int C. */
int main(void) {
    ColaPrioridad cp;
    cp_inicializar(&cp);
    // Historial de ejecucion del usuario
    // Operacion registrada: limpiar
    cp_vaciar(&cp);
    puts("Operacion aplicada.");
    // Operacion registrada: limpiar
    cp_vaciar(&cp);
    puts("Operacion aplicada.");
    /* Liberar propiedad del caller al terminar */ cp_vaciar(&cp);
    return 0;
}
