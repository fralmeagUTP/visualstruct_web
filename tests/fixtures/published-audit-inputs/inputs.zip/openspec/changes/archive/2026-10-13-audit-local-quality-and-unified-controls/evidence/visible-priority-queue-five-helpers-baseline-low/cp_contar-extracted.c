/**
 * @brief Cuenta el número de elementos presentes en la cola.
 *
 * @param[in] cola Puntero constante a la ColaPrioridad.
 *
 * @return Número de nodos (>= 0). Retorna 0 si @p cola es NULL.
 *
 * @note Complejidad temporal: O(1).
 */
int cp_contar(const ColaPrioridad *cola) {
    if (cola == NULL) {
        return 0;
    }
    return cola->cantidad;
}