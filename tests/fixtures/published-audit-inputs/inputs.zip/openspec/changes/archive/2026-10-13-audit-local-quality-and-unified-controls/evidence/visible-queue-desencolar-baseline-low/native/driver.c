#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <limits.h>
#include "tad_cola.h"
_Static_assert(_Generic(&cola_desencolar,int(*)(struct Cola*):1,default:0),"dequeue signature");
static void*objects[64];static int live[64],used,allocs,frees,active,sid,aux_init,aux_id,aux_live,num_init,num_value,result_init,result_value;static char console[256];
static int id(void*p){if(!p)return -1;for(int i=0;i<used;i++)if(live[i]&&objects[i]==p)return i;assert(0);return -1;}
static void string(const char*s){putchar('"');for(;*s;s++){if(*s=='\n')fputs("\\n",stdout);else if(*s=='"')fputs("\\\"",stdout);else if(*s=='\\')fputs("\\\\",stdout);else putchar(*s);}putchar('"');}
void qa_event(const char*ev,struct Cola*q,int cond){if(!active)return;printf("{\"sample\":%d,\"event\":\"%s\",\"condition\":%d,\"root_NULL\":%d,\"front\":%d,\"rear\":%d,\"aux_initialized\":%d,\"aux_id\":%d,\"aux_alive\":%d,\"num_initialized\":%d,\"num\":%d,\"result_initialized\":%d,\"result\":%d,\"values\":[",sid,ev,cond,q==NULL,q?id(q->delante):-1,q?id(q->atras):-1,aux_init,aux_id,aux_live,num_init,num_value,result_init,result_value);struct NodoCola*n=q?q->delante:NULL;int comma=0;while(n){assert(id(n)>=0);if(comma++)putchar(',');printf("%d",n->nro);n=n->sgte;}fputs("],\"heap\":[",stdout);comma=0;for(int i=0;i<used;i++)if(live[i]){if(comma++)putchar(',');struct NodoCola*t=objects[i];printf("{\"id\":%d,\"value\":%d,\"next\":%d}",i,t->nro,id(t->sgte));}fputs("],\"console\":",stdout);string(console);puts("}");}
int qa_guard(const char*e,struct Cola*q,int v){qa_event(e,q,v);return v;}void qa_aux(struct NodoCola*p){aux_init=1;aux_id=id(p);aux_live=1;}void qa_num(int n){num_init=1;num_value=n;}void qa_result(int n){result_init=1;result_value=n;}
void*qa_malloc(size_t n){void*p=malloc(n);assert(p&&used<64);objects[used]=p;live[used++]=1;allocs++;return p;}
void qa_free(void*p){if(!p)return;int i=id(p);live[i]=0;objects[i]=NULL;if(active&&i==aux_id)aux_live=0;frees++;free(p);}
int qa_printf(const char*fmt,...){va_list args;va_start(args,fmt);int n=vsnprintf(console,sizeof(console),fmt,args);va_end(args);return n;}
static void sample(struct Cola*q){aux_init=num_init=result_init=aux_live=0;aux_id=-1;num_value=result_value=0;console[0]=0;active=1;int result=cola_desencolar(q);active=0;assert(result_init&&result==result_value);sid++;}
int main(void){sample(NULL);sample(NULL);{struct Cola q={NULL,NULL};sample(&q);sample(&q);cola_vaciar(&q);}{struct Cola q={NULL,NULL};cola_encolar(&q,-1);sample(&q);sample(&q);cola_vaciar(&q);}{struct Cola q={NULL,NULL};cola_encolar(&q,7);cola_encolar(&q,-1);sample(&q);sample(&q);cola_vaciar(&q);}{struct Cola q={NULL,NULL};cola_encolar(&q,7);cola_encolar(&q,7);sample(&q);sample(&q);cola_vaciar(&q);}{struct Cola q={NULL,NULL};cola_encolar(&q,INT_MIN);cola_encolar(&q,INT_MAX);sample(&q);sample(&q);cola_vaciar(&q);}assert(allocs==frees);for(int i=0;i<used;i++)assert(!live[i]);fprintf(stderr,"OWNERSHIP %d %d 0\n",allocs,frees);return 0;}