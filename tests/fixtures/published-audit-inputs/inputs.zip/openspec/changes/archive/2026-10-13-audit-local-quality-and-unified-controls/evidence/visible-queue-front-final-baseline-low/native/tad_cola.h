#ifndef TADCOLA_H
#define TADCOLA_H

/**
 * @file tad_cola.h
 * @brief TAD Cola FIFO enlazada de enteros.
 */

/** @brief Nodo de la cola enlazada. */
struct NodoCola {
    int nro; /**< Dato entero almacenado. */
    struct NodoCola *sgte; /**< Enlace al siguiente nodo. */
};

/** @brief Estructura principal de la cola FIFO. */
struct Cola {
    struct NodoCola *delante; /**< Primer nodo de la cola. */
    struct NodoCola *atras; /**< Último nodo de la cola. */
};

/**
 * @brief Reserva y publica un nuevo nodo al final de la FIFO.
 * @param[in,out] q Direccion prestada de una cola inicializada y consistente.
 * @param valor Entero a almacenar, incluidos negativos y -1.
 * @note NULL q imprime error y retorna sin escritura. Fallo malloc imprime error y
 *       conserva la cola. El retorno void no comunica exito al caller.
 * @note La cola recibe propiedad del nodo; desencolar o vaciar lo libera.
 */
void cola_encolar(struct Cola *q, int valor);

/**
 * @brief Copia el dato del frente, retira su enlace y libera exactamente ese nodo.
 * @param[in,out] q Direccion prestada de una FIFO consistente, o NULL.
 * @return Dato extraido; -1 tambien es un dato valido. Ante q NULL/cola vacia,
 *         imprime diagnostico y devuelve -1 sin cambiar enlaces.
 * @note Compruebe la cola no vacia antes de extraer; el valor -1 no distingue error.
 * @note Los aliases al nodo liberado dejan de ser utilizables; q sigue valido.
 */
int cola_desencolar(struct Cola *q);

/**
 * @brief Imprime todos los elementos de la cola.
 * @param[in] q Cola a mostrar.
 */
void cola_mostrar(struct Cola q);

/**
 * @brief Libera todos los nodos de la cola.
 * @param[in,out] q Cola a vaciar.
 */
void cola_vaciar(struct Cola *q);

/**
 * @brief Obtiene el valor del cola_frente sin eliminarlo.
 * @param[in] q Cola origen.
 * @return Valor en cola_frente, o -1 si la cola esta vacia.
 */
int cola_frente(struct Cola q);
/**
 * @brief Consulta el último elemento sin modificar la cola.
 * @param q Cola a consultar.
 * @return Valor del último nodo, o -1 si no existe; -1 también puede ser un dato válido.
 */
int cola_final(struct Cola q);

#endif
