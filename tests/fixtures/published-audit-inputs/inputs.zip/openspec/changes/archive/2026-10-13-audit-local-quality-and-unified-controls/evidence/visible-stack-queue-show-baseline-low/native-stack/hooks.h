struct NodoPila;
void qa_entry(struct NodoPila*,struct NodoPila*,void*);
void qa_event(const char*,struct NodoPila*,int,int);
int qa_condition(const char*,struct NodoPila*,int);
void qa_printf(const char*,...);
