#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <limits.h>
#include "tad_pila.h"
_Static_assert(_Generic(&pila_apilar,void(*)(ptrPila*,int):1,default:0),"push signature");
static void*obj[64];static int live[64],mask[64],used,allocs,frees,active,sid,aux_init,aux_id,fail_next;static ptrPila*root;static char console[256];
static int id(void*p){if(!p)return -1;for(int j=0;j<used;j++)if(live[j]&&obj[j]==p)return j;assert(0);return -1;}
static void string(const char*s){putchar('"');for(;*s;s++){if(*s=='\n')fputs("\\n",stdout);else if(*s=='"')fputs("\\\"",stdout);else if(*s=='\\')fputs("\\\\",stdout);else putchar(*s);}putchar('"');}
void qa_event(const char*e,ptrPila*p,int condition){if(!active)return;
 printf("{\"sample\":%d,\"event\":\"%s\",\"condition\":%d,\"root_argument_NULL\":%d,\"aux_initialized\":%d,\"aux_id\":%d,\"root_ids\":[",sid,e,condition,p==NULL,aux_init,aux_init?aux_id:-1);
 ptrPila n=p?*p:NULL;int comma=0;while(n){int j=id(n);assert(mask[j]==3);if(comma++)putchar(',');printf("%d",j);n=n->sgte;}fputs("],\"root_values\":[",stdout);n=p?*p:NULL;comma=0;while(n){assert(mask[id(n)]==3);if(comma++)putchar(',');printf("%d",n->nro);n=n->sgte;}fputs("],\"live\":[",stdout);comma=0;
 for(int j=0;j<used;j++)if(live[j]){if(comma++)putchar(',');ptrPila n=obj[j];printf("{\"id\":%d,\"mask\":%d,\"value\":",j,mask[j]);if(mask[j]&1)printf("%d",n->nro);else fputs("null",stdout);fputs(",\"next_id\":",stdout);if(mask[j]&2)printf("%d",id(n->sgte));else fputs("null",stdout);putchar('}');}
 fputs("],\"console\":",stdout);string(console);puts("}");}
int qa_guard(const char*e,ptrPila*p,int v){qa_event(e,p,v);return v;}
void qa_capture(ptrPila p){if(active){aux_init=1;aux_id=id(p);}}
void qa_field(ptrPila p,int bit){mask[id(p)]|=bit;}
void*qa_malloc(size_t size){qa_event("allocator_enter",root,-1);if(active&&fail_next){fail_next=0;qa_event("allocator_NULL_return",root,-1);return NULL;}void*p=malloc(size);assert(p&&used<64);obj[used]=p;live[used]=1;mask[used++]=0;allocs++;qa_event("allocator_success_return",root,-1);return p;}
void qa_free(void*p){if(!p)return;int j=id(p);live[j]=0;obj[j]=NULL;mask[j]=0;frees++;free(p);}
int qa_printf(const char*fmt,...){va_list args;va_start(args,fmt);int result=vsnprintf(console,sizeof(console),fmt,args);va_end(args);return result;}
static void sample(ptrPila*p,int value,int fault){aux_init=0;aux_id=-1;console[0]=0;root=p;fail_next=fault;active=1;pila_apilar(p,value);active=0;sid++;root=NULL;}
int main(void){{ptrPila p=NULL;sample(&p,9,0);sample(&p,9,0);sample(&p,9,1);pila_destruir(&p);}{ptrPila p=NULL;pila_apilar(&p,7);sample(&p,-1,0);sample(&p,-1,0);sample(&p,-1,1);pila_destruir(&p);}{ptrPila p=NULL;pila_apilar(&p,7);sample(&p,7,0);sample(&p,7,0);sample(&p,7,1);pila_destruir(&p);}{ptrPila p=NULL;pila_apilar(&p,2147483647);pila_apilar(&p,-1);sample(&p,INT_MIN,0);sample(&p,INT_MIN,0);sample(&p,INT_MIN,1);pila_destruir(&p);}sample(NULL,9,0);assert(allocs==frees);for(int j=0;j<used;j++)assert(!live[j]);fprintf(stderr,"OWNERSHIP %d %d 0\n",allocs,frees);return 0;}