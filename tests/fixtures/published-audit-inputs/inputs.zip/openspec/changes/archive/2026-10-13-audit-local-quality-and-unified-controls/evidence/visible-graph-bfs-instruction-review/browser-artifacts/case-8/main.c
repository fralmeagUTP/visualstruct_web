/** @file main.c @brief Historial de operaciones; BFS imprime su resultado C y libera su lista propia. */
#include "tad_grafo.h"
#include <stdio.h>
#include <stdlib.h>
/** @brief Ejecuta el historial. @return 0 tras liberar el grafo final. */
int main(void) {
    Grafo g = grafo_crear();

    // Historial de ejecucion del usuario
    /* TAD nuevo: reinicio del grafo (dirigido=true didáctico). */ g = grafo_crear();
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, -2147483648);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, -1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, 2147483647);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_arco(g, -2147483648, -1, 1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_arco(g, -1, 2147483647, 1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    ListaVertice rec_7 = grafo_bfs(g, -2147483648); printf("BFS:"); for (ListaVertice it_7 = rec_7; it_7 != NULL; it_7 = it_7->sig) printf(" %d", it_7->dato); printf("\n"); while (rec_7 != NULL) { ListaVertice next_7 = rec_7->sig; free(rec_7); rec_7 = next_7; }
    ListaVertice rec_8 = grafo_bfs(g, -2147483648); printf("BFS:"); for (ListaVertice it_8 = rec_8; it_8 != NULL; it_8 = it_8->sig) printf(" %d", it_8->dato); printf("\n"); while (rec_8 != NULL) { ListaVertice next_8 = rec_8->sig; free(rec_8); rec_8 = next_8; }
    while (g.a != NULL) { ListaArco next = g.a->sig; free(g.a); g.a = next; }
    while (g.v != NULL) { ListaVertice next = g.v->sig; free(g.v); g.v = next; }
    return 0;
}