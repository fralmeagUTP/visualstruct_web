#include <stddef.h>
#include <stdio.h>
#include "tad_cola.h"
int main(void) {
    // Declaracion de la estructura
    struct Cola cola = { .delante = NULL, .atras = NULL };
 
    // Historial de ejecucion del usuario
    cola_encolar(&cola, 7);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cola_encolar(&cola, -2);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cola_encolar(&cola, 7);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cola_vaciar(&cola);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cola_encolar(&cola, 8);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cola_vaciar(&cola);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    return 0;
}
