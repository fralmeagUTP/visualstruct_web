/** @file main.c @brief Historial de operaciones; BFS imprime su resultado C y libera su lista propia. */
#include "tad_grafo.h"
#include <stdio.h>
#include <stdlib.h>
/** @brief Ejecuta el historial. @return 0 tras liberar el grafo final. */
int main(void) {
    Grafo g = grafo_crear();

    // Historial de ejecucion del usuario
    /* TAD nuevo: reinicio del grafo (dirigido=true didáctico). */ g = grafo_crear();
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, 1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, 2);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, 3);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, 4);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_arco(g, 1, 2, 1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_arco(g, 1, 3, 1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_arco(g, 2, 4, 1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    ListaVertice rec_9 = grafo_bfs(g, 1); printf("BFS:"); for (ListaVertice it_9 = rec_9; it_9 != NULL; it_9 = it_9->sig) printf(" %d", it_9->dato); printf("\n"); while (rec_9 != NULL) { ListaVertice next_9 = rec_9->sig; free(rec_9); rec_9 = next_9; }
    ListaVertice rec_10 = grafo_bfs(g, 1); printf("BFS:"); for (ListaVertice it_10 = rec_10; it_10 != NULL; it_10 = it_10->sig) printf(" %d", it_10->dato); printf("\n"); while (rec_10 != NULL) { ListaVertice next_10 = rec_10->sig; free(rec_10); rec_10 = next_10; }
    while (g.a != NULL) { ListaArco next = g.a->sig; free(g.a); g.a = next; }
    while (g.v != NULL) { ListaVertice next = g.v->sig; free(g.v); g.v = next; }
    return 0;
}