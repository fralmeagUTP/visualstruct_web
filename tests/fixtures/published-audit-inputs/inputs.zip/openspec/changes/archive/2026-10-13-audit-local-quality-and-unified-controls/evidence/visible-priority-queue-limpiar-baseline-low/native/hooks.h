#include "tad_cola_prioridad.h"
void qa_event(const char*,ColaPrioridad*,int);
int qa_guard(const char*,ColaPrioridad*,int);
void qa_aux(CPNodo*);
void qa_next(CPNodo*);
void *qa_malloc(size_t);
void qa_free(void*);
