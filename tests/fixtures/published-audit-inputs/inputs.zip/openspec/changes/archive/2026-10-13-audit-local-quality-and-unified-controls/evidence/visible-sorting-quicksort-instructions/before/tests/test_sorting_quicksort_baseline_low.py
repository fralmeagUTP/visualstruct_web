"""Quick sort LOW baseline and strong recorded causal regressions, no xfail."""
from pathlib import Path
import json,hashlib,types,sys
import pytest
from _audit_quicksort_baseline import audit,CASES,UI_CASES
from app import create_app
from app.domain.sorting.tad_ordenamiento import SortingInterpreter
from test_graph_bfs_documentation import run_doxygen
ROOT=Path(__file__).resolve().parents[1];E=ROOT/'openspec/changes/audit-local-quality-and-unified-controls/evidence/visible-sorting-quicksort-baseline-low'
@pytest.fixture(scope='module')
def observed(tmp_path_factory):
 out=tmp_path_factory.mktemp('quicksort-baseline');return out,audit(out)
@pytest.mark.parametrize('case',list(CASES))
def test_actual_C_result_and_each_represented_partial_array(case,observed):
 out,r=observed;d=json.loads((out/(case+'.json')).read_text(encoding='utf-8'));row=next(x for x in r['rows'] if x['case']==case)
 assert row['final_array_match'] and d['response']['visual_state']['items']==d['fast_response']['visual_state']['items']==sorted(CASES[case])
 for p in d['projection']:assert d['response']['execution_trace']['steps'][p['runtime_index']]['state_after']['items']==d['native'][p['native_index']]['array']
 assert all(0<=o['event']['a']<len(CASES[case]) and 0<=o['event']['b']<len(CASES[case]) for o in d['native'] if o['event']['a'] is not None)

@pytest.mark.parametrize('case',list(CASES))
def test_native_comparisons_swaps_and_three_assignment_moves_including_single(case,observed):
 _,r=observed;row=next(x for x in r['rows'] if x['case']==case)
 assert row['native_metrics']['moves']==3*row['native_metrics']['swaps']
 assert row['runtime_metrics']==row['native_metrics'],(case,row)

def test_exact_existing_helpers_and_native_guards(observed):
 out,r=observed;i=json.loads((out/'inventory.json').read_text(encoding='utf-8'));assert i['variant']['id']=='quicksort' and i['helpers']==['arreglo_valido','quicksort_recursivo','intercambiar'] and not i['partition_function'] and i['total_methods']==11
 assert r['native_guard_cases']==2 and r['native_guard_observations']==17 and r['empty_API_rejected']

def test_C_H_Doxygen_and_five_closed_modules_unchanged(observed):
 out,_=observed;run_doxygen(out,[out/'tad_ordenamiento.c',out/'tad_ordenamiento.h'])
 for ext in ['c','h']:assert (out/('tad_ordenamiento.'+ext)).read_bytes()==(ROOT/'docs/tads_C'/('tad_ordenamiento.'+ext)).read_bytes()
 h=json.loads((ROOT/'openspec/changes/audit-local-quality-and-unified-controls/evidence/visible-sorting-shell-instructions/implementation-hashes.json').read_text(encoding='utf-8'))['files']
 for rel in ['app/domain/sorting/intercambio_instructions.py','app/domain/sorting/seleccion_instructions.py','app/domain/sorting/insercion_instructions.py','app/domain/sorting/burbuja_instructions.py','app/domain/sorting/shell_instructions.py']:assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h[rel]

def test_shared_helper_default_unchanged_without_running_closed_methods():
 p=E/'before/app/domain/sorting/tad_ordenamiento.py';m=types.ModuleType('_quick_old');sys.modules[m.__name__]=m
 try:
  exec(compile(p.read_text(encoding='utf-8'),str(p),'exec'),m.__dict__)
  old=m.SortingInterpreter([2,1],'shell');now=SortingInterpreter([2,1],'shell');old._swap(0,1);now._swap(0,1)
  assert old._steps==now._steps and old.values==now.values and old.metrics.moves==now.metrics.moves==0
 finally:sys.modules.pop(m.__name__,None)

def test_repeated_history_and_GET_main_no_redispatch(monkeypatch):
 from app.adapters.sorting_adapter import SortingAdapter
 c=create_app().test_client();c.post('/api/ordenamiento/create-array',json={'values':[4,3,2,1]});a=c.post('/api/ordenamiento/run',json={'algorithm_id':'quicksort','mode':'fast'}).get_json();b=c.post('/api/ordenamiento/run',json={'algorithm_id':'quicksort','mode':'fast'}).get_json()
 assert a['success'] and b['success'] and sum(x['operation']=='run' for x in b['history'])==2
 monkeypatch.setattr(SortingAdapter,'run',lambda *a,**k:pytest.fail('GET sorted again'))
 d=c.get('/api/ordenamiento/state').get_json();assert d['history']==b['history'] and d['main_c']==b['main_c'] and d['main_c'].count('ordenar_quicksort(arreglo, n);')==2

@pytest.mark.parametrize('case',list(UI_CASES))
def test_actual_UI_coarse_replay_and_actual_C_downloads(case):
 r=json.loads((E/'browser/report.json').read_text(encoding='utf-8'));row=next(x for x in r['rows'] if x['case']==case)
 assert row['coarse_restorations']==2*row['coarse_steps'] and row['replay_extra_POSTs']==0 and row['page_errors']==[] and row['main_preserved_after_reload'] and row['five_stages']
 assert len(row['DOM_quick_variants'])==1 and row['DOM_quick_variants'][0]['id']=='quicksort'
 assert row['caller']['arrays']==[UI_CASES[case],sorted(UI_CASES[case])] and row['caller']['strict_C17'] and row['caller']['doxygen_warnings']==0 and row['caller']['allocations']==row['caller']['frees']==row['caller']['live']==0
 assert r['empty_UI_rejected'] and r['empty_caller']['successful_native_runs']==0

@pytest.mark.parametrize('case',list(CASES))
def test_every_quick_recursive_scan_call_scope_helper_instruction_is_represented(case,observed):
 out,_=observed;d=json.loads((out/(case+'.json')).read_text(encoding='utf-8'));steps=d['response']['execution_trace']['steps'];native=d['native']
 assert len(steps)==len(native),f'{case}: C has {len(native)} observations; runtime has {len(steps)} frames'
 for step,c in zip(steps,native):
  assert step['debug'].get('instruction_event')==c['event'] and step['state_after']['items']==c['array']
  assert (step['pedagogy']['condition']['result'] if step['pedagogy']['condition'] else None)==c['condition']
