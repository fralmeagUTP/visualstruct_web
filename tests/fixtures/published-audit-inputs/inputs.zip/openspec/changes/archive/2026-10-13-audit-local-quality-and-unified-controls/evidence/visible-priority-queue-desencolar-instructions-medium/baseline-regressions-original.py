"""Finite priority dequeue regressions from current C/API/UI baseline; no xfail."""
from __future__ import annotations
import json
from pathlib import Path
import pytest
E=Path(__file__).resolve().parents[1]/'openspec/changes/audit-local-quality-and-unified-controls/evidence/visible-priority-queue-desencolar-baseline-low'
CASES=['front','interior','rear','equal-front','equal-interior','several-updates','single','empty']
NORMAL=CASES[:-1]
def read(name):return json.loads((E/name).read_text(encoding='utf-8'))
def data(name):return next(x['data'] for x in read('API-report.json') if x['case']==name)
def step(name,token):return next(x for x in data(name)['execution_trace']['steps'] if token in x['line_text'])
@pytest.mark.parametrize('name',CASES)
def test_API_scalar_and_adapter_both_outputs_match_native_stable_selection(name):
    row=next(x for x in read('API-report.json') if x['case']==name);d=row['data'];raw=[x for x in read('reused-dequeue-native-events.json') if x['case']==CASES.index(name)];last=raw[-1];assert d['success']==(name!='empty');assert d.get('result')==(last['output_value'] if name!='empty' else None);assert d['visual_state']['items']==[{'value':v,'priority':p} for v,p in last['items']]
    if name!='empty':assert row['adapter_both_C_outputs_match']
def test_all_74_native_conditions_have_correct_current_result():
    report=read('native-priority-dequeue-current-review.json');assert len(report['condition_comparisons']['observations'])==74 and report['condition_comparisons']['mismatches']==[]
def test_current_trace_contains_all_198_compatible_native_occurrences():
    report=read('native-priority-dequeue-current-review.json');assert len(report['observations'])==198 and report['missing_sequence_events']==[]
@pytest.mark.parametrize('name',NORMAL)
def test_unlink_keeps_other_initialized_aliases_and_objective_identity(name):
    rows=[x for x in read('native-priority-dequeue-current-review.json')['observations'] if x['case']==name and x['line'] in ['cola->delante = objetivo->sgte;','objetivoPrev->sgte = objetivo->sgte;']];assert len(rows)==1
    for row in rows:assert all(row['trace_observed'].get(k)==row['expected'][k] for k in ['actual','prev','objetivo','objetivoPrev'])
@pytest.mark.parametrize('name',['front','rear','single','empty'])
def test_declarations_show_indeterminate_typed_scoped_locals_without_fake_NULL(name):
    for local in ['actual','prev','objetivo','objetivoPrev']:
        s=step(name,'CPNodo *'+local+';');v=next((x for x in s['pedagogy']['variables'] if x['name']==local),None);assert v is not None and v['type']=='CPNodo *' and v['initialized'] is False and v['scope']=='cp_desencolar'
def test_both_int_output_pointers_are_distinct_from_caller_scalars():
    for name in NORMAL:
        s=step(name,'*valor = objetivo->valor;');pointers=s['pedagogy']['pointers'];v=next((x for x in pointers if x['name']=='valor'),None);p=next((x for x in pointers if x['name']=='prioridad'),None);assert v is not None and p is not None and v['type']==p['type']=='int *' and v['target']!=p['target']
def test_free_removes_same_node_and_marks_every_alias_to_it_unusable():
    for name in NORMAL:
        s=step(name,'free(objetivo);');f=s['pedagogy'];freed=f['heap_transition']['freed'];assert len(freed)==1 and freed[0]['freed']
        target=step(name,'*valor = objetivo->valor;')['state_after']['objetivo'];refs=[x for x in f['pointers'] if x['name'] in ['objetivo','prev'] and x.get('target')==target];assert refs and all(x.get('valid') is False for x in refs);assert not any(x['id']==freed[0]['id'] for x in f['heap_objects'])
@pytest.mark.parametrize('name',NORMAL)
def test_quantity_changes_only_at_own_guarded_store_and_output_copies_precede_free(name):
    steps=data(name)['execution_trace']['steps'];store=next(i for i,x in enumerate(steps) if 'cola->cantidad--;' in x['line_text']);free=next(i for i,x in enumerate(steps) if 'free(objetivo);' in x['line_text']);v=next(i for i,x in enumerate(steps) if '*valor = objetivo->valor;' in x['line_text']);p=next(i for i,x in enumerate(steps) if '*prioridad = objetivo->prioridad;' in x['line_text']);initial=len(next(x['priorities'] for x in read('API-report.json') if x['case']==name));assert v<p<free<store;assert all(x['state_after'].get('cantidad',initial)==initial for x in steps[:store]);assert steps[store]['state_after']['cantidad']==initial-1
@pytest.mark.parametrize('name',['root_NULL','empty','value_NULL','priority_NULL','both_NULL','extremes','minus1','counter_zero'])
def test_python_C_transcription_matches_defined_native_private_guard_and_counter_case(name):
    from app.domain.sequential import tad_cola_prioridad as t
    seeds={'root_NULL':None,'empty':[],'value_NULL':[(17,7)],'priority_NULL':[(17,7)],'both_NULL':[(17,7)],'extremes':[(2147483647,2147483647),(-2147483648,-2147483648)],'minus1':[(-1,-1)],'counter_zero':[(17,7)]}[name];q=None if seeds is None else t.ColaPrioridad();v=None if name in ['value_NULL','both_NULL'] else [-999];p=None if name in ['priority_NULL','both_NULL'] else [-888]
    for value,priority in seeds or []:assert t.cp_encolar(q,value,priority)
    if name=='counter_zero':q.cantidad=0
    result=t.cp_desencolar(q,v,p);items=[];node=q.delante if q else None
    while node:items.append([node.valor,node.prioridad]);node=node.sgte
    expected=next(x['native_final'] for x in read('new-native-gap-report.json')['cases'] if x['case']==name);assert {'return':result,'items':items,'count':q.cantidad if q else 0,'value':v[0] if v else None,'priority':p[0] if p else None}==expected

def test_new_native_gap_types_safe_lifetimes_and_initialized_output_guards():
    report=read('new-native-gap-report.json');assert report['calls']==8 and report['ownership']=='OWNERSHIP 7 7 0' and report['signature_types_C17'];events=[json.loads(x) for x in (E/'new-native-gaps/events.jsonl').read_text(encoding='utf-8').splitlines()]
    for sample in range(5):
        rows=[x for x in events if x['sample']==sample];assert rows[-1]['return']==0 and not rows[-1]['value_written'] and not rows[-1]['priority_written'];assert all(x['aliases']==[None]*4 for x in rows)
@pytest.mark.parametrize('name',['front','rear','single'])
def test_return_ends_locals_but_preserves_caller_roots_and_counter(name):
    s=step(name,'return true;');p=s['pedagogy'];assert any(x.get('state')=='ended' or x.get('scope_state')=='ended' for x in p.get('scopes',[]));assert 'delante' in s['state_after'] and 'atras' in s['state_after'] and 'cantidad' in s['state_after']
def test_current_UI_two_views_native_diagram_roots_and_replay_are_verified():
    rows=read('browser/report.json');assert len(rows)==4
    for d in rows:assert d['five_numbered_sections_match'] and d['extra_POSTs']==0 and not d['JS_errors'];assert all(x['equal'] for x in d['DOM_root_observations'])
@pytest.mark.parametrize('name',['front','interior','rear','equal-interior'])
def test_priority_dequeue_reload_restores_exact_trace_and_real_Next(name):
    d=next(x for x in read('browser/report.json') if x['case']==name);assert d['history_reload_equal'] and d['reload_trace_equal'] and d['reload_next_clicked']
@pytest.mark.parametrize('name',['front','interior','rear','equal-interior'])
def test_actual_DOM_main_C17_native_outputs_ownership_and_Doxygen(name):
    d=read('caller-report.json');row=next(x for x in d['cases'] if x['case']==name);assert row['C17_compile_exit']==0;assert row['C17_exit']==row['ownership_exit']==0;assert row['allocs']==row['frees']==3 and row['live']==0;assert d['Doxygen_warnings']==0 and d['documented_main_symbols']==4
