#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "tad_cola_prioridad.h"
struct cp_nodo {
    int valor; /**< Dato almacenado. */
    int prioridad; /**< Prioridad del elemento. */
    struct cp_nodo *sgte; /**< Enlace al siguiente nodo. */
};
_Static_assert(_Generic(&cp_desencolar,bool(*)(ColaPrioridad*,int*,int*):1,default:0),"bool/output-pointer signature");
static void*objects[64];static int alive[64],used,allocs,frees,active,sid,aliases[4],defined[4],value_written,priority_written,ret=-1;static int *value_ptr,*priority_ptr;
static int id(void*p){if(!p)return -1;for(int i=0;i<used;i++)if(alive[i]&&objects[i]==p)return i;assert(0);return -1;}
static void string(const char*s){putchar('"');for(;*s;s++){if(*s=='"'||*s=='\\')putchar('\\');putchar(*s);}putchar('"');}
void qa_event(const char*line,ColaPrioridad*q,int cond){if(!active)return;printf("{\"sample\":%d,\"line\":",sid);string(line);printf(",\"condition\":%d,\"root_NULL\":%d,\"front\":%d,\"rear\":%d,\"count\":%d,\"value_ptr_NULL\":%d,\"priority_ptr_NULL\":%d,\"outputs_initialized\":true,\"value_written\":%d,\"priority_written\":%d,\"return\":%d,\"output_value\":",cond,q==NULL,q?id(q->delante):-1,q?id(q->atras):-1,q?q->cantidad:0,value_ptr==NULL,priority_ptr==NULL,value_written,priority_written,ret);if(value_ptr)printf("%d",*value_ptr);else fputs("null",stdout);fputs(",\"output_priority\":",stdout);if(priority_ptr)printf("%d",*priority_ptr);else fputs("null",stdout);fputs(",\"aliases\":[",stdout);for(int i=0;i<4;i++){if(i)putchar(',');if(defined[i])printf("%d",aliases[i]);else fputs("null",stdout);}fputs("],\"heap\":[",stdout);int comma=0;for(int i=0;i<used;i++)if(alive[i]){if(comma++)putchar(',');CPNodo*n=objects[i];printf("{\"id\":%d,\"value\":%d,\"priority\":%d,\"next\":%d}",i,n->valor,n->prioridad,id(n->sgte));}fputs("],\"items\":[",stdout);comma=0;for(CPNodo*n=q?q->delante:NULL;n;n=n->sgte){assert(id(n)>=0);if(comma++)putchar(',');printf("[%d,%d]",n->valor,n->prioridad);}puts("]}");}
bool qa_test(const char*l,bool v,ColaPrioridad*q){qa_event(l,q,v);return v;}void qa_alias(int i,CPNodo*p){aliases[i]=id(p);defined[i]=1;}void qa_result(int n){ret=n;}void qa_value_written(void){value_written=1;}void qa_priority_written(void){priority_written=1;}
void*qa_malloc(size_t n){void*p=malloc(n);assert(p&&used<64);objects[used]=p;alive[used++]=1;allocs++;return p;}void qa_free(void*p){if(!p)return;int j=id(p);alive[j]=0;objects[j]=NULL;frees++;free(p);}
static void sample(ColaPrioridad*q,int*v,int*p){for(int i=0;i<4;i++){defined[i]=0;aliases[i]=-1;}value_written=priority_written=0;ret=-1;value_ptr=v;priority_ptr=p;active=1;bool result=cp_desencolar(q,v,p);active=0;assert((int)result==ret);sid++;value_ptr=priority_ptr=NULL;}
int main(void){int v=-999,p=-888;sample(NULL,&v,&p);{ColaPrioridad q;cp_inicializar(&q);sample(&q,&v,&p);}for(int mode=0;mode<3;mode++){ColaPrioridad q;cp_inicializar(&q);assert(cp_encolar(&q,17,7));v=-999;p=-888;sample(&q,mode==0||mode==2?NULL:&v,mode==1||mode==2?NULL:&p);cp_vaciar(&q);} {ColaPrioridad q;cp_inicializar(&q);assert(cp_encolar(&q,INT_MAX,INT_MAX));assert(cp_encolar(&q,INT_MIN,INT_MIN));sample(&q,&v,&p);cp_vaciar(&q);} {ColaPrioridad q;cp_inicializar(&q);assert(cp_encolar(&q,-1,-1));sample(&q,&v,&p);cp_vaciar(&q);} {ColaPrioridad q;cp_inicializar(&q);assert(cp_encolar(&q,17,7));q.cantidad=0;sample(&q,&v,&p);assert(q.cantidad==0);cp_vaciar(&q);}assert(allocs==frees);for(int i=0;i<used;i++)assert(!alive[i]);fprintf(stderr,"OWNERSHIP %d %d 0\n",allocs,frees);return 0;}
