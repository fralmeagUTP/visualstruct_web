/**
 * @file tad_lista.c
 * @brief Implementación del TAD Lista enlazada.
 */

#include <stdio.h>
#include <stdlib.h>

/**
 * @brief Nodo de una lista enlazada simple.
 */
struct NodoLista {
    int nro; /**< Dato entero almacenado. */
    struct NodoLista *sgte; /**< Enlace al siguiente nodo. */
};

/** @brief Puntero a nodo o cabeza de lista; NULL representa lista vacía. */
typedef struct NodoLista* Tlista;

static Tlista audit_nodes[64];static int audit_live[64],audit_count,audit_case,audit_active;
static Tlista *audit_root;static int audit_alias[5],audit_scalars[2],audit_scalar_known[2];
static int audit_id(Tlista n){if(!n)return 0;for(int i=0;i<audit_count;i++)if(audit_live[i]&&n==audit_nodes[i])return i+1;return -1;}
static void *audit_malloc(size_t size){void *p=malloc(size);if(p){audit_nodes[audit_count]=p;audit_live[audit_count++]=1;}return p;}
static void audit_free(void *p){if(p){int id=audit_id(p);if(id>0)audit_live[id-1]=0;}free(p);}
static void audit_emit(const char *line,int condition){if(!audit_active)return;
 printf("AUDITJSON {\"case\":%d,\"line\":",audit_case);putchar('"');for(const char *c=line;*c;c++){if(*c=='"'||*c=='\\')putchar('\\');putchar(*c);}printf("\",\"condition\":%d,\"root\":%d,\"aliases\":[",condition,audit_id(*audit_root));
 for(int i=0;i<5;i++){if(i)putchar(',');printf("%d",audit_alias[i]);}printf("],\"scalars\":[");for(int i=0;i<2;i++){if(i)putchar(',');if(audit_scalar_known[i])printf("%d",audit_scalars[i]);else printf("null");}
 printf("],\"nodes\":[");int comma=0;for(int i=0;i<audit_count;i++)if(audit_live[i]){if(comma++)putchar(',');printf("{\"id\":%d,\"value\":%d,\"next\":%d}",i+1,audit_nodes[i]->nro,audit_id(audit_nodes[i]->sgte));}
 printf("],\"reachable_values\":[");comma=0;for(Tlista n=*audit_root;n;n=n->sgte){if(comma++)putchar(',');printf("%d",n->nro);}puts("]}");
}

/**
 * @brief Reserva un nodo y establece su dato y enlace NULL.
 * @param valor Dato almacenado.
 * @return Nodo reservado o NULL en error de memoria; el llamador libera su memoria.
 * @note Un fallo de malloc escribe un diagnóstico en stdout.
 */
static Tlista CrearNodoLista(int valor) {
    Tlista q = (Tlista) audit_malloc(sizeof(struct NodoLista));
    if (q == NULL) {
        printf("Error: no se pudo asignar memoria.\n");
        return NULL;
    }
    q->nro = valor;
    q->sgte = NULL;
    return q;
}


//----------------------------------------------------------------
/*
 * @brief Inserta un nuevo nodo al inicio de la lista.
 * @param lista Puntero a la lista.
 * @param valor Valor entero a insertar.
 */
/**
 * @brief Reserva e inserta un nodo al inicio de la cadena.
 * @param[in,out] lista Dirección de la variable cabeza del llamador; *lista puede ser NULL.
 * @param[in] valor Dato entero a insertar; se admiten valores repetidos.
 * @post En éxito, la nueva cabeza contiene valor y enlaza con la cabeza anterior.
 * @note Si lista es NULL no hace nada. Si malloc falla, conserva la cadena y escribe un diagnóstico en stdout.
 */
void lista_insertar_inicio(Tlista *lista, int valor) {
    if ((audit_emit("if (lista == NULL) {",(lista == NULL)),(lista == NULL))) {
audit_emit("return;",-1);         return;
    }

    Tlista q = CrearNodoLista(valor);
audit_alias[0]=audit_id(q); audit_emit("Tlista q = CrearNodoLista(valor);",-1);
    if ((audit_emit("if (q == NULL) {",(q == NULL)),(q == NULL))) {
audit_emit("return;",-1);         return;
    }

    q->sgte = *lista;
 audit_emit("q->sgte = *lista;",-1);
    *lista = q;
}


//---------------------------------------------------------------
/*
 * @brief Inserta un nuevo nodo al final de la lista.
 * @param lista Puntero a la lista.
 * @param valor Valor entero a insertar.
 */
/**
 * @brief Reserva e inserta un nodo al final de la cadena.
 * @param[in,out] lista Dirección de la variable cabeza del llamador; *lista puede ser NULL.
 * @param[in] valor Dato entero a insertar; se admiten valores repetidos.
 * @post En éxito, la cadena vacía recibe una cabeza; en otra cadena cambia el enlace del último nodo.
 * @note Si lista es NULL no hace nada. Si malloc falla, conserva la cadena y escribe un diagnóstico en stdout.
 */
void lista_insertar_final(Tlista *lista, int valor) {
    if ((audit_emit("if (lista == NULL) {",(lista == NULL)),(lista == NULL))) {
audit_emit("return;",-1);         return;
    }

    Tlista q = CrearNodoLista(valor);
audit_alias[0]=audit_id(q); audit_emit("Tlista q = CrearNodoLista(valor);",-1);
    if ((audit_emit("if (q == NULL) {",(q == NULL)),(q == NULL))) {
audit_emit("return;",-1);         return;
    }

    if ((audit_emit("if (*lista == NULL) {",(*lista == NULL)),(*lista == NULL))) {
        *lista = q;
    } else {
        Tlista t = *lista;
audit_alias[2]=audit_id(t); audit_emit("Tlista t = *lista;",-1);
        while ((audit_emit("while (t->sgte != NULL) {",(t->sgte != NULL)),(t->sgte != NULL))) {
            t = t->sgte;
audit_alias[2]=audit_id(t); audit_emit("t = t->sgte;",-1);
        }
        t->sgte = q;
 audit_emit("t->sgte = q;",-1);
    }
}

//---------------------------------------------------------------
/*
 * @brief Inserta un nodo en una posición dada.
 * @param lista Puntero a la lista.
 * @param valor Valor a insertar.
 * @param pos Posición base para la inserción.
 */
/**
 * @brief Inserta al inicio para pos=1, o después del nodo en la posición base pos.
 * @param[in,out] lista Dirección de la variable cabeza del llamador; *lista puede ser NULL.
 * @param[in] valor Dato entero a insertar; se admiten valores repetidos.
 * @param[in] pos Posición base: 1 incluso en lista vacía, o 2..n si existe el nodo base.
 * @note pos=1 no significa insertar después del primer nodo: inserta al inicio.
 * @note Si lista es NULL o pos<=0, retorna sin reservar ni modificar la cadena.
 * @note Un fallo de malloc conserva la cadena y escribe un diagnóstico en stdout.
 * @note Si no existe la posición base, escribe un diagnóstico, libera el nodo temporal y conserva la cadena.
 */
void lista_insertar_elemento(Tlista *lista, int valor, int pos) {
    if ((audit_emit("if (lista == NULL || pos <= 0) {",(lista == NULL || pos <= 0)),(lista == NULL || pos <= 0))) {
audit_emit("return;",-1);         return;
    }

    Tlista q = CrearNodoLista(valor);
audit_alias[0]=audit_id(q); audit_emit("Tlista q = CrearNodoLista(valor);",-1);
    if ((audit_emit("if (q == NULL) {",(q == NULL)),(q == NULL))) {
audit_emit("return;",-1);         return;
    }

    /*
     * Contrato actual:
     * - pos == 1: inserta al inicio.
     * - pos > 1 : inserta despues del nodo en posicion base `pos`.
     */
    if ((audit_emit("if (pos == 1) {",(pos == 1)),(pos == 1))) {
        q->sgte = *lista;
 audit_emit("q->sgte = *lista;",-1);
        *lista = q;
audit_emit("return;",-1);         return;
    }

    Tlista t = *lista;
audit_alias[2]=audit_id(t); audit_emit("Tlista t = *lista;",-1);
    int i = 1;
audit_scalars[0]=i; audit_scalar_known[0]=1; audit_emit("int i = 1;",-1);
    while ((audit_emit("while (t != NULL) {",(t != NULL)),(t != NULL))) {
        if ((audit_emit("if (i == pos) {",(i == pos)),(i == pos))) {
            q->sgte = t->sgte;
 audit_emit("q->sgte = t->sgte;",-1);
            t->sgte = q;
 audit_emit("t->sgte = q;",-1);
audit_emit("return;",-1);             return;
        }
        t = t->sgte;
audit_alias[2]=audit_id(t); audit_emit("t = t->sgte;",-1);
        i++;
audit_scalars[0]=i; audit_scalar_known[0]=1; audit_emit("i++;",-1);
    }

    printf("   Error...Posicion no encontrada..!\n");
 audit_emit("printf(\"   Error...Posicion no encontrada..!\\n\");",-1);
    audit_free(q);
 audit_emit("free(q);",-1);
}

//---------------------------------------------------------------
/*
 * @brief Recorre toda la lista e imprime las posiciones de todas las coincidencias.
 * @param lista Lista en la que se busca.
 * @param valor Valor a buscar.
 */
/**
 * @brief Recorre toda la cadena e imprime las posiciones de todas las coincidencias.
 * @param[in] lista Cabeza de la cadena por valor; NULL representa lista vacía.
 * @param[in] valor Dato buscado.
 * @post No modifica nodos ni enlaces; las posiciones impresas comienzan en 1.
 * @note Es void: comunica las coincidencias mediante stdout, no devuelve una colección C.
 * @note Si no hay coincidencias, incluida la lista vacía, imprime Numero no encontrado.
 */
void lista_buscar_elemento(Tlista lista, int valor) {
    int i = 1, encontrado = 0;
audit_scalars[0]=i; audit_scalar_known[0]=1; audit_scalars[1]=encontrado; audit_scalar_known[1]=1; audit_emit("int i = 1, encontrado = 0;",-1);
    Tlista q = lista;
audit_alias[0]=audit_id(q); audit_emit("Tlista q = lista;",-1);

    while ((audit_emit("while (q != NULL) {",(q != NULL)),(q != NULL))) {
        if ((audit_emit("if (q->nro == valor) {",(q->nro == valor)),(q->nro == valor))) {
            printf("\n Encontrado en la posicion %d\n", i);
 audit_emit("printf(\"\\n Encontrado en la posicion %d\\n\", i);",-1);
            encontrado = 1;
audit_scalars[1]=encontrado; audit_scalar_known[1]=1; audit_emit("encontrado = 1;",-1);
        }
        q = q->sgte;
audit_alias[0]=audit_id(q); audit_emit("q = q->sgte;",-1);
        i++;
audit_scalars[0]=i; audit_scalar_known[0]=1; audit_emit("i++;",-1);
    }

    if ((audit_emit("if (!encontrado) {",(!encontrado)),(!encontrado))) {
        printf("\n Numero no encontrado..\n");
 audit_emit("printf(\"\\n Numero no encontrado..\\n\");",-1);
    }
}


//---------------------------------------------------------------
/*
 * @brief Muestra los elementos de la lista con su posición.
 * @param lista Lista a mostrar.
 */
/**
 * @brief Imprime todos los elementos de la lista.
 * @param[in] lista Lista a mostrar.
 */
void lista_mostrar(Tlista lista) {
    int i = 1;
    Tlista aux = lista;
    while (aux != NULL) {
        printf(" %d) %d\n", i, aux->nro);
        aux = aux->sgte;
        i++;
    }
}


//---------------------------------------------------------------
/*
 * @brief Elimina la primera ocurrencia de un valor en la lista.
 * @param lista Puntero a la lista.
 * @param valor Valor a eliminar.
 */
/**
 * @brief Desconecta y libera únicamente la primera ocurrencia del valor.
 * @param[in,out] lista Dirección de la variable cabeza del llamador; *lista puede ser NULL.
 * @param[in] valor Dato cuya primera coincidencia se elimina.
 * @post Si hay coincidencia, reconecta la cabeza o el enlace anterior antes de free; las restantes ocurrencias se conservan.
 * @note Si lista es NULL, la cadena está vacía o no existe el valor, escribe un diagnóstico en stdout y no modifica la cadena.
 * @note No devuelve un estado de éxito: su tipo de retorno C es void.
 */
void lista_eliminar_elemento(Tlista *lista, int valor) {
    if ((audit_emit("if (lista == NULL || *lista == NULL) {",(lista == NULL || *lista == NULL)),(lista == NULL || *lista == NULL))) {
        printf(" Valor no encontrado o lista vacia.\n");
 audit_emit("printf(\" Valor no encontrado o lista vacia.\\n\");",-1);
audit_emit("return;",-1);         return;
    }

    Tlista p = *lista, ant = NULL;
audit_alias[1]=audit_id(p); audit_alias[3]=audit_id(ant); audit_emit("Tlista p = *lista, ant = NULL;",-1);

    while ((audit_emit("while (p != NULL) {",(p != NULL)),(p != NULL))) {
        if ((audit_emit("if (p->nro == valor) {",(p->nro == valor)),(p->nro == valor))) {
            if ((audit_emit("if (p == *lista) {",(p == *lista)),(p == *lista))) {
                *lista = p->sgte;
            } else {
                ant->sgte = p->sgte;
 audit_emit("ant->sgte = p->sgte;",-1);
            }
            audit_free(p);
 audit_emit("free(p);",-1);
audit_emit("return;",-1);             return;
        }
        ant = p;
audit_alias[3]=audit_id(ant); audit_emit("ant = p;",-1);
        p = p->sgte;
audit_alias[1]=audit_id(p); audit_emit("p = p->sgte;",-1);
    }

    printf(" Valor no encontrado o lista vacia.\n");
 audit_emit("printf(\" Valor no encontrado o lista vacia.\\n\");",-1);
}


//---------------------------------------------------------------
/*
 * @brief Elimina todas las ocurrencias de un valor en la lista.
 * @param lista Puntero a la lista.
 * @param valor Valor a eliminar.
 */
/**
 * @brief Desconecta y libera todas las ocurrencias del valor solicitado.
 * @param[in,out] lista Dirección de la variable cabeza del llamador; *lista puede ser NULL.
 * @param[in] valor Dato cuyas coincidencias se eliminan, incluso si solo hay una.
 * @post Conserva el orden y los nodos de los demás valores; no deja una copia del valor eliminado.
 * @note Si lista es NULL o la cadena está vacía, no modifica nodos. Imprime Valores eliminados también si no encontró coincidencias.
 * @note Es void: no devuelve un contador en C; el contador de la aplicación es información adicional del wrapper.
 */
void lista_eliminar_repetidos(Tlista *lista, int valor) {
    if ((audit_emit("if (lista == NULL || *lista == NULL) {",(lista == NULL || *lista == NULL)),(lista == NULL || *lista == NULL))) {
        printf("\n\n Valores eliminados..\n");
 audit_emit("printf(\"\\n\\n Valores eliminados..\\n\");",-1);
audit_emit("return;",-1);         return;
    }

    Tlista q = *lista, ant = NULL;
audit_alias[0]=audit_id(q); audit_alias[3]=audit_id(ant); audit_emit("Tlista q = *lista, ant = NULL;",-1);

    while ((audit_emit("while (q != NULL) {",(q != NULL)),(q != NULL))) {
        if ((audit_emit("if (q->nro == valor) {",(q->nro == valor)),(q->nro == valor))) {
            Tlista temp = q;
audit_alias[4]=audit_id(temp); audit_emit("Tlista temp = q;",-1);
            if ((audit_emit("if (q == *lista) {",(q == *lista)),(q == *lista))) {
                *lista = q->sgte;
                q = *lista;
audit_alias[0]=audit_id(q); audit_emit("q = *lista;",-1);
            } else {
                ant->sgte = q->sgte;
 audit_emit("ant->sgte = q->sgte;",-1);
                q = ant->sgte;
audit_alias[0]=audit_id(q); audit_emit("q = ant->sgte;",-1);
            }
            audit_free(temp);
 audit_emit("free(temp);",-1);
        } else {
            ant = q;
audit_alias[3]=audit_id(ant); audit_emit("ant = q;",-1);
            q = q->sgte;
audit_alias[0]=audit_id(q); audit_emit("q = q->sgte;",-1);
        }
    }
    printf("\n\n Valores eliminados..\n");
 audit_emit("printf(\"\\n\\n Valores eliminados..\\n\");",-1);
}

//---------------------------------------------------------------
/*
 * @brief Libera todos los nodos de una lista enlazada.
 * @param lista Puntero a la lista que se vacía.
 */
/**
 * @brief Desconecta y libera todos los nodos; deja la cabeza en NULL.
 * @param[in,out] lista Dirección de la variable cabeza del llamador; *lista puede ser NULL.
 * @post Cada nodo se desconecta de la cabeza antes de free(q); una cabeza inicialmente NULL permanece NULL.
 * @note Si lista es NULL retorna sin hacer nada. No escribe en stdout.
 * @note q es un alias local; después de free(q) su valor es indeterminado hasta la siguiente asignación. No se lee durante ese intervalo.
 */
void lista_limpiar(Tlista *lista) {
    if (lista == NULL) {
        return;
    }

    Tlista q;
    while (*lista != NULL) {
        q = *lista;
        *lista = q->sgte;
        audit_free(q);
    }
}

/**
 * @brief Desenlaza y libera el primer nodo.
 * @param lista Dirección de la cabeza que se actualiza.
 * @param valor Salida del dato eliminado; no debe ser NULL.
 * @return 1 al eliminar; 0 ante lista vacía o punteros NULL.
 */
int lista_eliminar_inicio(Tlista *lista, int *valor) {
    Tlista eliminado;
    if (lista == NULL || *lista == NULL || valor == NULL) return 0;
    eliminado = *lista;
    *valor = eliminado->nro;
    *lista = eliminado->sgte;
    audit_free(eliminado);
    return 1;
}

/**
 * @brief Desenlaza y libera el último nodo.
 * @param lista Dirección de la cabeza que puede actualizarse.
 * @param valor Salida del dato eliminado; no debe ser NULL.
 * @return 1 al eliminar; 0 ante lista vacía o punteros NULL.
 */
int lista_eliminar_final(Tlista *lista, int *valor) {
    Tlista actual, anterior = NULL;
    if (lista == NULL || *lista == NULL || valor == NULL) return 0;
    actual = *lista;
    while (actual->sgte != NULL) { anterior = actual; actual = actual->sgte; }
    *valor = actual->nro;
    if (anterior == NULL) *lista = NULL; else anterior->sgte = NULL;
    audit_free(actual);
    return 1;
}

/**
 * @brief Desenlaza y libera el nodo en un índice basado en cero.
 * @param lista Dirección de la cabeza.
 * @param posicion Índice: cero identifica el primer nodo.
 * @param valor Salida del dato eliminado; no debe ser NULL.
 * @return 1 al eliminar; 0 ante índice fuera de rango o punteros NULL.
 */
int lista_eliminar_posicion(Tlista *lista, int posicion, int *valor) {
    Tlista actual, anterior = NULL;
    int indice = 0;
    if (lista == NULL || posicion < 0 || valor == NULL) return 0;
    actual = *lista;
    while (actual != NULL && indice < posicion) { anterior = actual; actual = actual->sgte; indice++; }
    if (actual == NULL) return 0;
    *valor = actual->nro;
    if (anterior == NULL) *lista = actual->sgte; else anterior->sgte = actual->sgte;
    audit_free(actual);
    return 1;
}



/**
 * @brief Consulta el primer dato sin modificar enlaces.
 * @param lista Cabeza de la lista.
 * @param valor Salida del dato consultado.
 * @return 1 si existe el nodo y valor no es NULL; 0 en otro caso.
 */
int lista_primero(Tlista lista, int *valor) {
    if (lista == NULL || valor == NULL) return 0;
    *valor = lista->nro;
    return 1;
}

/**
 * @brief Consulta el último dato sin modificar enlaces.
 * @param lista Cabeza de la lista.
 * @param valor Salida del dato consultado.
 * @return 1 si existe el nodo y valor no es NULL; 0 en otro caso.
 */
int lista_ultimo(Tlista lista, int *valor) {
    if (lista == NULL || valor == NULL) return 0;
    while (lista->sgte != NULL) lista = lista->sgte;
    *valor = lista->nro;
    return 1;
}

int main(void){
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=0;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,7);
audit_active=0;lista_limpiar(&list);}
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
lista_insertar_final(&list,7);
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=1;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,7);
audit_active=0;lista_limpiar(&list);}
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
lista_insertar_final(&list,7);
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=2;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,9);
audit_active=0;lista_limpiar(&list);}
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
lista_insertar_final(&list,7);
lista_insertar_final(&list,8);
lista_insertar_final(&list,9);
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=3;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,7);
audit_active=0;lista_limpiar(&list);}
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
lista_insertar_final(&list,7);
lista_insertar_final(&list,8);
lista_insertar_final(&list,9);
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=4;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,8);
audit_active=0;lista_limpiar(&list);}
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
lista_insertar_final(&list,7);
lista_insertar_final(&list,8);
lista_insertar_final(&list,9);
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=5;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,9);
audit_active=0;lista_limpiar(&list);}
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
lista_insertar_final(&list,7);
lista_insertar_final(&list,8);
lista_insertar_final(&list,9);
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=6;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,99);
audit_active=0;lista_limpiar(&list);}
{Tlista list=NULL;audit_root=&list;audit_active=0;audit_count=0;for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
lista_insertar_final(&list,7);
lista_insertar_final(&list,7);
lista_insertar_final(&list,9);
for(int k=0;k<5;k++){audit_alias[k]=-2;}for(int k=0;k<2;k++){audit_scalar_known[k]=0;}
audit_case=7;audit_active=1;printf("AUDITBEGIN %d\n",audit_case);
lista_eliminar_elemento(&list,7);
audit_active=0;lista_limpiar(&list);}
return 0;}