#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tad_cola.h"
_Static_assert(_Generic(&cola_vaciar,void(*)(struct Cola*):1,default:0),"destructor signature");
static void*obj[64];static int alive[64],used,allocs,frees,active,sid,target_free,aux_init,aux_valid,aux_id,rear_valid,rear_id;
static int id(void*p){if(!p)return -1;for(int j=0;j<used;j++)if(alive[j]&&obj[j]==p)return j;assert(0);return -1;}
void*qa_malloc(size_t size){void*p=malloc(size);assert(p&&used<64);obj[used]=p;alive[used++]=1;allocs++;return p;}
void qa_free(void*p){if(!p)return;int j=id(p);if(active){assert(aux_valid&&aux_id==j);aux_valid=aux_init=0;target_free++;if(rear_id==j)rear_valid=0;}alive[j]=0;obj[j]=NULL;frees++;free(p);}
void qa_capture(struct NodoCola*p){if(active){aux_init=aux_valid=1;aux_id=id(p);}}
void qa_rear_NULL(void){if(active){rear_valid=1;rear_id=-1;}}
void qa_event(const char*e,struct Cola*q,int condition){if(!active)return;
 printf("{\"sample\":%d,\"event\":\"%s\",\"condition\":%d,\"root_argument_NULL\":%d,\"aux_initialized\":%d,\"aux_valid\":%d,\"aux_id\":%d,\"rear_valid\":%d,\"rear_id\":%d,\"frees\":%d,\"root_ids\":[",sid,e,condition,q==NULL,aux_init,aux_valid,aux_valid?aux_id:-1,rear_valid,rear_valid?rear_id:-1,target_free);
 struct NodoCola*n=q?q->delante:NULL;int comma=0;while(n){if(comma++)putchar(',');int j=id(n);printf("%d",j);n=n->sgte;}fputs("],\"root_values\":[",stdout);n=q?q->delante:NULL;comma=0;while(n){assert(id(n)>=0);if(comma++)putchar(',');printf("%d",n->nro);n=n->sgte;}fputs("],\"live\":[",stdout);comma=0;for(int j=0;j<used;j++)if(alive[j]){if(comma++)putchar(',');struct NodoCola*n=obj[j];printf("{\"id\":%d,\"value\":%d}",j,n->nro);}puts("]}");}
int qa_guard(const char*e,struct Cola*q,int value){qa_event(e,q,value);return value;}
static void sample(struct Cola*q){target_free=aux_init=aux_valid=0;aux_id=-1;rear_valid=q!=NULL;rear_id=q?id(q->atras):-1;active=1;cola_vaciar(q);active=0;sid++;}
int main(void){{struct Cola p={NULL,NULL};sample(&p);assert(p.delante==NULL&&p.atras==NULL);sample(&p);assert(p.delante==NULL&&p.atras==NULL);cola_vaciar(&p);}{struct Cola p={NULL,NULL};cola_encolar(&p,-1);sample(&p);assert(p.delante==NULL&&p.atras==NULL);sample(&p);assert(p.delante==NULL&&p.atras==NULL);cola_vaciar(&p);}{struct Cola p={NULL,NULL};cola_encolar(&p,7);cola_encolar(&p,-2);cola_encolar(&p,7);sample(&p);assert(p.delante==NULL&&p.atras==NULL);sample(&p);assert(p.delante==NULL&&p.atras==NULL);cola_vaciar(&p);}{struct Cola p={NULL,NULL};cola_encolar(&p,7);cola_encolar(&p,-2);cola_encolar(&p,7);sample(&p);assert(p.delante==NULL&&p.atras==NULL);cola_encolar(&p,8);sample(&p);assert(p.delante==NULL&&p.atras==NULL);cola_vaciar(&p);}sample(NULL);assert(allocs==frees);for(int j=0;j<used;j++)assert(!alive[j]);fprintf(stderr,"OWNERSHIP %d %d 0\n",allocs,frees);return 0;}