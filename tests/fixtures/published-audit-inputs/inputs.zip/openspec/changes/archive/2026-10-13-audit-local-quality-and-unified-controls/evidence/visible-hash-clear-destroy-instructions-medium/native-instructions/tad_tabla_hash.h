#ifndef TABLA_HASH_H
#define TABLA_HASH_H

#include <stdbool.h>
#include <stddef.h>

/**
 * @file tad_tabla_hash.h
 * @brief TAD Tabla Hash con encadenamiento separado.
 */

/** @brief Nodo de una lista de colision. */
typedef struct th_nodo {
    int clave; /**< Clave entera del elemento. */
    int valor; /**< Dato almacenado. */
    struct th_nodo *siguiente; /**< Enlace al siguiente nodo del bucket. */
} THNodo;

/** @brief Estructura principal de la tabla hash. */
typedef struct {
    THNodo **buckets; /**< Arreglo de cabezas de cadenas de colisión. */
    int capacidad; /**< Capacidad reservada de la estructura. */
    int cantidad; /**< Número de elementos almacenados. */
} TablaHash;

/** @brief Estadisticas de ocupacion y colisiones. */
typedef struct {
    int capacidad; /**< Capacidad reservada de la estructura. */
    int cantidad; /**< Número de elementos almacenados. */
    int buckets_ocupados; /**< Número de buckets con al menos un nodo. */
    int colisiones; /**< Elementos que exceden el primer nodo de cada bucket ocupado. */
    float factor_carga; /**< Cociente cantidad/capacidad. */
} THEstadisticas;

/**
 * @brief Normaliza el módulo de una clave, incluidas claves negativas.
 * @param tabla Tabla con capacidad positiva.
 * @param clave Clave entera.
 * @return Índice entre 0 y capacidad-1, o -1 ante tabla NULL o capacidad no positiva.
 */
int th_indice(const TablaHash *tabla, int clave);
/**
 * @brief Inicializa la tabla hash.
 * @param[out] tabla Puntero a la tabla hash.
 * @param[in] capacidad Capacidad (número de buckets) de la tabla.
 */
void th_inicializar(TablaHash *tabla, int capacidad);
/**
 * @brief Inserta un par clave-valor, actualizando el valor si la clave existe.
 * @param[in,out] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a insertar.
 * @param[in] valor Valor asociado a la clave.
 * @return true si se insertó o actualizó correctamente, false en error.
 */
bool th_insertar(TablaHash *tabla, int clave, int valor);
/**
 * @brief Busca el valor asociado a una clave.
 * @param[in] tabla Puntero a la tabla hash constante.
 * @param[in] clave Clave a buscar.
 * @param[out] valor Puntero donde se almacenará el valor si se encuentra.
 * @return true si se encontró la clave, false si no.
 */
bool th_buscar(const TablaHash *tabla, int clave, int *valor);
/**
 * @brief Verifica si una clave existe en la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a verificar.
 * @return true si la clave existe, false si no.
 */
bool th_contiene(const TablaHash *tabla, int clave);
/**
 * @brief Elimina una clave de la tabla hash.
 * @param[in,out] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a eliminar.
 * @return true si fue eliminada, false si no existía o error.
 */
bool th_eliminar(TablaHash *tabla, int clave);
/**
 * @brief Elimina todos los elementos manteniendo la capacidad de la tabla.
 * @param[in,out] tabla Puntero a la tabla hash.
 */
void th_vaciar(TablaHash *tabla);
/**
 * @brief Destruye la tabla hash liberando toda su memoria.
 * @param[in,out] tabla Puntero a la tabla hash.
 */
void th_destruir(TablaHash *tabla);
/**
 * @brief Indica si la tabla está vacía.
 * @param[in] tabla Puntero a la tabla hash.
 * @return true si la cantidad es 0, false caso contrario.
 */
bool th_vacia(const TablaHash *tabla);
/**
 * @brief Retorna la cantidad de elementos en la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Cantidad de elementos almacenados.
 */
int th_cantidad(const TablaHash *tabla);
/**
 * @brief Retorna la capacidad actual de la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Capacidad (número de buckets).
 */
int th_capacidad(const TablaHash *tabla);
/**
 * @brief Calcula y retorna las estadísticas de la tabla hash.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Estructura con las estadísticas calculadas.
 */
THEstadisticas th_estadisticas(const TablaHash *tabla);
/**
 * @brief Formatea el contenido de la tabla hash en una cadena de texto.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[out] destino Buffer donde se escribirá la representación.
 * @param[in] capacidad Tamaño máximo del buffer destino.
 */
void th_formatear(const TablaHash *tabla, char *destino, size_t capacidad);
/**
 * @brief Formatea las estadísticas de la tabla en una cadena de texto.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[out] destino Buffer donde se escribirá la representación.
 * @param[in] capacidad Tamaño máximo del buffer destino.
 */
void th_formatear_estadisticas(const TablaHash *tabla, char *destino, size_t capacidad);

#endif
