
#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#include <string.h>
#include <assert.h>
typedef struct {int first,last,*i,*j,*pivot,initialized;} Frame;
static Frame frames[64];static int depth;
static int *root,*pa,*pb,*pt,has_t,fixture,comparisons,swaps,moves;static size_t count;
static void emit(const char*t,const char*f,int condition){
 printf("{\"case\":%d,\"event\":{\"token\":\"%s\",\"function\":",fixture,t);
 if(f){printf("\"%s\"",f);}else{printf("null");}
 printf(",\"frames\":[");for(int k=0;k<depth;k++){Frame *q=&frames[k];if(k){printf(",");}printf("{\"primero\":%d,\"ultimo\":%d,\"i\":",q->first,q->last);if(q->initialized){printf("%d",*q->i);}else{printf("null");}printf(",\"j\":");if(q->initialized){printf("%d",*q->j);}else{printf("null");}printf(",\"pivote\":");if(q->initialized){printf("%d",*q->pivot);}else{printf("null");}printf("}");}printf("]");
 printf(",\"temporal\":");if(pt && has_t){printf("%d",*pt);}else{printf("null");}
 printf(",\"a\":");if(pa){printf("%td",pa-root);}else{printf("null");}printf(",\"b\":");if(pb){printf("%td",pb-root);}else{printf("null");}
 printf(",\"comparisons\":%d,\"swaps\":%d,\"moves\":%d},\"condition\":",comparisons,swaps,moves);
 if(condition<0){printf("null");}else{printf(condition?"true":"false");}
 printf(",\"array\":[");for(size_t k=0;k<count;k++){if(k){printf(",");}printf("%d",root[k]);}puts("]}");
}
static int cond(const char*t,const char*f,int r){if(!strcmp(t,"i_test") || !strcmp(t,"j_test") || !strcmp(t,"cross_test")){comparisons++;}emit(t,f,r);return r;}
static int checked(int r){emit("valid_return","arreglo_valido",-1);return cond("sort_guard","ordenar_quicksort",!r);}

static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry","arreglo_valido",-1);
	return cond("valid_ptr","arreglo_valido",arreglo!=NULL) && cond("valid_n","arreglo_valido",n>0);
}
static void intercambiar(int *a, int *b) {pa=a;pb=b;emit("swap_entry","intercambiar",-1);
	int temporal;pt=&temporal;has_t=0;emit("swap_declare","intercambiar",-1);
	if(cond("swap_guard","intercambiar",a==NULL || b==NULL)) return;
	temporal=*a;has_t=1;moves++;emit("swap_temp","intercambiar",-1);
	*a=*b;moves++;emit("swap_assign_a","intercambiar",-1);
	*b=temporal;moves++;swaps++;emit("swap_assign_b","intercambiar",-1);
pt=NULL;has_t=0;pa=pb=NULL;}

static void quicksort_recursivo(int arreglo[], int primero, int ultimo) {assert(depth<64);frames[depth++]=(Frame){primero,ultimo,NULL,NULL,NULL,0};emit("rec_entry","quicksort_recursivo",-1);
	int i=primero,j=ultimo,pivote=arreglo[(primero+ultimo)/2];frames[depth-1].i=&i;frames[depth-1].j=&j;frames[depth-1].pivot=&pivote;frames[depth-1].initialized=1;emit("rec_init","quicksort_recursivo",-1);
	while(cond("outer_test","quicksort_recursivo",i<=j)) {
		while(cond("i_test","quicksort_recursivo",arreglo[i]<pivote)){++i;emit("i_increment","quicksort_recursivo",-1);}
		while(cond("j_test","quicksort_recursivo",arreglo[j]>pivote)){--j;emit("j_decrement","quicksort_recursivo",-1);}
		if(cond("cross_test","quicksort_recursivo",i<=j)) {
			emit("swap_call","quicksort_recursivo",-1);intercambiar(&arreglo[i],&arreglo[j]);emit("swap_return","intercambiar",-1);emit("swap_resume","quicksort_recursivo",-1);
			++i;emit("cross_i_increment","quicksort_recursivo",-1);--j;emit("cross_j_decrement","quicksort_recursivo",-1);
		}
	}
	if(cond("left_test","quicksort_recursivo",primero<j)){emit("left_call","quicksort_recursivo",-1);quicksort_recursivo(arreglo,primero,j);emit("left_resume","quicksort_recursivo",-1);}
	if(cond("right_test","quicksort_recursivo",i<ultimo)){emit("right_call","quicksort_recursivo",-1);quicksort_recursivo(arreglo,i,ultimo);emit("right_resume","quicksort_recursivo",-1);}
depth--;emit("rec_return","quicksort_recursivo",-1);}

void ordenar_quicksort(int arreglo[], size_t n) {emit("sort_entry","ordenar_quicksort",-1);
	emit("valid_call","ordenar_quicksort",-1);if(checked(arreglo_valido(arreglo,n))){emit("guard_return","ordenar_quicksort",-1);return;}
	emit("rec_call","ordenar_quicksort",-1);quicksort_recursivo(arreglo,0,(int)n-1);emit("rec_resume","ordenar_quicksort",-1);
}
int main(void){
{int a[]={7};root=a;count=sizeof(a)/sizeof(a[0]);fixture=0;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(a,count);emit("sort_return","ordenar_quicksort",-1);}
{int a[]={1,2,3,4};root=a;count=sizeof(a)/sizeof(a[0]);fixture=1;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(a,count);emit("sort_return","ordenar_quicksort",-1);}
{int a[]={4,3,2,1};root=a;count=sizeof(a)/sizeof(a[0]);fixture=2;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(a,count);emit("sort_return","ordenar_quicksort",-1);}
{int a[]={2,2,2};root=a;count=sizeof(a)/sizeof(a[0]);fixture=3;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(a,count);emit("sort_return","ordenar_quicksort",-1);}
{int a[]={-3,0,-1,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=4;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(a,count);emit("sort_return","ordenar_quicksort",-1);}
{int a[]={2147483647,-2147483648,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=5;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(a,count);emit("sort_return","ordenar_quicksort",-1);}
{int a=42;root=&a;count=0;fixture=6;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(&a,0);}
{root=NULL;count=0;fixture=7;depth=has_t=comparisons=swaps=moves=0;pa=pb=pt=NULL;emit("initial",NULL,-1);ordenar_quicksort(NULL,1);}
return 0;}
