import private_limits
private_limits.require_guarded_job()
from pathlib import Path
import sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path.cwd()/"tests"))
import pytest
raise SystemExit(pytest.main(["-q","--disable-warnings","--junitxml="+str(P/"duplicates-pure-1.xml"),"tests/test_phase8_duplicate_memory_consumer_controls.py"]))
