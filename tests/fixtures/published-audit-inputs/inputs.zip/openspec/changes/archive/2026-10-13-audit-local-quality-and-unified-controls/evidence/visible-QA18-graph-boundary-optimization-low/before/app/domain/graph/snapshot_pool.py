"""Exact per-request structural sharing and versioned numeric Graph transport.

Every logical field and event survives. References name immutable JSON subtrees,
not C pointers or sampled states. The unchanged player receives expanded shared
objects; a consumer can expand this codec without executing the operation.
"""
from __future__ import annotations
from dataclasses import replace
from time import perf_counter
from typing import Any
import json

CODEC = 'graph-snapshot-pool/v1'
REFERENCE = '$graph_ref'

class SnapshotPool:
    """Intern complete dictionaries/lists by typed structural value."""
    def __init__(self):
        self.objects=[];self.keys={};self.identities={};self.records=[]

    @staticmethod
    def primitive_key(value):
        if value is None:return ('null',)
        if type(value) is bool:return ('bool',value)
        if type(value) is int:return ('int',value)
        if type(value) is float:return ('float',value.hex())
        if isinstance(value,str):return ('text',value)
        raise TypeError(('Unsupported snapshot JSON value',type(value)))

    def intern(self,value):
        if isinstance(value,tuple):value=list(value) # JSON arrays; preserve transport semantics.
        if not isinstance(value,(dict,list)):
            self.primitive_key(value);return value
        old=self.identities.get(id(value))
        if old is not None and self.objects[old] is value:return value
        if isinstance(value,dict):
            def text_key(k):
                if isinstance(k,str):return k
                if k is None:return 'null'
                if type(k) is bool:return 'true' if k else 'false'
                if isinstance(k,(int,float)):return json.dumps(k)
                raise TypeError('Unsupported JSON snapshot key')
            pairs=[(text_key(k),v) for k,v in value.items()]
            if len({k for k,v in pairs})!=len(pairs):raise ValueError('Duplicate normalized snapshot keys')
            children=[(k,self.intern(v)) for k,v in pairs]
            key=('dict',tuple((k,self.token(v)) for k,v in children))
        else:
            children=[self.intern(v) for v in value];key=('list',tuple(self.token(v) for v in children))
        existing=self.keys.get(key)
        if existing is not None:return self.objects[existing]
        result=dict(children) if isinstance(value,dict) else children
        index=len(self.objects);self.keys[key]=index;self.objects.append(result);self.identities[id(result)]=index
        record=[0,[[k,self.encode(v)] for k,v in children]] if isinstance(value,dict) else [1,[self.encode(v) for v in children]]
        self.records.append(record);return result

    def token(self,value):
        if isinstance(value,(dict,list)):return ('ref',self.identities[id(value)])
        return self.primitive_key(value)

    def encode(self,value):
        if isinstance(value,(dict,list)):return {REFERENCE:self.identities[id(value)]}
        return value

    def pack(self,trace):
        # Metadata/events stay ordinary JSON. Only repetitive step subtrees and
        # the final C memory use the table, keeping one header per actual step.
        steps=[{k:self.encode(self.intern(v)) if isinstance(v,(dict,list)) and k!='console' else v for k,v in step.items()} for step in trace['steps']]
        result={**trace,'steps':steps,'numeric_C_memory':self.encode(self.intern(trace['numeric_C_memory']))} if 'numeric_C_memory' in trace else {**trace,'steps':steps}
        result.update(graph_snapshot_codec=CODEC,graph_snapshot_pool=self.records,
            graph_snapshot_stats={'compound_nodes':len(self.records),'steps':len(steps),'C_events':len(trace.get('C_instruction_events',[])),'sampling':False})
        return result


def expand_graph_trace(trace:dict[str,Any])->dict[str,Any]:
    """Expand transport exactly with shared objects; pass legacy traces through."""
    if 'graph_snapshot_codec' not in trace:return trace
    if trace['graph_snapshot_codec']!=CODEC:raise ValueError('Unknown Graph snapshot codec')
    objects=[]
    def decode(value):
        if isinstance(value,dict):
            if set(value)!={REFERENCE}:raise ValueError('Malformed Graph snapshot reference')
            index=value[REFERENCE]
            if type(index) is not int or not 0<=index<len(objects):raise ValueError('Invalid or forward Graph snapshot reference')
            return objects[index]
        if isinstance(value,list):raise ValueError('Unexpected nested transport list')
        return value
    for record in trace['graph_snapshot_pool']:
        if not isinstance(record,list) or len(record)!=2 or record[0] not in (0,1):raise ValueError('Malformed Graph pool record')
        if record[0]==0:
            keys=[item[0] for item in record[1]]
            if not all(isinstance(k,str) for k in keys) or len(set(keys))!=len(keys):raise ValueError('Invalid Graph pool dictionary keys')
            value={k:decode(v) for k,v in record[1]}
        else:value=[decode(v) for v in record[1]]
        objects.append(value)
    result={k:v for k,v in trace.items() if k not in {'graph_snapshot_codec','graph_snapshot_pool','graph_snapshot_stats'}}
    result['steps']=[{k:decode(v) if isinstance(v,dict) and REFERENCE in v else v for k,v in step.items()} for step in trace['steps']]
    if 'numeric_C_memory' in trace:result['numeric_C_memory']=decode(trace['numeric_C_memory'])
    return result


def validate_graph_logical_trace(trace):
    """Preserve legacy round-trip/types plus all engine boundary/source checks.

Validate one compatibility conversion at a time. Retain only its semantic
states for the engine; retaining every copied legacy pedagogy was redundant.
No generic engine or other family changes are needed.
"""
    from app.services.trace.compatibility import LegacyTraceAdapter
    from app.services.trace.strategies import TraceStrategyRegistry
    from app.services.trace.engine import TraceEngine
    from app.services.observability import emit_operational_event
    start=perf_counter();strategy=TraceStrategyRegistry.resolve('graph');semantic=[]
    for step in trace['steps']:
        if LegacyTraceAdapter.round_trip([step])!=[step]:raise ValueError('Graph compatibility round-trip changed logical step')
        normalized=strategy.normalize_steps([step])[0]
        semantic.append(replace(normalized,before_state=step['state_snapshot'],after_state=step['state_after'],metadata={}))
    TraceEngine.validate_steps(semantic,trace['final_state'],trace['source_code'])
    emit_operational_event('trace_validation',outcome='success',duration_ms=(perf_counter()-start)*1000,
        structure_id='graph',strategy=strategy.family,step_count=len(semantic))


def finish_graph_trace(trace,pool,compact=True):
    trace['final_state']=pool.intern(trace['final_state'])
    validate_graph_logical_trace(trace)
    return pool.pack(trace) if compact else trace
