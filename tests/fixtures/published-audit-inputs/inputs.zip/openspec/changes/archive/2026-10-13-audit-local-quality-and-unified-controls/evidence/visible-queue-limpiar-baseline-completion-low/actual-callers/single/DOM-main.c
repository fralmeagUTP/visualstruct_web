int main(void) {
    // Declaracion de la estructura
    struct Cola cola = { .delante = NULL, .atras = NULL };
 
    // Historial de ejecucion del usuario
    cola_encolar(&cola, -1);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cola_vaciar(&cola);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cola_vaciar(&cola);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    return 0;
}
