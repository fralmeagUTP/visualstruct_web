/**
 * @file tad_pila.c
 * @brief Implementación del TAD Pila LIFO.
 */

#include <stdio.h>
#include <stdlib.h>

/**
 * @brief Nodo de una pila enlazada.
 */
struct NodoPila {
    int nro; /**< Dato entero almacenado. */
    struct NodoPila *sgte; /**< Enlace al siguiente nodo. */
};

/** @brief Puntero a nodo o cima de pila; NULL representa pila vacía. */
typedef struct NodoPila* ptrPila;


//---------------------------------------------------------------
/*
 * @brief Apila un nuevo valor en la pila.
 * @param p Puntero a la pila.
 * @param valor Valor entero que se apilará.
 */
/**
 * @brief Inserta un elemento en la cima de la pila.
 * @param[in,out] p Puntero a la pila.
 * @param[in] valor Valor a apilar.
 */
void pila_apilar(ptrPila *p, int valor) {
    if (p == NULL) {
        printf("Error: pila no inicializada.\n");
        return;
    }

    ptrPila aux = (ptrPila) malloc(sizeof(struct NodoPila));
    if (aux == NULL) {
        printf("Error: No se pudo asignar memoria.\n");
        return;
    }
    aux->nro = valor;
    aux->sgte = *p;
    *p = aux;
}


//---------------------------------------------------------------
/*
 * @brief Desapila y devuelve el valor en la cima de la pila.
 * @param p Puntero a la pila.
 * @return int Valor desapilado.
 */
/**
 * @brief Extrae el elemento en la cima de la pila.
 * @param[in,out] p Puntero a la pila.
 * @return Valor extraido, o -1 si no se puede extraer; -1 también puede ser un dato válido.
 */
int pila_desapilar(ptrPila *p) {
    if (p == NULL || *p == NULL) {
        printf("Pila vacía. No se puede desapilar.\n");
        return -1;  // Valor de error
    }

    ptrPila aux = *p;
    int num = aux->nro;
    *p = aux->sgte;
    free(aux);
    return num;
}

/**
 * @brief Consulta la cima sin modificar la pila.
 * @param p Pila a consultar; puede ser NULL.
 * @return Valor de la cima, o -1 si está vacía. El valor -1 también puede estar almacenado.
 */
int pila_cima(ptrPila p) {
    return p == NULL ? -1 : p->nro;
}


//---------------------------------------------------------------
/*
 * @brief Muestra todos los elementos de la pila.
 * @param p Pila a mostrar.
 */
/**
 * @brief Muestra el contenido de la pila en orden de cima a fondo.
 * @param[in] p Pila a mostrar.
 */
void pila_mostrar(ptrPila p) {
    qa_entry(p, NULL, &p);
    ptrPila aux = p;
    qa_event("declare",aux,1,-1);
    if (qa_condition("if",aux,aux == NULL)) {
        qa_printf("Pila vacia.\n");
        qa_event("return",aux,1,-1);
        return;
    }

    while (qa_condition("while",aux,aux != NULL)) {
        qa_printf("\t%d\n", aux->nro);
        aux = aux->sgte;
        qa_event("advance",aux,1,-1);
    }
    qa_event("end",aux,1,-1);
}


//---------------------------------------------------------------
/*
 * @brief Elimina todos los elementos de la pila.
 * @param p Puntero a la pila.
 */
/**
 * @brief Libera todos los nodos de la pila.
 * @param[in,out] p Puntero a la pila.
 */
void pila_destruir(ptrPila *p) {
    ptrPila aux;
    if (p == NULL) {
        return;
    }

    while (*p != NULL) {
        aux = *p;
        *p = aux->sgte;
        free(aux);
    }
}
