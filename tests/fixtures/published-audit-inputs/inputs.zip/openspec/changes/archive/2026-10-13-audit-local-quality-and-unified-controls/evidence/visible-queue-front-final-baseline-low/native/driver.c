#include <assert.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include "tad_cola.h"
_Static_assert(_Generic(&cola_frente,int(*)(struct Cola):1,default:0),"front by-value signature");
_Static_assert(_Generic(&cola_final,int(*)(struct Cola):1,default:0),"final by-value signature");
static struct NodoCola*nodes;static int count,fixture,sample_id;
static int id(struct NodoCola*p){if(!p)return -1;for(int i=0;i<count;i++)if(p==&nodes[i])return i;assert(0);return -1;}
static void event(const char*method,struct Cola q,const char*phase,int condition,int result,int written){
 _Static_assert(_Generic(q,struct Cola:1,default:0),"q is struct value, not pointer or const");
 printf("{\"method\":\"%s\",\"fixture\":%d,\"sample\":%d,\"phase\":\"%s\",\"condition\":%d,\"result\":%d,\"written\":%d,\"front_id\":%d,\"rear_id\":%d,\"nodes\":[",method,fixture,sample_id,phase,condition,result,written,id(q.delante),id(q.atras));
 for(int i=0;i<count;i++){if(i)putchar(',');printf("{\"id\":%d,\"nro\":%d,\"next_id\":%d}",i,nodes[i].nro,id(nodes[i].sgte));}puts("]}");
}
void qa_entry(const char*m,struct Cola q){event(m,q,"entry",-1,0,0);}
int qa_condition(const char*m,struct Cola q,int c){event(m,q,"condition",c,0,0);return c;}
int qa_return(const char*m,struct Cola q,int v){event(m,q,"return",-1,v,1);return v;}
static void query(struct Cola q,const char*method){
 struct Cola saved=q;int values[8];struct NodoCola*links[8];for(int i=0;i<count;i++){values[i]=nodes[i].nro;links[i]=nodes[i].sgte;}
 int expected=strcmp(method,"frente")==0?(q.delante?q.delante->nro:-1):(q.atras?q.atras->nro:-1);
 int result=strcmp(method,"frente")==0?cola_frente(q):cola_final(q);assert(result==expected&&q.delante==saved.delante&&q.atras==saved.atras);
 for(int i=0;i<count;i++){assert(nodes[i].nro==values[i]&&nodes[i].sgte==links[i]);}
 sample_id++;
}
static void both(struct Cola q){query(q,"frente");query(q,"frente");query(q,"final");query(q,"final");fixture++;}
int main(void){
nodes=NULL;count=0;{struct Cola q={NULL,NULL};both(q);}
 {struct NodoCola fixture_nodes[1];nodes=fixture_nodes;count=1;
fixture_nodes[0].nro=17;fixture_nodes[0].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[0]};both(q);}
 {struct NodoCola fixture_nodes[3];nodes=fixture_nodes;count=3;
fixture_nodes[0].nro=17;fixture_nodes[0].sgte=&fixture_nodes[1];
fixture_nodes[1].nro=9;fixture_nodes[1].sgte=&fixture_nodes[2];
fixture_nodes[2].nro=3;fixture_nodes[2].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[2]};both(q);}
 {struct NodoCola fixture_nodes[2];nodes=fixture_nodes;count=2;
fixture_nodes[0].nro=7;fixture_nodes[0].sgte=&fixture_nodes[1];
fixture_nodes[1].nro=7;fixture_nodes[1].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[1]};both(q);}
 {struct NodoCola fixture_nodes[1];nodes=fixture_nodes;count=1;
fixture_nodes[0].nro=-1;fixture_nodes[0].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[0]};both(q);}
 {struct NodoCola fixture_nodes[2];nodes=fixture_nodes;count=2;
fixture_nodes[0].nro=-1;fixture_nodes[0].sgte=&fixture_nodes[1];
fixture_nodes[1].nro=17;fixture_nodes[1].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[1]};both(q);}
 {struct NodoCola fixture_nodes[2];nodes=fixture_nodes;count=2;
fixture_nodes[0].nro=17;fixture_nodes[0].sgte=&fixture_nodes[1];
fixture_nodes[1].nro=-1;fixture_nodes[1].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[1]};both(q);}
 {struct NodoCola fixture_nodes[3];nodes=fixture_nodes;count=3;
fixture_nodes[0].nro=INT_MIN;fixture_nodes[0].sgte=&fixture_nodes[1];
fixture_nodes[1].nro=0;fixture_nodes[1].sgte=&fixture_nodes[2];
fixture_nodes[2].nro=INT_MAX;fixture_nodes[2].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[2]};both(q);}
 {struct NodoCola fixture_nodes[3];nodes=fixture_nodes;count=3;
fixture_nodes[0].nro=INT_MAX;fixture_nodes[0].sgte=&fixture_nodes[1];
fixture_nodes[1].nro=0;fixture_nodes[1].sgte=&fixture_nodes[2];
fixture_nodes[2].nro=INT_MIN;fixture_nodes[2].sgte=NULL;
struct Cola q={&fixture_nodes[0],&fixture_nodes[2]};both(q);}
 {struct NodoCola fixture_nodes[1];nodes=fixture_nodes;count=1;
fixture_nodes[0].nro=19;fixture_nodes[0].sgte=NULL;
struct Cola q={&fixture_nodes[0],NULL};both(q);}
 {struct NodoCola fixture_nodes[1];nodes=fixture_nodes;count=1;
fixture_nodes[0].nro=19;fixture_nodes[0].sgte=NULL;
struct Cola q={NULL,&fixture_nodes[0]};both(q);}
return 0;}
