struct NodoCola;
void qa_entry(struct NodoCola*,struct NodoCola*,void*);
void qa_event(const char*,struct NodoCola*,int,int);
int qa_condition(const char*,struct NodoCola*,int);
void qa_printf(const char*,...);
