struct Cola;
void qa_entry(const char*,struct Cola);
int qa_condition(const char*,struct Cola,int);
int qa_return(const char*,struct Cola,int);
