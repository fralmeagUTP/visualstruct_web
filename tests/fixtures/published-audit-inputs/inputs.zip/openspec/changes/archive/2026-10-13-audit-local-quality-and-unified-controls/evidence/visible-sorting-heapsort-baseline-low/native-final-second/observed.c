
#include <stdio.h>
#include <stddef.h>
#include <string.h>
typedef struct {size_t n,raiz,mayor,izquierdo,derecho;int locals;} Frame;
static Frame frames[20];static int depth;static int *root,*pa,*pb;static size_t count,wi;static int hi,ia,ib,temp,td,ht,comparisons,swaps,moves,fixture;static const char *phase;
#define F frames[depth-1]
static void emit(const char*t,const char*f,int condition){
 printf("{\"case\":%d,\"event\":{\"token\":\"%s\",\"function\":",fixture,t);if(f)printf("\"%s\"",f);else printf("null");printf(",\"i\":");if(hi)printf("%zu",wi);else printf("null");printf(",\"phase\":");if(phase)printf("\"%s\"",phase);else printf("null");printf(",\"comparisons\":%d,\"swaps\":%d,\"moves\":%d,\"a\":",comparisons,swaps,moves);if(pa)printf("%d",ia);else printf("null");printf(",\"b\":");if(pb)printf("%d",ib);else printf("null");printf(",\"temporal_declared\":%s,\"temporal\":",td?"true":"false");if(ht)printf("%d",temp);else printf("null");printf(",\"frames\":[");
 for(int z=0;z<depth;z++){Frame q=frames[z];if(z)printf(",");printf("{\"n\":%zu,\"raiz\":%zu,\"mayor\":",q.n,q.raiz);if(q.locals)printf("%zu",q.mayor);else printf("null");printf(",\"izquierdo\":");if(q.locals)printf("%zu",q.izquierdo);else printf("null");printf(",\"derecho\":");if(q.locals)printf("%zu",q.derecho);else printf("null");printf("}");}
 printf("]},\"condition\":");if(condition<0)printf("null");else printf(condition?"true":"false");printf(",\"array\":[");for(size_t z=0;z<count;z++){if(z)printf(",");printf("%d",root[z]);}puts("]}");
}
static int cond(const char*t,const char*f,int r){if(!strcmp(t,"left_compare") || !strcmp(t,"right_compare"))comparisons++;emit(t,f,r);return r;}
static int checked(int r){emit("valid_return","arreglo_valido",-1);return cond("sort_guard","ordenar_heapsort",!r);}

static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry","arreglo_valido",-1);
	return cond("valid_ptr","arreglo_valido",arreglo!=NULL) && cond("valid_n","arreglo_valido",n>0);
}
static void intercambiar(int *a, int *b) {pa=a;pb=b;ia=a?(int)(a-root):-1;ib=b?(int)(b-root):-1;emit("swap_entry","intercambiar",-1);
	int temporal;td=1;emit("swap_declare","intercambiar",-1);
	if(cond("swap_guard","intercambiar",cond("swap_a_null","intercambiar",a==NULL) || cond("swap_b_null","intercambiar",b==NULL))){pa=pb=NULL;td=ht=0;emit("swap_guard_return","intercambiar",-1);return;}
	temporal = *a;temp=temporal;ht=1;moves++;emit("swap_temp","intercambiar",-1);
	*a = *b;moves++;emit("swap_assign_a","intercambiar",-1);
	*b = temporal;moves++;swaps++;emit("swap_assign_b","intercambiar",-1);
pa=pb=NULL;td=ht=0;emit("swap_return","intercambiar",-1);}
static void heapify(int arreglo[], size_t n, size_t raiz) {frames[depth++]=(Frame){.n=n,.raiz=raiz};emit("heap_entry","heapify",-1);
	size_t mayor=raiz,izquierdo=2*raiz+1,derecho=2*raiz+2;F.mayor=mayor;F.izquierdo=izquierdo;F.derecho=derecho;F.locals=1;emit("heap_init","heapify",-1);
	if(cond("left_test","heapify",cond("left_bound","heapify",izquierdo<n) && cond("left_compare","heapify",arreglo[izquierdo]>arreglo[mayor]))){mayor=izquierdo;F.mayor=mayor;emit("largest_left","heapify",-1);}
	if(cond("right_test","heapify",cond("right_bound","heapify",derecho<n) && cond("right_compare","heapify",arreglo[derecho]>arreglo[mayor]))){mayor=derecho;F.mayor=mayor;emit("largest_right","heapify",-1);}
	if(cond("root_test","heapify",mayor!=raiz)) {
		emit("heap_swap_call","heapify",-1);intercambiar(&arreglo[raiz], &arreglo[mayor]);emit("heap_swap_resume","heapify",-1);
		emit("heap_rec_call","heapify",-1);heapify(arreglo,n,mayor);emit("heap_rec_resume","heapify",-1);
	}
depth--;emit("heap_return","heapify",-1);}
void ordenar_heapsort(int arreglo[], size_t n) {emit("sort_entry","ordenar_heapsort",-1);
	size_t i;emit("i_declare","ordenar_heapsort",-1);
	emit("valid_call","ordenar_heapsort",-1);if(checked(arreglo_valido(arreglo,n))){emit("guard_return","ordenar_heapsort",-1);return;}
	for(i=n/2,wi=i,hi=1,phase="build",emit("build_init","ordenar_heapsort",-1);cond("build_test","ordenar_heapsort",i>0);--i,wi=i,emit("build_decrement","ordenar_heapsort",-1)){emit("build_call","ordenar_heapsort",-1);heapify(arreglo,n,i-1);emit("build_resume","ordenar_heapsort",-1);}
	for(i=n,wi=i,phase="extract",emit("extract_init","ordenar_heapsort",-1);cond("extract_test","ordenar_heapsort",i>1);--i,wi=i,emit("extract_decrement","ordenar_heapsort",-1)) {
		emit("extract_swap_call","ordenar_heapsort",-1);intercambiar(&arreglo[0], &arreglo[i-1]);emit("extract_swap_resume","ordenar_heapsort",-1);
		emit("extract_heap_call","ordenar_heapsort",-1);heapify(arreglo,i-1,0);emit("extract_heap_resume","ordenar_heapsort",-1);
	}
hi=0;phase=NULL;emit("sort_return","ordenar_heapsort",-1);}
int main(void){
{int a[]={7};root=a;count=sizeof(a)/sizeof(a[0]);fixture=0;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(a,count);}
{int a[]={1,2,3,4};root=a;count=sizeof(a)/sizeof(a[0]);fixture=1;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(a,count);}
{int a[]={4,3,2,1};root=a;count=sizeof(a)/sizeof(a[0]);fixture=2;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(a,count);}
{int a[]={2,2,2};root=a;count=sizeof(a)/sizeof(a[0]);fixture=3;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(a,count);}
{int a[]={-3,0,-1,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=4;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(a,count);}
{int a[]={2147483647,-2147483648,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=5;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(a,count);}
{int a=42;root=&a;count=0;fixture=6;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(&a,0);if(a!=42)return 2;}
{root=NULL;count=0;fixture=7;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);ordenar_heapsort(NULL,1);}
{int a=42;root=&a;count=1;fixture=8;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);intercambiar(NULL,&a);if(a!=42)return 3;}
{int a=42;root=&a;count=1;fixture=9;depth=hi=td=ht=comparisons=swaps=moves=0;pa=pb=NULL;phase=NULL;emit("initial",NULL,-1);intercambiar(&a,NULL);if(a!=42)return 4;}return 0;}
