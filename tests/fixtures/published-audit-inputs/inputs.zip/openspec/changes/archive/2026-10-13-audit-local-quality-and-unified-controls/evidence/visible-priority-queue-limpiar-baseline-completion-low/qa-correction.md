# Corrección exclusiva del harness caller

El harness reutilizado de Cola esperaba texto de error del kernel; cp_encolar retorna 0 silenciosamente. La primera corrida preservada falla esa asunción QA, no C17 ni ownership. Se elimina sólo la expectativa stdout diferente y se registra output real y mismo número de mensajes aplicados. Sin modificar cuerpo DOM ni C/H.
