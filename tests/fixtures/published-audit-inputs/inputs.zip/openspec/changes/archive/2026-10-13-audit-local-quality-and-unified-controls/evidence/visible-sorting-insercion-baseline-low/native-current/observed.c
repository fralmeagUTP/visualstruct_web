
#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#include <string.h>
static int *root,*pk,key;static size_t count,*pi,*pj,ci,cj;
static int has_i,has_j,has_key,comparisons,moves,fixture;
static void emit(const char*token,const char*function,int condition){
 if(pi && has_i){ci=*pi;}if(pj && has_j){cj=*pj;}if(pk && has_key){key=*pk;}
 printf("{\"case\":%d,\"event\":{\"token\":\"%s\",\"function\":",fixture,token);
 if(function){printf("\"%s\"",function);}else{printf("null");}
 printf(",\"i\":");if(has_i){printf("%zu",ci);}else{printf("null");}
 printf(",\"j\":");if(has_j){printf("%zu",cj);}else{printf("null");}
 printf(",\"clave\":");if(has_key){printf("%d",key);}else{printf("null");}
 printf(",\"comparisons\":%d,\"moves\":%d},\"condition\":",comparisons,moves);
 if(condition<0){printf("null");}else{printf(condition?"true":"false");}
 printf(",\"array\":[");for(size_t k=0;k<count;k++){if(k){printf(",");}printf("%d",root[k]);}puts("]}");
}
static int cond(const char*t,const char*f,int r){if(!strcmp(t,"while_compare")){comparisons++;}emit(t,f,r);return r;}
static int checked(int r){emit("valid_return","arreglo_valido",-1);return cond("sort_guard","ordenar_insercion",!r);}

static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry","arreglo_valido",-1);
	return cond("valid_ptr","arreglo_valido",arreglo!=NULL) && cond("valid_n","arreglo_valido",n>0);
}
void ordenar_insercion(int arreglo[], size_t n) {emit("sort_entry","ordenar_insercion",-1);
	size_t i;pi=&i;emit("sort_declare","ordenar_insercion",-1);
	emit("valid_call","ordenar_insercion",-1);if(checked(arreglo_valido(arreglo,n))){pi=NULL;emit("guard_return","ordenar_insercion",-1);return;}
	for(i=1,has_i=1,emit("outer_init","ordenar_insercion",-1);cond("outer_test","ordenar_insercion",i<n);++i,emit("outer_increment","ordenar_insercion",-1)) {
		int clave=arreglo[i];pk=&clave;has_key=1;moves++;emit("key_take","ordenar_insercion",-1);
		size_t j=i;pj=&j;has_j=1;emit("j_init","ordenar_insercion",-1);
		while(cond("while_test","ordenar_insercion",cond("while_left","ordenar_insercion",j>0) && cond("while_compare","ordenar_insercion",arreglo[j-1]>clave))) {
			arreglo[j]=arreglo[j-1];moves++;emit("shift","ordenar_insercion",-1);
			--j;emit("j_decrement","ordenar_insercion",-1);
		}
		arreglo[j]=clave;moves++;emit("key_write","ordenar_insercion",-1);
pj=NULL;pk=NULL;has_j=has_key=0;emit("body_exit","ordenar_insercion",-1);	}
pi=NULL;}

int main(void){
{int a[]={7};root=a;count=sizeof(a)/sizeof(a[0]);fixture=0;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(a,count);emit("sort_return","ordenar_insercion",-1);}
{int a[]={1,2};root=a;count=sizeof(a)/sizeof(a[0]);fixture=1;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(a,count);emit("sort_return","ordenar_insercion",-1);}
{int a[]={2,1};root=a;count=sizeof(a)/sizeof(a[0]);fixture=2;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(a,count);emit("sort_return","ordenar_insercion",-1);}
{int a[]={2,2};root=a;count=sizeof(a)/sizeof(a[0]);fixture=3;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(a,count);emit("sort_return","ordenar_insercion",-1);}
{int a[]={-3,0,-1,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=4;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(a,count);emit("sort_return","ordenar_insercion",-1);}
{int a[]={2147483647,-2147483648,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=5;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(a,count);emit("sort_return","ordenar_insercion",-1);}
{int a=42;root=&a;count=0;fixture=6;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(&a,0);}
{root=NULL;count=0;fixture=7;has_i=has_j=has_key=comparisons=moves=0;pi=pj=NULL;pk=NULL;emit("initial",NULL,-1);ordenar_insercion(NULL,1);}
return 0;}
