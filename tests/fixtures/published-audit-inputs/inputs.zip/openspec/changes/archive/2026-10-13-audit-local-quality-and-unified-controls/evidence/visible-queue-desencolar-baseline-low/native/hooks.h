#include <stddef.h>
struct Cola;struct NodoCola;
void qa_event(const char*,struct Cola*,int);int qa_guard(const char*,struct Cola*,int);void qa_aux(struct NodoCola*);void qa_num(int);void qa_result(int);void*qa_malloc(size_t);void qa_free(void*);int qa_printf(const char*,...);
