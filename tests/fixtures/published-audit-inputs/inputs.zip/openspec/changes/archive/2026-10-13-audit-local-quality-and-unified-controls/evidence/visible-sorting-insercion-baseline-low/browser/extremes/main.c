/** @file main.c
 * @brief Reproduce el historial aceptado de Ordenamientos.
 * @details Compilar: gcc -std=c17 -Wall -Wextra -pedantic main.c tad_ordenamiento.c -o ordenamiento
 * Datos aleatorios materializados; no usa rand ni resultados precalculados.
 * Arreglo automatico de 80 enteros. El TAD libera sus auxiliares internos.
 */
#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#include "tad_ordenamiento.h"
#if INT_MAX != 2147483647 || INT_MIN != (-2147483647 - 1)
#error "Este ejemplo reproduce el contrato int32 de la aplicacion."
#endif
/** @brief Ejecuta en orden creaciones y ordenamientos aceptados.
 * @return 0 si termina; 1 si un metodo int reporta un fallo nativo, incluida memoria.
 */
int main(void) {
    int arreglo[80] = {0};
    size_t n = 0;
    /* Nueva creacion: reemplaza los datos corrientes. */
    n = 3;
    arreglo[0] = INT_MAX;
    arreglo[1] = INT_MIN;
    arreglo[2] = 0;
    imprimir_arreglo(arreglo, n);
    /* Metodo preparado: ordenar_insercion; seleccion no ejecuta el TAD. */
    printf("Run 1: ordenar_insercion\n");
    ordenar_insercion(arreglo, n);
    imprimir_arreglo(arreglo, n);
    return 0;
}
