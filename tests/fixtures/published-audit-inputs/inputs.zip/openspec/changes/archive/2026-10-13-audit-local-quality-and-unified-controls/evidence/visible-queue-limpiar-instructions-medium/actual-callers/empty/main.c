#include <stddef.h>
#include <stdio.h>
#include "tad_cola.h"
/** @file main.c @brief Reproduce el historial FIFO y libera los nodos propios. */
/** @brief Ejecuta operaciones registradas; informa fallo de reserva antes de anunciar éxito. @return 0 en éxito, 1 si una reserva falla o un entero no es representable. */
int main(void) {
    struct Cola cola = { .delante = NULL, .atras = NULL };
    // Historial de ejecucion del usuario
    // Operacion registrada: limpiar
    cola_vaciar(&cola);
    puts("Operacion aplicada.");
    // Operacion registrada: limpiar
    cola_vaciar(&cola);
    puts("Operacion aplicada.");
    /* Liberar propiedad del caller al terminar */ cola_vaciar(&cola);
    return 0;
}
