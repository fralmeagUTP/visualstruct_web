/** @file main.c
 * @brief Caller Hash H1 generado desde el historial mutante confirmado.
 * @details Enteros C y capacidad fija; recrear libera primero la instancia anterior.
 * Un fallo real de reserva se informa y sale por cleanup. No inyecta fallos QA.
 * Las consultas y operaciones rechazadas no pertenecen a este historial.
 */
#include "tad_tabla_hash.h"
#include <stdio.h>
#include <limits.h>

/** @brief Ejecuta el historial y libera todos los objetos.
 * @return 0 en exito; 1 ante fallo de reserva o insercion.
 */
int main(void) {
    TablaHash tabla = {0};
    int status = 0;
    th_inicializar(&tabla, 17);
    if (!tabla.buckets) { status = 1; goto cleanup; }
    th_destruir(&tabla);
    th_inicializar(&tabla, 3);
    if (!tabla.buckets) { status = 1; goto cleanup; }
    printf("create:%d\n", tabla.capacidad);
    { bool ok = th_insertar(&tabla, 1, 10);
      printf("insert:%d:%d:%d\n", 1, 10, (int)ok);
      if (!ok) { status = 1; goto cleanup; } }
    { bool ok = th_insertar(&tabla, 4, 20);
      printf("insert:%d:%d:%d\n", 4, 20, (int)ok);
      if (!ok) { status = 1; goto cleanup; } }
    { bool ok = th_insertar(&tabla, 7, 30);
      printf("insert:%d:%d:%d\n", 7, 30, (int)ok);
      if (!ok) { status = 1; goto cleanup; } }
    { bool ok = th_insertar(&tabla, 4, 99);
      printf("insert:%d:%d:%d\n", 4, 99, (int)ok);
      if (!ok) { status = 1; goto cleanup; } }
    printf("state:%d:%d\n", tabla.capacidad, tabla.cantidad);
cleanup:
    th_destruir(&tabla);
    return status;
}
