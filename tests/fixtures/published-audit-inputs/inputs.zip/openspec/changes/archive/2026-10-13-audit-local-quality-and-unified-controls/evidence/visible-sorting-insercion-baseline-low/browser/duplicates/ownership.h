#include <stddef.h>
void *owned_malloc(size_t);
void *owned_calloc(size_t,size_t);
void owned_free(void*);
