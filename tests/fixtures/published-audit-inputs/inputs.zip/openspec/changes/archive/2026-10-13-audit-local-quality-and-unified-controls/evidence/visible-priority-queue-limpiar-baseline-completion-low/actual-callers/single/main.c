#include <stdio.h>
#include "tad_cola_prioridad.h"
int main(void) {
    // Declaracion de la estructura
    ColaPrioridad cp;
    cp_inicializar(&cp);
 
    // Historial de ejecucion del usuario
    cp_encolar(&cp, -1, 2);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cp_vaciar(&cp);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    cp_vaciar(&cp);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    return 0;
}
