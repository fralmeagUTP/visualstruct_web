
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "tad_cola_prioridad.h"
struct cp_nodo {int valor;int prioridad;struct cp_nodo*sgte;};
_Static_assert(_Generic(&cp_encolar,bool(*)(ColaPrioridad*,int,int):1,default:0),"public signature");
static void*objects[64];static int live[64],mask[64],used,allocs,frees,active,sid,fail_next,parent_init,parent_id,helper_init,helper_id,helper_scope,param_value,param_priority;static ColaPrioridad*root;
static int id(void*p){if(!p)return -1;for(int i=0;i<used;i++)if(live[i]&&objects[i]==p)return i;assert(0);return -1;}
void qa_helper_scope(int state){if(active){helper_scope=state;if(state){helper_init=0;helper_id=-1;}}}
void qa_capture(void*p,int helper){if(!active)return;if(helper){helper_init=1;helper_id=id(p);}else{parent_init=1;parent_id=id(p);}}
void qa_field(void*p,int bit){mask[id(p)]|=bit;}
void qa_event(const char*event,ColaPrioridad*p,int condition){if(!active)return;(void)p;
 printf("{\"sample\":%d,\"event\":\"%s\",\"condition\":%d,\"value_parameter\":%d,\"priority_parameter\":%d,\"root_NULL\":%d,\"parent_new_initialized\":%d,\"parent_new_id\":%d,\"helper_active\":%d,\"helper_new_initialized\":%d,\"helper_new_id\":%d,\"front_id\":%d,\"rear_id\":%d,\"quantity\":%d,\"root_items\":[",sid,event,condition,param_value,param_priority,root==NULL,parent_init,parent_init?parent_id:-1,helper_scope,helper_init,helper_init?helper_id:-1,root?id(root->delante):-1,root?id(root->atras):-1,root?root->cantidad:0);
 struct cp_nodo*n=root?root->delante:NULL;int comma=0,index=0,out=-1,best=0;while(n){assert(mask[id(n)]==7);if(comma++)putchar(',');printf("{\"value\":%d,\"priority\":%d}",n->valor,n->prioridad);if(out==-1||n->prioridad<best){out=index;best=n->prioridad;}index++;n=n->sgte;}printf("],\"out_index\":%d,\"live\":[",out);comma=0;
 for(int i=0;i<used;i++){if(live[i]){if(comma++)putchar(',');struct cp_nodo*n=objects[i];printf("{\"id\":%d,\"mask\":%d,\"value\":",i,mask[i]);if(mask[i]&1)printf("%d",n->valor);else fputs("null",stdout);fputs(",\"priority\":",stdout);if(mask[i]&2)printf("%d",n->prioridad);else fputs("null",stdout);fputs(",\"next_id\":",stdout);if(mask[i]&4)printf("%d",id(n->sgte));else fputs("null",stdout);putchar('}');}}
 puts("]}");}
int qa_guard(const char*event,ColaPrioridad*p,int condition){qa_event(event,p,condition);return condition;}
void*qa_malloc(size_t size){qa_event("allocator_enter",root,-1);if(active&&fail_next){fail_next=0;qa_event("allocator_NULL_return",root,-1);return NULL;}void*p=malloc(size);assert(p&&used<64);objects[used]=p;live[used]=1;mask[used++]=0;allocs++;qa_event("allocator_success_return",root,-1);return p;}
void qa_free(void*p){if(!p)return;int i=id(p);live[i]=0;objects[i]=NULL;mask[i]=0;frees++;free(p);}
static void sample(ColaPrioridad*p,int v,int priority,int fault){root=p;param_value=v;param_priority=priority;parent_init=helper_init=helper_scope=0;parent_id=helper_id=-1;fail_next=fault;active=1;bool result=cp_encolar(p,v,priority);active=0;assert(result==(p!=NULL&&!fault));sid++;root=NULL;}
int main(void){{ColaPrioridad cp;cp_inicializar(&cp);sample(&cp,9,3,0);sample(&cp,9,3,0);sample(&cp,9,3,1);cp_vaciar(&cp);}{ColaPrioridad cp;cp_inicializar(&cp);assert(cp_encolar(&cp,7,2));sample(&cp,-1,-1,0);sample(&cp,-1,-1,0);sample(&cp,-1,-1,1);cp_vaciar(&cp);}{ColaPrioridad cp;cp_inicializar(&cp);assert(cp_encolar(&cp,7,1));sample(&cp,7,1,0);sample(&cp,7,1,0);sample(&cp,7,1,1);cp_vaciar(&cp);}{ColaPrioridad cp;cp_inicializar(&cp);assert(cp_encolar(&cp,INT_MAX,INT_MAX));assert(cp_encolar(&cp,-1,-1));sample(&cp,INT_MIN,INT_MIN,0);sample(&cp,INT_MIN,INT_MIN,0);sample(&cp,INT_MIN,INT_MIN,1);cp_vaciar(&cp);}sample(NULL,9,3,0);{ColaPrioridad cp;cp_inicializar(&cp);sample(&cp,9,3,1);assert(!cp.delante&&!cp.atras&&cp.cantidad==0);}assert(allocs==frees);for(int i=0;i<used;i++)assert(!live[i]);fprintf(stderr,"OWNERSHIP %d %d 0\n",allocs,frees);return 0;}