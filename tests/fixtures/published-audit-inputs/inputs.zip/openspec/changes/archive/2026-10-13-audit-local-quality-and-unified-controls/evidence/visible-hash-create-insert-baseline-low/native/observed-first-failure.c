#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <limits.h>
#include <assert.h>
#include "tad_tabla_hash.h"
static TablaHash *root;static int case_id,operation_id,init_active,insert_active,index_active;
static int have_index,have_actual,have_new,have_i,index_value,loop_i,input_key,input_value,input_capacity;
static THNodo *obs_actual,*obs_new;static unsigned char bucket_mask[64];
static void *objects[128];static int kinds[128],masks[128],live[128],used,allocations,frees,attempts,fail_at,alloc_kind;
static int comparisons,hash_calls,link_writes,value_writes,key_writes,count_writes;
static int identity(const void*p){if(!p)return 0;for(int i=used-1;i>=0;i--)if(live[i]&&objects[i]==p)return i+1;assert(0);return 0;}
static void *qa_malloc(size_t size){attempts++;if(fail_at&&attempts==fail_at)return NULL;void*p=malloc(size);if(p){assert(used<128);objects[used]=p;kinds[used]=alloc_kind;masks[used]=0;live[used++]=1;allocations++;}return p;}
static void qa_free(void*p){if(p){int id=identity(p);live[id-1]=0;frees++;}free(p);}
static void scalar(const char*name,int initialized,int value){printf(",\"%s\":",name);if(initialized)printf("%d",value);else printf("null");}
static void emit(const char*token,int condition,int status){
 printf("{\"case\":%d,\"operation\":%d,\"token\":\"%s\",\"condition\":",case_id,operation_id,token);if(condition<0)printf("null");else printf(condition?"true":"false");
 printf(",\"capacity\":%d,\"size\":%d,\"bucket_pointer\":%d,\"buckets\":[",root->capacidad,root->cantidad,identity(root->buckets));
 if(root->buckets)for(int i=0;i<root->capacidad;i++){if(i)printf(",");printf("{\"index\":%d,\"initialized\":%s,\"chain\":[",i,bucket_mask[i]?"true":"false");if(bucket_mask[i]){THNodo*p=root->buckets[i];int count=0;while(p){int id=identity(p);assert(masks[id-1]==7);if(count++)printf(",");assert(count<64);printf("{\"id\":%d,\"key\":%d,\"value\":%d,\"next\":%d}",id,p->clave,p->valor,identity(p->siguiente));p=p->siguiente;}}printf("]}");}printf("]");
 printf(",\"heap\":[");int comma=0;for(int j=0;j<used;j++)if(live[j]){if(comma++)printf(",");printf("{\"id\":%d,\"kind\":%d,\"initialized_mask\":%d",j+1,kinds[j],masks[j]);if(kinds[j]==2){THNodo*p=objects[j];scalar("key",masks[j]&1,p&& (masks[j]&1)?p->clave:0);scalar("value",masks[j]&2,p&&(masks[j]&2)?p->valor:0);scalar("next",masks[j]&4,p&&(masks[j]&4)?identity(p->siguiente):0);}printf("}");}printf("]");
 printf(",\"init_active\":%s,\"insert_active\":%s,\"index_active\":%s",init_active?"true":"false",insert_active?"true":"false",index_active?"true":"false");scalar("indice",have_index,index_value);scalar("i",have_i,loop_i);scalar("actual",have_actual,insert_active&&have_actual?identity(obs_actual):0);scalar("nuevo",have_new,insert_active&&have_new?identity(obs_new):0);
 printf(",\"key\":%d,\"value\":%d,\"capacity_parameter\":%d,\"allocations\":%d,\"frees\":%d,\"live\":%d,\"attempts\":%d,\"comparisons\":%d,\"hash_calls\":%d,\"link_writes\":%d,\"value_writes\":%d,\"key_writes\":%d,\"count_writes\":%d",input_key,input_value,input_capacity,allocations,frees,allocations-frees,attempts,comparisons,hash_calls,link_writes,value_writes,key_writes,count_writes);scalar("return_status",status>=0,status);printf("}\n");
}
static int cond(const char*t,int value){if(!strcmp(t,"key_compare"))comparisons++;emit(t,value,-1);return value;}
#define INSERT_RETURN(v) do{insert_active=have_actual=have_new=have_index=0;obs_actual=obs_new=NULL;emit("insert_return",-1,(v));return(v);}while(0)
#define malloc qa_malloc
#define free qa_free
#include "tad_tabla_hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

/**
 * @file tad_tabla_hash.c
 * @brief Implementación del TAD Tabla Hash.
 */

/**
 * @brief Ajunta texto formateado dentro de un buffer acotado.
 * @param destino Buffer de salida.
 * @param capacidad Tamaño total del buffer, incluido el terminador.
 * @param usado Contador de bytes usados que se actualiza o satura a capacidad.
 * @param fmt Formato de vsnprintf para los argumentos variables.
 */
static void th_append_text(char *destino, size_t capacidad, size_t *usado, const char *fmt, ...) {
    va_list args;
    int escritos;

    if (destino == NULL || usado == NULL || *usado >= capacidad) {
        return;
    }

    va_start(args, fmt);
    escritos = vsnprintf(destino + *usado, capacidad - *usado, fmt, args);
    va_end(args);
    if (escritos < 0) {
        return;
    }
    if ((size_t)escritos >= capacidad - *usado) {
        *usado = capacidad;
    } else {
        *usado += (size_t)escritos;
    }
}

/**
 * @brief Normaliza el módulo de una clave, incluidas claves negativas.
 * @param tabla Tabla con capacidad positiva.
 * @param clave Clave entera.
 * @return Índice entre 0 y capacidad-1, o -1 ante tabla NULL o capacidad no positiva.
 */
int th_indice(const TablaHash *tabla, int clave) {
 index_active=1;hash_calls++;emit("index_entry",-1,-1);
 if(cond("index_guard",!tabla || tabla->capacidad<=0)){index_active=0;emit("index_return",-1,-1);return -1;}
 int indice=clave%tabla->capacidad;index_value=indice;have_index=1;emit("raw_modulo",-1,-1);
 if(cond("negative_modulo_guard",indice<0)){indice+=tabla->capacidad;index_value=indice;emit("normalize_modulo",-1,-1);}
 index_active=0;emit("index_return",-1,indice);return indice;
}

/*
 * @brief Inicializa la tabla hash.
 * @param tabla Puntero a la tabla hash.
 * @param capacidad Capacidad (número de buckets) de la tabla.
 */
/**
 * @brief Inicializa la tabla hash.
 * @param[out] tabla Puntero a la tabla hash.
 * @param[in] capacidad Capacidad (número de buckets) de la tabla.
 */
void th_inicializar(TablaHash *tabla,int capacidad){
 init_active=1;emit("init_entry",-1,-1);
 if(cond("init_guard",!tabla || capacidad<=0)){init_active=0;emit("init_return",-1,-1);return;}
 tabla->capacidad=capacidad;emit("capacity_write",-1,-1);tabla->cantidad=0;count_writes++;emit("size_zero",-1,-1);
 alloc_kind=1;memset(bucket_mask,0,sizeof(bucket_mask));tabla->buckets=(THNodo**)malloc(capacidad*sizeof(THNodo*));emit("bucket_allocate",-1,-1);
 if(cond("bucket_allocation_guard",tabla->buckets!=NULL)){
  for(int i=0,unused=(loop_i=0,have_i=1,emit("bucket_loop_init",-1,-1),0);cond("bucket_loop_test",i<capacidad);i++,loop_i=i,emit("bucket_loop_increment",-1,-1)){
   (void)unused;tabla->buckets[i]=NULL;bucket_mask[i]=1;link_writes++;emit("bucket_null_write",-1,-1);
  }
  have_i=0;
 }else{tabla->capacidad=0;emit("allocation_error_capacity",-1,-1);}
 init_active=0;emit("init_return",-1,-1);
}

/*
 * @brief Inserta un par clave-valor, actualizando el valor si la clave existe.
 * @param tabla Puntero a la tabla hash.
 * @param clave Clave a insertar.
 * @param valor Valor asociado a la clave.
 * @return true si se insertó o actualizó correctamente, false en error.
 */
/**
 * @brief Inserta un par clave-valor, actualizando el valor si la clave existe.
 * @param[in,out] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a insertar.
 * @param[in] valor Valor asociado a la clave.
 * @return true si se insertó o actualizó correctamente, false en error.
 */
bool th_insertar(TablaHash *tabla,int clave,int valor){
 insert_active=1;have_index=have_actual=have_new=0;emit("insert_entry",-1,-1);
 if(cond("insert_guard",!tabla || !tabla->buckets || tabla->capacidad<=0))INSERT_RETURN(false);
 emit("index_call",-1,-1);int indice=th_indice(tabla,clave);index_value=indice;have_index=1;emit("index_assign",-1,-1);
 THNodo*actual=tabla->buckets[indice];obs_actual=actual;have_actual=1;emit("actual_init",-1,-1);
 while(cond("search_test",actual!=NULL)){
  if(cond("key_compare",actual->clave==clave)){actual->valor=valor;value_writes++;emit("update_value",-1,-1);INSERT_RETURN(true);}
  actual=actual->siguiente;obs_actual=actual;emit("actual_advance",-1,-1);
 }
 alloc_kind=2;THNodo*nuevo=(THNodo*)malloc(sizeof(THNodo));obs_new=nuevo;have_new=1;emit("node_allocate",-1,-1);
 if(cond("node_null_guard",!nuevo))INSERT_RETURN(false);
 nuevo->clave=clave;masks[identity(nuevo)-1]|=1;key_writes++;emit("node_key_write",-1,-1);
 nuevo->valor=valor;masks[identity(nuevo)-1]|=2;value_writes++;emit("node_value_write",-1,-1);
 nuevo->siguiente=tabla->buckets[indice];masks[identity(nuevo)-1]|=4;link_writes++;emit("node_next_write",-1,-1);
 tabla->buckets[indice]=nuevo;link_writes++;emit("head_publish",-1,-1);
 tabla->cantidad++;count_writes++;emit("size_increment",-1,-1);INSERT_RETURN(true);
}

/*
 * @brief Busca el valor asociado a una clave.
 * @param tabla Puntero a la tabla hash constante.
 * @param clave Clave a buscar.
 * @param valor Puntero donde se almacenará el valor si se encuentra.
 * @return true si se encontró la clave, false si no.
 */
/**
 * @brief Busca el valor asociado a una clave.
 * @param[in] tabla Puntero a la tabla hash constante.
 * @param[in] clave Clave a buscar.
 * @param[out] valor Puntero donde se almacenará el valor si se encuentra.
 * @return true si se encontró la clave, false si no.
 */
bool th_buscar(const TablaHash *tabla, int clave, int *valor) {
    if (!tabla || !tabla->buckets || tabla->capacidad <= 0 || !valor) return false;
    
    int indice = th_indice(tabla, clave);
    THNodo *actual = tabla->buckets[indice];
    
    while (actual != NULL) {
        if (actual->clave == clave) {
            *valor = actual->valor;
            return true;
        }
        actual = actual->siguiente;
    }
    
    return false;
}

/*
 * @brief Verifica si una clave existe en la tabla.
 * @param tabla Puntero a la tabla hash.
 * @param clave Clave a verificar.
 * @return true si la clave existe, false si no.
 */
/**
 * @brief Verifica si una clave existe en la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a verificar.
 * @return true si la clave existe, false si no.
 */
bool th_contiene(const TablaHash *tabla, int clave) {
    int dummy_valor;
    return th_buscar(tabla, clave, &dummy_valor);
}

/*
 * @brief Elimina una clave de la tabla hash.
 * @param tabla Puntero a la tabla hash.
 * @param clave Clave a eliminar.
 * @return true si fue eliminada, false si no existía o error.
 */
/**
 * @brief Elimina una clave de la tabla hash.
 * @param[in,out] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a eliminar.
 * @return true si fue eliminada, false si no existía o error.
 */
bool th_eliminar(TablaHash *tabla, int clave) {
    if (!tabla || !tabla->buckets || tabla->capacidad <= 0) return false;
    
    int indice = th_indice(tabla, clave);
    THNodo *actual = tabla->buckets[indice];
    THNodo *anterior = NULL;
    
    while (actual != NULL) {
        if (actual->clave == clave) {
            if (anterior == NULL) {
                tabla->buckets[indice] = actual->siguiente;
            } else {
                anterior->siguiente = actual->siguiente;
            }
            free(actual);
            tabla->cantidad--;
            return true;
        }
        anterior = actual;
        actual = actual->siguiente;
    }
    
    return false;
}

/*
 * @brief Elimina todos los elementos manteniendo la capacidad de la tabla.
 * @param tabla Puntero a la tabla hash.
 */
/**
 * @brief Elimina todos los elementos manteniendo la capacidad de la tabla.
 * @param[in,out] tabla Puntero a la tabla hash.
 */
void th_vaciar(TablaHash *tabla) {
    if (!tabla || !tabla->buckets) return;
    
    for (int i = 0; i < tabla->capacidad; i++) {
        THNodo *actual = tabla->buckets[i];
        while (actual != NULL) {
            THNodo *siguiente = actual->siguiente;
            free(actual);
            actual = siguiente;
        }
        tabla->buckets[i] = NULL;
    }
    tabla->cantidad = 0;
}

/*
 * @brief Destruye la tabla hash liberando toda su memoria.
 * @param tabla Puntero a la tabla hash.
 */
/**
 * @brief Destruye la tabla hash liberando toda su memoria.
 * @param[in,out] tabla Puntero a la tabla hash.
 */
void th_destruir(TablaHash *tabla) {
    if (!tabla || !tabla->buckets) return;
    
    th_vaciar(tabla);
    free(tabla->buckets);
    tabla->buckets = NULL;
    tabla->capacidad = 0;
    tabla->cantidad = 0;
}

/*
 * @brief Indica si la tabla está vacía.
 * @param tabla Puntero a la tabla hash.
 * @return true si la cantidad es 0, false caso contrario.
 */
/**
 * @brief Indica si la tabla está vacía.
 * @param[in] tabla Puntero a la tabla hash.
 * @return true si la cantidad es 0, false caso contrario.
 */
bool th_vacia(const TablaHash *tabla) {
    if (!tabla) return true;
    return tabla->cantidad == 0;
}

/*
 * @brief Retorna la cantidad de elementos en la tabla.
 * @param tabla Puntero a la tabla hash.
 * @return Cantidad de elementos almacenados.
 */
/**
 * @brief Retorna la cantidad de elementos en la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Cantidad de elementos almacenados.
 */
int th_cantidad(const TablaHash *tabla) {
    if (!tabla) return 0;
    return tabla->cantidad;
}

/*
 * @brief Retorna la capacidad actual de la tabla.
 * @param tabla Puntero a la tabla hash.
 * @return Capacidad (número de buckets).
 */
/**
 * @brief Retorna la capacidad actual de la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Capacidad (número de buckets).
 */
int th_capacidad(const TablaHash *tabla) {
    if (!tabla) return 0;
    return tabla->capacidad;
}

/*
 * @brief Calcula y retorna las estadísticas de la tabla hash.
 * @param tabla Puntero a la tabla hash.
 * @return Estructura con las estadísticas calculadas.
 */
/**
 * @brief Calcula y retorna las estadísticas de la tabla hash.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Estructura con las estadísticas calculadas.
 */
THEstadisticas th_estadisticas(const TablaHash *tabla) {
    THEstadisticas stats = {0};
    
    if (!tabla || !tabla->buckets || tabla->capacidad <= 0) return stats;
    
    stats.capacidad = tabla->capacidad;
    stats.cantidad = tabla->cantidad;
    stats.factor_carga = (float)tabla->cantidad / (float)tabla->capacidad;
    
    for (int i = 0; i < tabla->capacidad; i++) {
        THNodo *actual = tabla->buckets[i];
        if (actual != NULL) {
            stats.buckets_ocupados++;
            int nodos_en_bucket = 0;
            while (actual != NULL) {
                nodos_en_bucket++;
                actual = actual->siguiente;
            }
            if (nodos_en_bucket > 1) {
                stats.colisiones += (nodos_en_bucket - 1);
            }
        }
    }
    
    return stats;
}

/*
 * @brief Formatea el contenido de la tabla hash en una cadena de texto.
 * @param tabla Puntero a la tabla hash.
 * @param destino Buffer donde se escribirá la representación.
 * @param capacidad Tamaño máximo del buffer destino.
 */
/**
 * @brief Formatea el contenido de la tabla hash en una cadena de texto.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[out] destino Buffer donde se escribirá la representación.
 * @param[in] capacidad Tamaño máximo del buffer destino.
 */
void th_formatear(const TablaHash *tabla, char *destino, size_t capacidad) {
    if (!destino || capacidad == 0) return;
    destino[0] = '\0';
    
    if (!tabla || !tabla->buckets) {
        snprintf(destino, capacidad, "Tabla no inicializada\n");
        return;
    }
    
    size_t usado = 0;
    for (int i = 0; i < tabla->capacidad && usado < capacidad; i++) {
        th_append_text(destino, capacidad, &usado, "[%d] -> ", i);
        
        THNodo *actual = tabla->buckets[i];
        while (actual != NULL && usado < capacidad) {
            th_append_text(destino, capacidad, &usado, "(%d:%d) -> ", actual->clave, actual->valor);
            actual = actual->siguiente;
        }
        
        if (usado < capacidad) {
            th_append_text(destino, capacidad, &usado, "NULL\n");
        }
    }
}

/*
 * @brief Formatea las estadísticas de la tabla en una cadena de texto.
 * @param tabla Puntero a la tabla hash.
 * @param destino Buffer donde se escribirá la representación.
 * @param capacidad Tamaño máximo del buffer destino.
 */
/**
 * @brief Formatea las estadísticas de la tabla en una cadena de texto.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[out] destino Buffer donde se escribirá la representación.
 * @param[in] capacidad Tamaño máximo del buffer destino.
 */
void th_formatear_estadisticas(const TablaHash *tabla, char *destino, size_t capacidad) {
    if (!destino || capacidad == 0) return;
    destino[0] = '\0';
    
    if (!tabla || !tabla->buckets) {
        snprintf(destino, capacidad, "Tabla no inicializada\n");
        return;
    }
    
    THEstadisticas stats = th_estadisticas(tabla);
    snprintf(destino, capacidad, 
             "Capacidad: %d\n"
             "Cantidad: %d\n"
             "Buckets ocupados: %d\n"
             "Colisiones: %d\n"
             "Factor de carga: %.2f\n",
             stats.capacidad, stats.cantidad, stats.buckets_ocupados, 
             stats.colisiones, stats.factor_carga);
}

#undef malloc
#undef free
static void setup(TablaHash*t,int id,int fault){root=t;case_id=id;operation_id=0;init_active=insert_active=index_active=have_index=have_actual=have_new=have_i=0;obs_actual=obs_new=NULL;used=allocations=frees=attempts=comparisons=hash_calls=link_writes=value_writes=key_writes=count_writes=0;input_key=input_value=0;fail_at=fault;memset(live,0,sizeof(live));memset(bucket_mask,0,sizeof(bucket_mask));}
static void cleanup(void){have_index=have_actual=have_new=have_i=0;obs_actual=obs_new=NULL;th_destruir(root);emit("cleanup",-1,-1);assert(allocations==frees);}
int main(void){_Static_assert(sizeof(int)==4,"int32");{TablaHash t={0};setup(&t,0,0);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,1,0);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);bool ok_0=th_insertar(&t,input_key,input_value);assert(ok_0);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,2,0);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);bool ok_0=th_insertar(&t,input_key,input_value);assert(ok_0);operation_id=2;input_key=4;input_value=20;emit("initial",-1,-1);bool ok_1=th_insertar(&t,input_key,input_value);assert(ok_1);operation_id=3;input_key=7;input_value=30;emit("initial",-1,-1);bool ok_2=th_insertar(&t,input_key,input_value);assert(ok_2);operation_id=4;input_key=10;input_value=40;emit("initial",-1,-1);bool ok_3=th_insertar(&t,input_key,input_value);assert(ok_3);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,3,0);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);bool ok_0=th_insertar(&t,input_key,input_value);assert(ok_0);operation_id=2;input_key=4;input_value=20;emit("initial",-1,-1);bool ok_1=th_insertar(&t,input_key,input_value);assert(ok_1);operation_id=3;input_key=4;input_value=99;emit("initial",-1,-1);bool ok_2=th_insertar(&t,input_key,input_value);assert(ok_2);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,4,0);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);bool ok_0=th_insertar(&t,input_key,input_value);assert(ok_0);operation_id=2;input_key=4;input_value=20;emit("initial",-1,-1);bool ok_1=th_insertar(&t,input_key,input_value);assert(ok_1);operation_id=3;input_key=7;input_value=30;emit("initial",-1,-1);bool ok_2=th_insertar(&t,input_key,input_value);assert(ok_2);operation_id=4;input_key=4;input_value=99;emit("initial",-1,-1);bool ok_3=th_insertar(&t,input_key,input_value);assert(ok_3);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,5,0);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);bool ok_0=th_insertar(&t,input_key,input_value);assert(ok_0);operation_id=2;input_key=4;input_value=20;emit("initial",-1,-1);bool ok_1=th_insertar(&t,input_key,input_value);assert(ok_1);operation_id=3;input_key=7;input_value=30;emit("initial",-1,-1);bool ok_2=th_insertar(&t,input_key,input_value);assert(ok_2);operation_id=4;input_key=1;input_value=99;emit("initial",-1,-1);bool ok_3=th_insertar(&t,input_key,input_value);assert(ok_3);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,6,0);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=-1;input_value=-10;emit("initial",-1,-1);bool ok_0=th_insertar(&t,input_key,input_value);assert(ok_0);operation_id=2;input_key=-4;input_value=-2147483648;emit("initial",-1,-1);bool ok_1=th_insertar(&t,input_key,input_value);assert(ok_1);operation_id=3;input_key=-2147483648;input_value=2147483647;emit("initial",-1,-1);bool ok_2=th_insertar(&t,input_key,input_value);assert(ok_2);operation_id=4;input_key=2147483647;input_value=0;emit("initial",-1,-1);bool ok_3=th_insertar(&t,input_key,input_value);assert(ok_3);operation_id=5;input_key=0;input_value=-1;emit("initial",-1,-1);bool ok_4=th_insertar(&t,input_key,input_value);assert(ok_4);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,7,0);input_capacity=17;emit("initial",-1,-1);th_inicializar(&t,17);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);bool ok_0=th_insertar(&t,input_key,input_value);assert(ok_0);operation_id=2;input_key=18;input_value=20;emit("initial",-1,-1);bool ok_1=th_insertar(&t,input_key,input_value);assert(ok_1);operation_id=3;input_key=35;input_value=30;emit("initial",-1,-1);bool ok_2=th_insertar(&t,input_key,input_value);assert(ok_2);operation_id=4;input_key=52;input_value=40;emit("initial",-1,-1);bool ok_3=th_insertar(&t,input_key,input_value);assert(ok_3);operation_id=5;input_key=18;input_value=99;emit("initial",-1,-1);bool ok_4=th_insertar(&t,input_key,input_value);assert(ok_4);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,20,2);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);(void)th_insertar(&t,input_key,input_value);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,21,3);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=1;input_key=1;input_value=10;emit("initial",-1,-1);(void)th_insertar(&t,input_key,input_value);operation_id=2;input_key=1;input_value=99;emit("initial",-1,-1);(void)th_insertar(&t,input_key,input_value);operation_id=99;cleanup();}{TablaHash t={0};setup(&t,22,1);input_capacity=3;emit("initial",-1,-1);th_inicializar(&t,3);operation_id=99;cleanup();}return 0;}