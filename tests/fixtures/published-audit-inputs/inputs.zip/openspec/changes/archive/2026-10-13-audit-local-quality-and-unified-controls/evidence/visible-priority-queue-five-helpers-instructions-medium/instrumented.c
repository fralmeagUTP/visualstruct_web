/**
 * @file tad_cola_prioridad.c
 * @brief Implementación del TAD Cola de prioridad en orden de llegada.
 */

#include "tad_cola_prioridad.h"

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

/**
 * @brief Nodo interno de cola de prioridad, enlazado en orden de llegada.
 */
struct cp_nodo {
    int valor; /**< Dato almacenado. */
    int prioridad; /**< Prioridad del elemento. */
    struct cp_nodo *sgte; /**< Enlace al siguiente nodo. */
};

/**
 * @brief Agrega texto formateado en un buffer de tamaño acotado.
 * @param destino Buffer de salida.
 * @param capacidad Capacidad total en bytes, incluido el terminador.
 * @param usado Contador actualizado de bytes; se satura a capacidad si hay truncamiento.
 * @param fmt Formato de vsnprintf para los argumentos variables.
 */

#include <assert.h>
static FILE *audit_file;
static ColaPrioridad *audit_queue;
static CPNodo *audit_nodes,*audit_aux;
static int audit_n,audit_mask,audit_active,audit_helper,audit_aux_init,audit_count_init,audit_used_init,audit_args,audit_written_init;
static int *audit_values,*audit_priorities,*audit_count;
static size_t *audit_used;
static char *audit_bytes;
static int audit_cap,audit_value_marks[6],audit_priority_marks[6],audit_byte_marks[130],audit_result_set,audit_result,audit_written;
static const char *audit_terms[8];static int audit_term_results[8],audit_terms_n;
void audit_set_file(const char *path){assert(!audit_file);audit_file=fopen(path,"w");assert(audit_file);}
static int audit_node_id(const CPNodo *p){if(!p)return -1;for(int i=0;i<audit_n;i++)if(p==&audit_nodes[i])return i;assert(0);return -2;}
static int audit_operand(const char *source,int result){assert(audit_terms_n<8);audit_terms[audit_terms_n]=source;audit_term_results[audit_terms_n++]=!!result;return !!result;}
static void audit_emit(const char *fn,const char *event,int line,int condition){
 assert(audit_file);
 fprintf(audit_file,"{\"function\":\"%s\",\"event\":\"%s\",\"C_line\":%d,\"condition\":",fn,event,line);
 if(condition<0)fputs("null",audit_file);else fputs(condition?"true":"false",audit_file);
 fputs(",\"operands\":[",audit_file);
 for(int i=0;i<audit_terms_n;i++){if(i)fputc(',',audit_file);fprintf(audit_file,"{\"source\":\"%s\",\"result\":%s}",audit_terms[i],audit_term_results[i]?"true":"false");}
 audit_terms_n=0;
 fprintf(audit_file,"],\"root\":{\"mask\":%d,\"front\":%d,\"rear\":%d,\"count\":",audit_mask,(audit_mask&1)?audit_node_id(audit_queue->delante):-1,(audit_mask&2)?audit_node_id(audit_queue->atras):-1);
 if(audit_mask&4)fprintf(audit_file,"%d",audit_queue->cantidad);else fputs("null",audit_file);
 fprintf(audit_file,"},\"scope\":%s,\"helper_scope\":%s,\"aux_initialized\":%s,\"aux\":%d,\"count_initialized\":%s,\"count\":",audit_active?"true":"false",audit_helper?"true":"false",audit_active&&audit_aux_init?"true":"false",audit_active&&audit_aux_init?audit_node_id(audit_aux):-1,audit_active&&audit_count_init?"true":"false");
 if(audit_active&&audit_count_init)fprintf(audit_file,"%d",*audit_count);else fputs("null",audit_file);
 fprintf(audit_file,",\"used_initialized\":%s,\"used\":",audit_active&&audit_used_init?"true":"false");
 if(audit_active&&audit_used_init)fprintf(audit_file,"%zu",*audit_used);else fputs("null",audit_file);
 fprintf(audit_file,",\"args_live\":%s,\"escritos_initialized\":%s,\"escritos\":",audit_helper&&audit_args?"true":"false",audit_helper&&audit_written_init?"true":"false");
 if(audit_helper&&audit_written_init)fprintf(audit_file,"%d",audit_written);else fputs("null",audit_file);
 fputs(",\"result\":",audit_file);if(audit_result_set)fprintf(audit_file,"%d",audit_result);else fputs("null",audit_file);
 fputs(",\"values\":[",audit_file);for(int i=0;i<6;i++){if(i)fputc(',',audit_file);fprintf(audit_file,"%d",audit_values[i]);}
 fputs("],\"priorities\":[",audit_file);for(int i=0;i<6;i++){if(i)fputc(',',audit_file);fprintf(audit_file,"%d",audit_priorities[i]);}
 fputs("],\"bytes\":[",audit_file);for(int i=0;i<130;i++){if(i)fputc(',',audit_file);fprintf(audit_file,"%u",(unsigned char)audit_bytes[i]);}
 fputs("],\"values_written\":[",audit_file);for(int i=0;i<6;i++){if(i)fputc(',',audit_file);fputs(audit_value_marks[i]?"true":"false",audit_file);}
 fputs("],\"priorities_written\":[",audit_file);for(int i=0;i<6;i++){if(i)fputc(',',audit_file);fputs(audit_priority_marks[i]?"true":"false",audit_file);}
 fputs("],\"bytes_written\":[",audit_file);for(int i=0;i<130;i++){if(i)fputc(',',audit_file);fputs(audit_byte_marks[i]?"true":"false",audit_file);}
 fputs("]}\n",audit_file);
}
static int audit_guard(const char *fn,const char *event,int line,int result){audit_emit(fn,event,line,!!result);return !!result;}
static void audit_return(const char *fn,int line,int has_result,int result){audit_result_set=has_result;audit_result=result;audit_active=0;audit_count=NULL;audit_used=NULL;audit_emit(fn,"return",line,-1);}
static void audit_begin(ColaPrioridad *q,CPNodo *nodes,int n,int mask,int cap,int *values,int *priorities,char *bytes){
 audit_queue=q;audit_nodes=nodes;audit_n=n;audit_mask=mask;audit_cap=cap;audit_values=values;audit_priorities=priorities;audit_bytes=bytes;
 audit_active=1;audit_helper=0;audit_aux_init=0;audit_count_init=0;audit_used_init=0;audit_args=0;audit_written_init=0;audit_result_set=0;audit_terms_n=0;audit_aux=NULL;audit_count=NULL;audit_used=NULL;
 memset(audit_value_marks,0,sizeof audit_value_marks);memset(audit_priority_marks,0,sizeof audit_priority_marks);memset(audit_byte_marks,0,sizeof audit_byte_marks);
}
static void audit_format_marks(char *dest,size_t cap){assert(dest>=audit_bytes&&dest<audit_bytes+130);size_t offset=(size_t)(dest-audit_bytes);assert(offset+cap<=130);for(size_t i=0;i<cap;i++){audit_byte_marks[offset+i]=1;if(!dest[i])break;}}
static void audit_close(void){assert(fclose(audit_file)==0);audit_file=NULL;audit_queue=NULL;audit_nodes=NULL;audit_aux=NULL;audit_count=NULL;audit_used=NULL;}

static void cp_append_text(char *destino, size_t capacidad, size_t *usado, const char *fmt, ...) {
    audit_helper=1;audit_args=0;audit_written_init=0;audit_emit("cp_append_text","entry",28,-1);
    va_list args;
    audit_emit("cp_append_text","declare-args",29,-1);
    int escritos;
    audit_emit("cp_append_text","declare-escritos",30,-1);

    if (audit_guard("cp_append_text","guard",32,(audit_operand("destino == NULL",(destino == NULL)) || audit_operand("usado == NULL",(usado == NULL)) || audit_operand("*usado >= capacidad",(*usado >= capacidad))))) {
    audit_helper=0;audit_emit("cp_append_text","return",33,-1);
        return;
    }

    va_start(args, fmt);
    audit_args=1;audit_emit("cp_append_text","va-start",36,-1);
    escritos = vsnprintf(destino + *usado, capacidad - *usado, fmt, args);
    audit_written=escritos;audit_written_init=1;audit_format_marks(destino+*usado,capacidad-*usado);audit_emit("cp_append_text","format",37,-1);
    va_end(args);
    audit_args=0;audit_emit("cp_append_text","va-end",38,-1);
    if (audit_guard("cp_append_text","format-error",39,(audit_operand("escritos < 0",(escritos < 0))))) {
    audit_helper=0;audit_emit("cp_append_text","return",40,-1);
        return;
    }
    if (audit_guard("cp_append_text","truncation",42,(audit_operand("(size_t)escritos >= capacidad - *usado",((size_t)escritos >= capacidad - *usado))))) {
        *usado = capacidad;
    audit_emit("cp_append_text","saturate",43,-1);
    } else {
        *usado += (size_t)escritos;
    audit_emit("cp_append_text","append-count",45,-1);
    }
    audit_helper=0;audit_emit("cp_append_text","end",47,-1);
}

/**
 * @brief Reserva e inicializa un nodo con enlace siguiente NULL.
 * @param valor Dato a almacenar.
 * @param prioridad Prioridad que se consulta al seleccionar la extracción.
 * @return Nodo reservado o NULL si falla malloc; el llamador adquiere su propiedad.
 */
static CPNodo *cp_crear_nodo(int valor, int prioridad) {
    CPNodo *nuevo = (CPNodo *)malloc(sizeof(CPNodo));
    if (nuevo == NULL) {
        return NULL;
    }
    nuevo->valor = valor;
    nuevo->prioridad = prioridad;
    nuevo->sgte = NULL;
    return nuevo;
}

/*
 * @brief Inicializa una ColaPrioridad poniéndola en estado vacío.
 *
 * Establece @c delante y @c atras a NULL. Debe ser la primera llamada
 * antes de operar sobre la cola. No reserva memoria dinámica.
 *
 * @param cola Puntero a la ColaPrioridad que se va a inicializar.
 *                  Si es NULL la función no hace nada.
 *
 * @post La cola queda vacía y lista para usarse.
 */
/**
 * @brief Inicializa una ColaPrioridad poniéndola en estado vacío.
 *
 * Establece @c delante y @c atras a NULL. Debe ser la primera llamada
 * antes de operar sobre la cola. No reserva memoria dinámica.
 *
 * @param[out] cola Puntero a la ColaPrioridad que se va a inicializar.
 *                  Si es NULL la función no hace nada.
 *
 * @post La cola queda vacía y lista para usarse.
 */
void cp_inicializar(ColaPrioridad *cola) {
    audit_emit("cp_inicializar","entry",88,-1);
    if (audit_guard("cp_inicializar","guard",89,(audit_operand("cola == NULL",(cola == NULL))))) {
    audit_return("cp_inicializar",90,0,0);
        return;
    }
    cola->delante = NULL;
    audit_mask|=1;audit_emit("cp_inicializar","store-delante",92,-1);
    cola->atras = NULL;
    audit_mask|=2;audit_emit("cp_inicializar","store-atras",93,-1);
    cola->cantidad = 0;
    audit_mask|=4;audit_emit("cp_inicializar","store-cantidad",94,-1);
    audit_active=0;audit_count=NULL;audit_used=NULL;audit_emit("cp_inicializar","end",95,-1);
}

/*
 * @brief Encola un elemento con su valor y prioridad asociada.
 *
 * @details
 * Reserva dinámicamente un nuevo @c CPNodo, almacena @p valor y
 * @p prioridad en él y lo enlaza al extremo @c atras de la cola.
 * Si la cola estaba vacía, tanto @c delante como @c atras apuntarán
 * al nuevo nodo. El orden de extracción depende de la prioridad,
 * no del orden de inserción.
 *
 * @param cola      Puntero a la ColaPrioridad destino.
 * @param valor     Dato entero a almacenar.
 * @param prioridad Número de prioridad (menor valor = mayor prioridad).
 *
 * @return @c true  si el nodo fue creado e insertado correctamente.
 * @return @c false si @p cola es NULL o @c malloc() falla.
 *
 * @pre  La cola debe haber sido inicializada con cp_inicializar().
 * @post El tamaño de la cola aumenta en 1.
 * @note Complejidad temporal: O(1).
 */
/**
 * @brief Encola un elemento con su valor y prioridad asociada.
 *
 * @details
 * Reserva dinámicamente un nuevo @c CPNodo, almacena @p valor y
 * @p prioridad en él y lo enlaza al extremo @c atras de la cola.
 * Si la cola estaba vacía, tanto @c delante como @c atras apuntarán
 * al nuevo nodo. El orden de extracción depende de la prioridad,
 * no del orden de inserción.
 *
 * @param[in,out] cola      Puntero a la ColaPrioridad destino.
 * @param[in]     valor     Dato entero a almacenar.
 * @param[in]     prioridad Número de prioridad (menor valor = mayor prioridad).
 *
 * @return @c true  si el nodo fue creado e insertado correctamente.
 * @return @c false si @p cola es NULL o @c malloc() falla.
 *
 * @pre  La cola debe haber sido inicializada con cp_inicializar().
 * @post Si retorna true, el tamaño aumenta en 1; si retorna false, la cola no cambia.
 * @note Complejidad temporal: O(1).
 */
bool cp_encolar(ColaPrioridad *cola, int valor, int prioridad) {
    CPNodo *nuevo;
    if (cola == NULL) {
        return false;
    }

    nuevo = cp_crear_nodo(valor, prioridad);
    if (nuevo == NULL) {
        return false;
    }

    if (cola->delante == NULL) {
        cola->delante = nuevo;
    } else {
        cola->atras->sgte = nuevo;
    }
    cola->atras = nuevo;
    cola->cantidad++;
    return true;
}

/*
 * @brief Desencola el elemento de mayor prioridad efectiva.
 *
 * @details
 * Recorre toda la cola buscando el nodo con el valor de prioridad más
 * bajo (número más pequeño). En caso de empate extrae el que fue
 * insertado primero (el que aparece antes en la lista).
 * Una vez encontrado, lo desenlaza actualizando @c delante o
 * @c atras según corresponda, escribe sus datos en los punteros
 * @p valor y @p prioridad y libera su memoria.
 *
 * @param cola      Puntero a la ColaPrioridad de origen.
 * @param valor     Puntero donde se escribe el valor del nodo extraído.
 * @param prioridad Puntero donde se escribe la prioridad extraída.
 *
 * @return @c true  si se extrajo un elemento correctamente.
 * @return @c false si @p cola, @p valor o @p prioridad son NULL,
 *                  o la cola está vacía.
 *
 * @pre  La cola debe contener al menos un elemento.
 * @post El tamaño de la cola disminuye en 1.
 * @note Complejidad temporal: O(n), donde n es el número de elementos.
 */
/**
 * @brief Desencola el elemento de mayor prioridad efectiva.
 *
 * @details
 * Recorre toda la cola buscando el nodo con el valor de prioridad más
 * bajo (número más pequeño). En caso de empate extrae el que fue
 * insertado primero (el que aparece antes en la lista).
 * Una vez encontrado, lo desenlaza actualizando @c delante o
 * @c atras según corresponda, escribe sus datos en los punteros
 * @p valor y @p prioridad y libera su memoria.
 *
 * @param[in,out] cola      Puntero a la ColaPrioridad de origen.
 * @param[out]    valor     Puntero donde se escribe el valor del nodo extraído.
 * @param[out]    prioridad Puntero donde se escribe la prioridad extraída.
 *
 * @return @c true  si se extrajo un elemento correctamente.
 * @return @c false si @p cola, @p valor o @p prioridad son NULL,
 *                  o la cola está vacía.
 *
 * @pre  La cola debe estar inicializada; una cola vacía se admite y retorna false.
 * @post Si retorna true, el tamaño disminuye en 1; ante cola vacía o parámetros NULL no hay extracción.
 * @note Complejidad temporal: O(n), donde n es el número de elementos.
 */
bool cp_desencolar(ColaPrioridad *cola, int *valor, int *prioridad) {
    CPNodo *actual;
    CPNodo *prev;
    CPNodo *objetivo;
    CPNodo *objetivoPrev;

    if (cola == NULL || cola->delante == NULL || valor == NULL || prioridad == NULL) {
        return false;
    }

    actual = cola->delante;
    prev = NULL;
    objetivo = actual;
    objetivoPrev = NULL;

    while (actual != NULL) {
        if (actual->prioridad < objetivo->prioridad) {
            objetivo = actual;
            objetivoPrev = prev;
        }
        prev = actual;
        actual = actual->sgte;
    }

    if (objetivo == cola->delante) {
        cola->delante = objetivo->sgte;
        if (cola->delante == NULL) {
            cola->atras = NULL;
        }
    } else {
        objetivoPrev->sgte = objetivo->sgte;
        if (cola->atras == objetivo) {
            cola->atras = objetivoPrev;
        }
    }

    *valor = objetivo->valor;
    *prioridad = objetivo->prioridad;
    free(objetivo);
    if (cola->cantidad > 0) {
        cola->cantidad--;
    }
    return true;
}

/*
 * @brief Consulta el elemento que sería atendido sin modificar la cola.
 * @details Selecciona la menor prioridad; los empates conservan el orden de llegada.
 * @param cola Cola que se consulta.
 * @param valor Valor del candidato seleccionado.
 * @param prioridad Prioridad del candidato seleccionado.
 * @return true si hay candidato y los parámetros de salida son válidos.
 */
/**
 * @brief Consulta el elemento que sería atendido sin modificar la cola.
 * @details Selecciona la menor prioridad; los empates conservan el orden de llegada.
 * @param[in] cola Cola que se consulta.
 * @param[out] valor Valor del candidato seleccionado.
 * @param[out] prioridad Prioridad del candidato seleccionado.
 * @return true si hay candidato y los parámetros de salida son válidos.
 * @return false si la cola está vacía o cola, valor o prioridad son NULL.
 */
bool cp_frente(const ColaPrioridad *cola, int *valor, int *prioridad) {
    const CPNodo *actual;
    const CPNodo *objetivo;

    if (cola == NULL || cola->delante == NULL || valor == NULL || prioridad == NULL) {
        return false;
    }
    objetivo = cola->delante;
    actual = cola->delante->sgte;
    while (actual != NULL) {
        if (actual->prioridad < objetivo->prioridad) {
            objetivo = actual;
        }
        actual = actual->sgte;
    }
    *valor = objetivo->valor;
    *prioridad = objetivo->prioridad;
    return true;
}

/*
 * @brief Indica si la cola de prioridad no contiene ningún elemento.
 *
 * @param cola Puntero constante a la ColaPrioridad a consultar.
 *
 * @return @c true  si @p cola es NULL o @c delante es NULL.
 * @return @c false si la cola tiene al menos un elemento.
 *
 * @note Complejidad temporal: O(1).
 */
/**
 * @brief Indica si la cola de prioridad no contiene ningún elemento.
 *
 * @param[in] cola Puntero constante a la ColaPrioridad a consultar.
 *
 * @return @c true si @p cola es NULL, @c delante es NULL o @c cantidad es cero.
 * @return @c false si la cola tiene al menos un elemento.
 *
 * @note Complejidad temporal: O(1).
 */
bool cp_vacia(const ColaPrioridad *cola) {
    audit_emit("cp_vacia","entry",308,-1);
    int audit_value=audit_guard("cp_vacia","return-condition",309,(audit_operand("cola == NULL",cola == NULL) || audit_operand("cola->delante == NULL",cola->delante == NULL) || audit_operand("cola->cantidad == 0",cola->cantidad == 0))); audit_return("cp_vacia",309,1,audit_value); return audit_value;
}

/*
 * @brief Cuenta el número de elementos presentes en la cola.
 *
 * @param cola Puntero constante a la ColaPrioridad.
 *
 * @return Número de nodos (>= 0). Retorna 0 si @p cola es NULL.
 *
 * @note Complejidad temporal: O(1).
 */
/**
 * @brief Cuenta el número de elementos presentes en la cola.
 *
 * @param[in] cola Puntero constante a la ColaPrioridad.
 *
 * @return Número de nodos (>= 0). Retorna 0 si @p cola es NULL.
 *
 * @note Complejidad temporal: O(1).
 */
int cp_contar(const ColaPrioridad *cola) {
    audit_emit("cp_contar","entry",330,-1);
    if (audit_guard("cp_contar","guard",331,(audit_operand("cola == NULL",(cola == NULL))))) {
    int audit_value = 0; audit_return("cp_contar",332,1,audit_value); return audit_value;
    }
    int audit_value = cola->cantidad; audit_return("cp_contar",334,1,audit_value); return audit_value;
}

/*
 * @brief Copia el valor y prioridad de cada elemento en arreglos externos.
 *
 * @details
 * Recorre la cola de frente a fondo. Por cada nodo, copia su @c valor
 * en @p valores[@c i] y su @c prioridad en @p prioridades[@c i].
 * Se copian como máximo @p capacidad elementos. La cola no se modifica.
 *
 * @param cola        Puntero constante a la ColaPrioridad de origen.
 * @param valores     Arreglo donde se almacenarán los valores copiados.
 * @param prioridades Arreglo donde se almacenarán las prioridades.
 * @param capacidad   Número máximo de elementos a copiar.
 *
 * @return Número de elementos efectivamente copiados.
 *         Retorna 0 si algún parámetro es inválido.
 *
 * @pre  @p valores y @p prioridades deben apuntar a bloques con espacio
 *       para al menos @p capacidad enteros cada uno.
 * @note Complejidad temporal: O(min(n, capacidad)).
 */
/**
 * @brief Copia el valor y prioridad de cada elemento en arreglos externos.
 *
 * @details
 * Recorre la cola de frente a fondo. Por cada nodo, copia su @c valor
 * en @p valores[@c i] y su @c prioridad en @p prioridades[@c i].
 * Se copian como máximo @p capacidad elementos. La cola no se modifica.
 *
 * @param[in]  cola        Puntero constante a la ColaPrioridad de origen.
 * @param[out] valores     Arreglo donde se almacenarán los valores copiados.
 * @param[out] prioridades Arreglo donde se almacenarán las prioridades.
 * @param[in]  capacidad   Número máximo de elementos a copiar.
 *
 * @return Número de elementos efectivamente copiados.
 *         Retorna 0 si algún parámetro es inválido.
 *
 * @pre  @p valores y @p prioridades deben apuntar a bloques con espacio
 *       para al menos @p capacidad enteros cada uno.
 * @note Complejidad temporal: O(min(n, capacidad)).
 */
int cp_copiar_items(const ColaPrioridad *cola, int *valores, int *prioridades, int capacidad) {
    audit_emit("cp_copiar_items","entry",377,-1);
    int usados = 0;
    audit_count=&usados;audit_count_init=1;audit_emit("cp_copiar_items","declare-usados",378,-1);
    CPNodo *aux;
    audit_emit("cp_copiar_items","declare-aux",379,-1);

    if (audit_guard("cp_copiar_items","guard",381,(audit_operand("cola == NULL",(cola == NULL)) || audit_operand("valores == NULL",(valores == NULL)) || audit_operand("prioridades == NULL",(prioridades == NULL)) || audit_operand("capacidad <= 0",(capacidad <= 0))))) {
    int audit_value = 0; audit_return("cp_copiar_items",382,1,audit_value); return audit_value;
    }

    aux = cola->delante;
    audit_aux=aux;audit_aux_init=1;audit_emit("cp_copiar_items","assign-aux",385,-1);
    while (audit_guard("cp_copiar_items","loop",386,(audit_operand("aux != NULL",(aux != NULL)) && audit_operand("usados < capacidad",(usados < capacidad))))) {
        valores[usados] = aux->valor;
    audit_value_marks[usados]=1;audit_emit("cp_copiar_items","store-value",387,-1);
        prioridades[usados] = aux->prioridad;
    audit_priority_marks[usados]=1;audit_emit("cp_copiar_items","store-priority",388,-1);
        usados++;
    audit_emit("cp_copiar_items","increment",389,-1);
        aux = aux->sgte;
    audit_aux=aux;audit_emit("cp_copiar_items","advance",390,-1);
    }
    int audit_value = usados; audit_return("cp_copiar_items",392,1,audit_value); return audit_value;
}

/*
 * @brief Genera una representación textual de la cola de prioridad.
 *
 * @details
 * Escribe en @p destino una cadena con el formato:
 * @code
 * frente -> v1(p=p1) | v2(p=p2) | ... | vN(p=pN)
 * @endcode
 * donde @c vK es el valor y @c pK la prioridad del k-ésimo elemento
 * en orden de inserción. Si la cola está vacía escribe
 * @c "Cola de prioridad vacia".
 * La cadena siempre queda terminada en @c '\0' si @p capacidad >= 1.
 *
 * @param cola      Puntero constante a la ColaPrioridad.
 * @param destino   Buffer donde se escribirá la cadena resultante.
 * @param capacidad Tamaño en bytes del buffer @p destino.
 *
 * @pre  @p destino debe apuntar a un buffer de al menos @p capacidad bytes.
 * @post @p destino contiene una cadena terminada en @c '\0'.
 * @note Si el contenido supera @p capacidad se trunca de forma segura.
 * @note Si @p destino es NULL o @p capacidad es 0, no hace nada.
 * @note Complejidad temporal: O(n).
 */
/**
 * @brief Genera una representación textual de la cola de prioridad.
 *
 * @details
 * Escribe en @p destino una cadena con el formato:
 * @code
 * frente -> v1(p=p1) | v2(p=p2) | ... | vN(p=pN)
 * @endcode
 * donde @c vK es el valor y @c pK la prioridad del k-ésimo elemento
 * en orden de inserción. Si la cola está vacía escribe
 * @c "Cola de prioridad vacia".
 * La cadena siempre queda terminada en @c '\0' si @p capacidad >= 1.
 *
 * @param[in]  cola      Puntero constante a la ColaPrioridad.
 * @param[out] destino   Buffer donde se escribirá la cadena resultante.
 * @param[in]  capacidad Tamaño en bytes del buffer @p destino.
 *
 * @pre  @p destino debe apuntar a un buffer de al menos @p capacidad bytes.
 * @post @p destino contiene una cadena terminada en @c '\0'.
 * @note Si el contenido supera @p capacidad se trunca de forma segura.
 * @note Si @p destino es NULL o @p capacidad es 0, no hace nada.
 * @note Complejidad temporal: O(n).
 */
void cp_formatear(const ColaPrioridad *cola, char *destino, size_t capacidad) {
    audit_emit("cp_formatear","entry",441,-1);
    CPNodo *aux;
    audit_emit("cp_formatear","declare-aux",442,-1);
    size_t usado = 0;
    audit_used=&usado;audit_used_init=1;audit_emit("cp_formatear","declare-usado",443,-1);

    if (audit_guard("cp_formatear","guard",445,(audit_operand("destino == NULL",(destino == NULL)) || audit_operand("capacidad == 0",(capacidad == 0))))) {
    audit_return("cp_formatear",446,0,0);
        return;
    }

    destino[0] = '\0';
    audit_byte_marks[0]=1;audit_emit("cp_formatear","buffer-init",449,-1);

    if (audit_guard("cp_formatear","empty",451,(audit_operand("cola == NULL",(cola == NULL)) || audit_operand("cola->delante == NULL",(cola->delante == NULL))))) {
        snprintf(destino, capacidad, "Cola de prioridad vacia");
    audit_format_marks(destino,capacidad);audit_emit("cp_formatear","format-empty",452,-1);
    audit_return("cp_formatear",453,0,0);
        return;
    }

    audit_emit("cp_formatear","call",456,-1);
    cp_append_text(destino, capacidad, &usado, "frente -> ");
    audit_emit("cp_formatear","resume",456,-1);

    aux = cola->delante;
    audit_aux=aux;audit_aux_init=1;audit_emit("cp_formatear","assign-aux",458,-1);
    while (audit_guard("cp_formatear","loop",459,(audit_operand("aux != NULL",(aux != NULL)) && audit_operand("usado < capacidad",(usado < capacidad))))) {
    audit_emit("cp_formatear","call",460,-1);
        cp_append_text(destino, capacidad, &usado, "%d(p=%d)", aux->valor, aux->prioridad);
    audit_emit("cp_formatear","resume",460,-1);
        aux = aux->sgte;
    audit_aux=aux;audit_emit("cp_formatear","advance",461,-1);
        if (audit_guard("cp_formatear","separator",462,(audit_operand("aux != NULL",(aux != NULL)) && audit_operand("usado < capacidad",(usado < capacidad))))) {
    audit_emit("cp_formatear","call",463,-1);
            cp_append_text(destino, capacidad, &usado, " | ");
    audit_emit("cp_formatear","resume",463,-1);
        }
    }
    audit_active=0;audit_count=NULL;audit_used=NULL;audit_emit("cp_formatear","end",466,-1);
}

/*
 * @brief Elimina todos los elementos de la cola y libera su memoria.
 *
 * @details
 * Recorre la cola desde @c delante hasta el final usando un puntero
 * @c next para guardar el enlace antes de liberar cada @c CPNodo.
 * Al finalizar, @c delante y @c atras quedan en NULL.
 *
 * @param cola Puntero a la ColaPrioridad a vaciar.
 *                     Si es NULL la función no hace nada.
 *
 * @post La cola queda en el mismo estado que tras cp_inicializar().
 * @note Complejidad temporal: O(n).
 */
/**
 * @brief Elimina todos los elementos de la cola y libera su memoria.
 *
 * @details
 * Recorre la cola desde @c delante hasta el final usando un puntero
 * @c next para guardar el enlace antes de liberar cada @c CPNodo.
 * Al finalizar, @c delante y @c atras quedan en NULL.
 *
 * @param[in,out] cola Puntero a la ColaPrioridad a vaciar.
 *                     Si es NULL la función no hace nada.
 *
 * @post La cola queda en el mismo estado que tras cp_inicializar().
 * @note Complejidad temporal: O(n).
 */
void cp_vaciar(ColaPrioridad *cola) {
    CPNodo *aux;
    CPNodo *next;

    if (cola == NULL) {
        return;
    }

    aux = cola->delante;
    while (aux != NULL) {
        next = aux->sgte;
        cola->delante = next;
        if (cola->atras == aux) {
            cola->atras = NULL;
        }
        free(aux);
        if (cola->cantidad > 0) {
            cola->cantidad--;
        }
        aux = next;
    }

    cola->delante = NULL;
    cola->atras = NULL;
    cola->cantidad = 0;
}
