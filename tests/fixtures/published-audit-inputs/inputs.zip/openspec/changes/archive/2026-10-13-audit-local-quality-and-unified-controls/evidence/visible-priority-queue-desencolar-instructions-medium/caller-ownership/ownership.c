#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static void*objects[64];static int alive[64],used,allocs,frees,attempts,fault;
static void report(void){int live=0;for(int i=0;i<used;i++)live+=alive[i];fprintf(stderr,"OWNERSHIP %d %d %d\n",allocs,frees,live);assert(live==0&&allocs==frees);}
void*audit_malloc(size_t n){if(attempts==0){const char*value=getenv("QA_NULL_POINT");fault=value?atoi(value):0;atexit(report);}attempts++;if(attempts==fault)return NULL;void*p=malloc(n);assert(p&&used<64);objects[used]=p;alive[used++]=1;allocs++;return p;}
void audit_free(void*p){if(!p)return;int found=-1;for(int i=0;i<used;i++)if(alive[i]&&objects[i]==p){found=i;break;}assert(found>=0);alive[found]=0;objects[found]=NULL;frees++;free(p);}
