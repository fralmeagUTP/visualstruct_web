# QA y revisión de recarga

Primerrecorrido160/144 comprobóJSONexacto, peroinspección source revelóque clave restaurada debeusar buildSelectionKey(...)+::execution: y valorinput para botónreal. Corregido sóloapilar; preservadoreportantesclave. La siguientecomprobación usóSiguiente conmodo rápidopor defecto trasreload(botónocultoporc ontratoactual):harness debeactivarPasoapasocomounusuario antesSiguiente;no cambia mododefault ni ramasclosed. Logs originales conservados.
