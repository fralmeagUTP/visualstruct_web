/**
 * @file tad_cola_prioridad.c
 * @brief Implementación del TAD Cola de prioridad en orden de llegada.
 */

#include "tad_cola_prioridad.h"

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

/**
 * @brief Nodo interno de cola de prioridad, enlazado en orden de llegada.
 */
struct cp_nodo {
    int valor; /**< Dato almacenado. */
    int prioridad; /**< Prioridad del elemento. */
    struct cp_nodo *sgte; /**< Enlace al siguiente nodo. */
};

/**
 * @brief Agrega texto formateado en un buffer de tamaño acotado.
 * @param destino Buffer de salida.
 * @param capacidad Capacidad total en bytes, incluido el terminador.
 * @param usado Contador actualizado de bytes; se satura a capacidad si hay truncamiento.
 * @param fmt Formato de vsnprintf para los argumentos variables.
 */
static void cp_append_text(char *destino, size_t capacidad, size_t *usado, const char *fmt, ...) {
    va_list args;
    int escritos;

    if (destino == NULL || usado == NULL || *usado >= capacidad) {
        return;
    }

    va_start(args, fmt);
    escritos = vsnprintf(destino + *usado, capacidad - *usado, fmt, args);
    va_end(args);
    if (escritos < 0) {
        return;
    }
    if ((size_t)escritos >= capacidad - *usado) {
        *usado = capacidad;
    } else {
        *usado += (size_t)escritos;
    }
}

/**
 * @brief Reserva e inicializa un nodo con enlace siguiente NULL.
 * @param valor Dato a almacenar.
 * @param prioridad Prioridad que se consulta al seleccionar la extracción.
 * @return Nodo reservado o NULL si falla malloc; el llamador adquiere su propiedad.
 */
static CPNodo *cp_crear_nodo(int valor, int prioridad) {
    CPNodo *nuevo = (CPNodo *)malloc(sizeof(CPNodo));
    if (nuevo == NULL) {
        return NULL;
    }
    nuevo->valor = valor;
    nuevo->prioridad = prioridad;
    nuevo->sgte = NULL;
    return nuevo;
}

/*
 * @brief Inicializa una ColaPrioridad poniéndola en estado vacío.
 *
 * Establece @c delante y @c atras a NULL. Debe ser la primera llamada
 * antes de operar sobre la cola. No reserva memoria dinámica.
 *
 * @param cola Puntero a la ColaPrioridad que se va a inicializar.
 *                  Si es NULL la función no hace nada.
 *
 * @post La cola queda vacía y lista para usarse.
 */
/**
 * @brief Inicializa una ColaPrioridad poniéndola en estado vacío.
 *
 * Establece @c delante y @c atras a NULL. Debe ser la primera llamada
 * antes de operar sobre la cola. No reserva memoria dinámica.
 *
 * @param[out] cola Puntero a la ColaPrioridad que se va a inicializar.
 *                  Si es NULL la función no hace nada.
 *
 * @post La cola queda vacía y lista para usarse.
 */
void cp_inicializar(ColaPrioridad *cola) {
    if (cola == NULL) {
        return;
    }
    cola->delante = NULL;
    cola->atras = NULL;
    cola->cantidad = 0;
}

/*
 * @brief Encola un elemento con su valor y prioridad asociada.
 *
 * @details
 * Reserva dinámicamente un nuevo @c CPNodo, almacena @p valor y
 * @p prioridad en él y lo enlaza al extremo @c atras de la cola.
 * Si la cola estaba vacía, tanto @c delante como @c atras apuntarán
 * al nuevo nodo. El orden de extracción depende de la prioridad,
 * no del orden de inserción.
 *
 * @param cola      Puntero a la ColaPrioridad destino.
 * @param valor     Dato entero a almacenar.
 * @param prioridad Número de prioridad (menor valor = mayor prioridad).
 *
 * @return @c true  si el nodo fue creado e insertado correctamente.
 * @return @c false si @p cola es NULL o @c malloc() falla.
 *
 * @pre  La cola debe haber sido inicializada con cp_inicializar().
 * @post El tamaño de la cola aumenta en 1.
 * @note Complejidad temporal: O(1).
 */
/**
 * @brief Encola un elemento con su valor y prioridad asociada.
 *
 * @details
 * Reserva dinámicamente un nuevo @c CPNodo, almacena @p valor y
 * @p prioridad en él y lo enlaza al extremo @c atras de la cola.
 * Si la cola estaba vacía, tanto @c delante como @c atras apuntarán
 * al nuevo nodo. El orden de extracción depende de la prioridad,
 * no del orden de inserción.
 *
 * @param[in,out] cola      Puntero a la ColaPrioridad destino.
 * @param[in]     valor     Dato entero a almacenar.
 * @param[in]     prioridad Número de prioridad (menor valor = mayor prioridad).
 *
 * @return @c true  si el nodo fue creado e insertado correctamente.
 * @return @c false si @p cola es NULL o @c malloc() falla.
 *
 * @pre  La cola debe haber sido inicializada con cp_inicializar().
 * @post Si retorna true, el tamaño aumenta en 1; si retorna false, la cola no cambia.
 * @note Complejidad temporal: O(1).
 */
bool cp_encolar(ColaPrioridad *cola, int valor, int prioridad) {
    CPNodo *nuevo;
    if (cola == NULL) {
        return false;
    }

    nuevo = cp_crear_nodo(valor, prioridad);
    if (nuevo == NULL) {
        return false;
    }

    if (cola->delante == NULL) {
        cola->delante = nuevo;
    } else {
        cola->atras->sgte = nuevo;
    }
    cola->atras = nuevo;
    cola->cantidad++;
    return true;
}

/*
 * @brief Desencola el elemento de mayor prioridad efectiva.
 *
 * @details
 * Recorre toda la cola buscando el nodo con el valor de prioridad más
 * bajo (número más pequeño). En caso de empate extrae el que fue
 * insertado primero (el que aparece antes en la lista).
 * Una vez encontrado, lo desenlaza actualizando @c delante o
 * @c atras según corresponda, escribe sus datos en los punteros
 * @p valor y @p prioridad y libera su memoria.
 *
 * @param cola      Puntero a la ColaPrioridad de origen.
 * @param valor     Puntero donde se escribe el valor del nodo extraído.
 * @param prioridad Puntero donde se escribe la prioridad extraída.
 *
 * @return @c true  si se extrajo un elemento correctamente.
 * @return @c false si @p cola, @p valor o @p prioridad son NULL,
 *                  o la cola está vacía.
 *
 * @pre  La cola debe contener al menos un elemento.
 * @post El tamaño de la cola disminuye en 1.
 * @note Complejidad temporal: O(n), donde n es el número de elementos.
 */
/**
 * @brief Desencola el elemento de mayor prioridad efectiva.
 *
 * @details
 * Recorre toda la cola buscando el nodo con el valor de prioridad más
 * bajo (número más pequeño). En caso de empate extrae el que fue
 * insertado primero (el que aparece antes en la lista).
 * Una vez encontrado, lo desenlaza actualizando @c delante o
 * @c atras según corresponda, escribe sus datos en los punteros
 * @p valor y @p prioridad y libera su memoria.
 *
 * @param[in,out] cola      Puntero a la ColaPrioridad de origen.
 * @param[out]    valor     Puntero donde se escribe el valor del nodo extraído.
 * @param[out]    prioridad Puntero donde se escribe la prioridad extraída.
 *
 * @return @c true  si se extrajo un elemento correctamente.
 * @return @c false si @p cola, @p valor o @p prioridad son NULL,
 *                  o la cola está vacía.
 *
 * @pre  La cola debe estar inicializada; una cola vacía se admite y retorna false.
 * @post Si retorna true, el tamaño disminuye en 1; ante cola vacía o parámetros NULL no hay extracción.
 * @note Complejidad temporal: O(n), donde n es el número de elementos.
 */
bool cp_desencolar(ColaPrioridad *cola, int *valor, int *prioridad) {
qa_event("entry",cola,-1);

    CPNodo *actual;
    _Static_assert(_Generic(actual,CPNodo*:1,default:0),"CPNodo pointer type");
    qa_event("CPNodo *actual;",cola,-1);
    CPNodo *prev;
    _Static_assert(_Generic(prev,CPNodo*:1,default:0),"CPNodo pointer type");
    qa_event("CPNodo *prev;",cola,-1);
    CPNodo *objetivo;
    _Static_assert(_Generic(objetivo,CPNodo*:1,default:0),"CPNodo pointer type");
    qa_event("CPNodo *objetivo;",cola,-1);
    CPNodo *objetivoPrev;
    _Static_assert(_Generic(objetivoPrev,CPNodo*:1,default:0),"CPNodo pointer type");
    qa_event("CPNodo *objetivoPrev;",cola,-1);

    if (qa_test("if (cola == NULL || cola->delante == NULL || valor == NULL || prioridad == NULL) {",(cola == NULL || cola->delante == NULL || valor == NULL || prioridad == NULL),cola)) {
        qa_result(0);qa_event("return false;",cola,-1);
        return false;
    }

    actual = cola->delante;
    qa_alias(0,actual);
    qa_event("actual = cola->delante;",cola,-1);
    prev = NULL;
    qa_alias(1,prev);
    qa_event("prev = NULL;",cola,-1);
    objetivo = actual;
    qa_alias(2,objetivo);
    qa_event("objetivo = actual;",cola,-1);
    objetivoPrev = NULL;
    qa_alias(3,objetivoPrev);
    qa_event("objetivoPrev = NULL;",cola,-1);

    while (qa_test("while (actual != NULL) {",(actual != NULL),cola)) {
        if (qa_test("if (actual->prioridad < objetivo->prioridad) {",(actual->prioridad < objetivo->prioridad),cola)) {
            objetivo = actual;
            qa_alias(2,objetivo);
            qa_event("objetivo = actual;",cola,-1);
            objetivoPrev = prev;
            qa_alias(3,objetivoPrev);
            qa_event("objetivoPrev = prev;",cola,-1);
        }
        prev = actual;
        qa_alias(1,prev);
        qa_event("prev = actual;",cola,-1);
        actual = actual->sgte;
        qa_alias(0,actual);
        qa_event("actual = actual->sgte;",cola,-1);
    }

    if (qa_test("if (objetivo == cola->delante) {",(objetivo == cola->delante),cola)) {
        cola->delante = objetivo->sgte;
        qa_event("cola->delante = objetivo->sgte;",cola,-1);
        if (qa_test("if (cola->delante == NULL) {",(cola->delante == NULL),cola)) {
            cola->atras = NULL;
            qa_event("cola->atras = NULL;",cola,-1);
        }
    } else {
        objetivoPrev->sgte = objetivo->sgte;
        qa_event("objetivoPrev->sgte = objetivo->sgte;",cola,-1);
        if (qa_test("if (cola->atras == objetivo) {",(cola->atras == objetivo),cola)) {
            cola->atras = objetivoPrev;
            qa_event("cola->atras = objetivoPrev;",cola,-1);
        }
    }

    *valor = objetivo->valor;
    qa_value_written();
    qa_event("*valor = objetivo->valor;",cola,-1);
    *prioridad = objetivo->prioridad;
    qa_priority_written();
    qa_event("*prioridad = objetivo->prioridad;",cola,-1);
    free(objetivo);
    qa_event("free(objetivo);",cola,-1);
    if (qa_test("if (cola->cantidad > 0) {",(cola->cantidad > 0),cola)) {
        cola->cantidad--;
        qa_event("cola->cantidad--;",cola,-1);
    }
    qa_result(1);qa_event("return true;",cola,-1);
    return true;
}

/*
 * @brief Consulta el elemento que sería atendido sin modificar la cola.
 * @details Selecciona la menor prioridad; los empates conservan el orden de llegada.
 * @param cola Cola que se consulta.
 * @param valor Valor del candidato seleccionado.
 * @param prioridad Prioridad del candidato seleccionado.
 * @return true si hay candidato y los parámetros de salida son válidos.
 */
/**
 * @brief Consulta el elemento que sería atendido sin modificar la cola.
 * @details Selecciona la menor prioridad; los empates conservan el orden de llegada.
 * @param[in] cola Cola que se consulta.
 * @param[out] valor Valor del candidato seleccionado.
 * @param[out] prioridad Prioridad del candidato seleccionado.
 * @return true si hay candidato y los parámetros de salida son válidos.
 * @return false si la cola está vacía o cola, valor o prioridad son NULL.
 */
bool cp_frente(const ColaPrioridad *cola, int *valor, int *prioridad) {
    const CPNodo *actual;
    const CPNodo *objetivo;

    if (cola == NULL || cola->delante == NULL || valor == NULL || prioridad == NULL) {
        return false;
    }
    objetivo = cola->delante;
    actual = cola->delante->sgte;
    while (actual != NULL) {
        if (actual->prioridad < objetivo->prioridad) {
            objetivo = actual;
        }
        actual = actual->sgte;
    }
    *valor = objetivo->valor;
    *prioridad = objetivo->prioridad;
    return true;
}

/*
 * @brief Indica si la cola de prioridad no contiene ningún elemento.
 *
 * @param cola Puntero constante a la ColaPrioridad a consultar.
 *
 * @return @c true  si @p cola es NULL o @c delante es NULL.
 * @return @c false si la cola tiene al menos un elemento.
 *
 * @note Complejidad temporal: O(1).
 */
/**
 * @brief Indica si la cola de prioridad no contiene ningún elemento.
 *
 * @param[in] cola Puntero constante a la ColaPrioridad a consultar.
 *
 * @return @c true si @p cola es NULL, @c delante es NULL o @c cantidad es cero.
 * @return @c false si la cola tiene al menos un elemento.
 *
 * @note Complejidad temporal: O(1).
 */
bool cp_vacia(const ColaPrioridad *cola) {
    return cola == NULL || cola->delante == NULL || cola->cantidad == 0;
}

/*
 * @brief Cuenta el número de elementos presentes en la cola.
 *
 * @param cola Puntero constante a la ColaPrioridad.
 *
 * @return Número de nodos (>= 0). Retorna 0 si @p cola es NULL.
 *
 * @note Complejidad temporal: O(1).
 */
/**
 * @brief Cuenta el número de elementos presentes en la cola.
 *
 * @param[in] cola Puntero constante a la ColaPrioridad.
 *
 * @return Número de nodos (>= 0). Retorna 0 si @p cola es NULL.
 *
 * @note Complejidad temporal: O(1).
 */
int cp_contar(const ColaPrioridad *cola) {
    if (cola == NULL) {
        return 0;
    }
    return cola->cantidad;
}

/*
 * @brief Copia el valor y prioridad de cada elemento en arreglos externos.
 *
 * @details
 * Recorre la cola de frente a fondo. Por cada nodo, copia su @c valor
 * en @p valores[@c i] y su @c prioridad en @p prioridades[@c i].
 * Se copian como máximo @p capacidad elementos. La cola no se modifica.
 *
 * @param cola        Puntero constante a la ColaPrioridad de origen.
 * @param valores     Arreglo donde se almacenarán los valores copiados.
 * @param prioridades Arreglo donde se almacenarán las prioridades.
 * @param capacidad   Número máximo de elementos a copiar.
 *
 * @return Número de elementos efectivamente copiados.
 *         Retorna 0 si algún parámetro es inválido.
 *
 * @pre  @p valores y @p prioridades deben apuntar a bloques con espacio
 *       para al menos @p capacidad enteros cada uno.
 * @note Complejidad temporal: O(min(n, capacidad)).
 */
/**
 * @brief Copia el valor y prioridad de cada elemento en arreglos externos.
 *
 * @details
 * Recorre la cola de frente a fondo. Por cada nodo, copia su @c valor
 * en @p valores[@c i] y su @c prioridad en @p prioridades[@c i].
 * Se copian como máximo @p capacidad elementos. La cola no se modifica.
 *
 * @param[in]  cola        Puntero constante a la ColaPrioridad de origen.
 * @param[out] valores     Arreglo donde se almacenarán los valores copiados.
 * @param[out] prioridades Arreglo donde se almacenarán las prioridades.
 * @param[in]  capacidad   Número máximo de elementos a copiar.
 *
 * @return Número de elementos efectivamente copiados.
 *         Retorna 0 si algún parámetro es inválido.
 *
 * @pre  @p valores y @p prioridades deben apuntar a bloques con espacio
 *       para al menos @p capacidad enteros cada uno.
 * @note Complejidad temporal: O(min(n, capacidad)).
 */
int cp_copiar_items(const ColaPrioridad *cola, int *valores, int *prioridades, int capacidad) {
    int usados = 0;
    CPNodo *aux;

    if (cola == NULL || valores == NULL || prioridades == NULL || capacidad <= 0) {
        return 0;
    }

    aux = cola->delante;
    while (aux != NULL && usados < capacidad) {
        valores[usados] = aux->valor;
        prioridades[usados] = aux->prioridad;
        usados++;
        aux = aux->sgte;
    }
    return usados;
}

/*
 * @brief Genera una representación textual de la cola de prioridad.
 *
 * @details
 * Escribe en @p destino una cadena con el formato:
 * @code
 * frente -> v1(p=p1) | v2(p=p2) | ... | vN(p=pN)
 * @endcode
 * donde @c vK es el valor y @c pK la prioridad del k-ésimo elemento
 * en orden de inserción. Si la cola está vacía escribe
 * @c "Cola de prioridad vacia".
 * La cadena siempre queda terminada en @c '\0' si @p capacidad >= 1.
 *
 * @param cola      Puntero constante a la ColaPrioridad.
 * @param destino   Buffer donde se escribirá la cadena resultante.
 * @param capacidad Tamaño en bytes del buffer @p destino.
 *
 * @pre  @p destino debe apuntar a un buffer de al menos @p capacidad bytes.
 * @post @p destino contiene una cadena terminada en @c '\0'.
 * @note Si el contenido supera @p capacidad se trunca de forma segura.
 * @note Si @p destino es NULL o @p capacidad es 0, no hace nada.
 * @note Complejidad temporal: O(n).
 */
/**
 * @brief Genera una representación textual de la cola de prioridad.
 *
 * @details
 * Escribe en @p destino una cadena con el formato:
 * @code
 * frente -> v1(p=p1) | v2(p=p2) | ... | vN(p=pN)
 * @endcode
 * donde @c vK es el valor y @c pK la prioridad del k-ésimo elemento
 * en orden de inserción. Si la cola está vacía escribe
 * @c "Cola de prioridad vacia".
 * La cadena siempre queda terminada en @c '\0' si @p capacidad >= 1.
 *
 * @param[in]  cola      Puntero constante a la ColaPrioridad.
 * @param[out] destino   Buffer donde se escribirá la cadena resultante.
 * @param[in]  capacidad Tamaño en bytes del buffer @p destino.
 *
 * @pre  @p destino debe apuntar a un buffer de al menos @p capacidad bytes.
 * @post @p destino contiene una cadena terminada en @c '\0'.
 * @note Si el contenido supera @p capacidad se trunca de forma segura.
 * @note Si @p destino es NULL o @p capacidad es 0, no hace nada.
 * @note Complejidad temporal: O(n).
 */
void cp_formatear(const ColaPrioridad *cola, char *destino, size_t capacidad) {
    CPNodo *aux;
    size_t usado = 0;

    if (destino == NULL || capacidad == 0) {
        return;
    }

    destino[0] = '\0';

    if (cola == NULL || cola->delante == NULL) {
        snprintf(destino, capacidad, "Cola de prioridad vacia");
        return;
    }

    cp_append_text(destino, capacidad, &usado, "frente -> ");

    aux = cola->delante;
    while (aux != NULL && usado < capacidad) {
        cp_append_text(destino, capacidad, &usado, "%d(p=%d)", aux->valor, aux->prioridad);
        aux = aux->sgte;
        if (aux != NULL && usado < capacidad) {
            cp_append_text(destino, capacidad, &usado, " | ");
        }
    }
}

/*
 * @brief Elimina todos los elementos de la cola y libera su memoria.
 *
 * @details
 * Recorre la cola desde @c delante hasta el final usando un puntero
 * @c next para guardar el enlace antes de liberar cada @c CPNodo.
 * Al finalizar, @c delante y @c atras quedan en NULL.
 *
 * @param cola Puntero a la ColaPrioridad a vaciar.
 *                     Si es NULL la función no hace nada.
 *
 * @post La cola queda en el mismo estado que tras cp_inicializar().
 * @note Complejidad temporal: O(n).
 */
/**
 * @brief Elimina todos los elementos de la cola y libera su memoria.
 *
 * @details
 * Recorre la cola desde @c delante hasta el final usando un puntero
 * @c next para guardar el enlace antes de liberar cada @c CPNodo.
 * Al finalizar, @c delante y @c atras quedan en NULL.
 *
 * @param[in,out] cola Puntero a la ColaPrioridad a vaciar.
 *                     Si es NULL la función no hace nada.
 *
 * @post La cola queda en el mismo estado que tras cp_inicializar().
 * @note Complejidad temporal: O(n).
 */
void cp_vaciar(ColaPrioridad *cola) {
    CPNodo *aux;
    CPNodo *next;

    if (cola == NULL) {
        return;
    }

    aux = cola->delante;
    while (aux != NULL) {
        next = aux->sgte;
        cola->delante = next;
        if (cola->atras == aux) {
            cola->atras = NULL;
        }
        free(aux);
        if (cola->cantidad > 0) {
            cola->cantidad--;
        }
        aux = next;
    }

    cola->delante = NULL;
    cola->atras = NULL;
    cola->cantidad = 0;
}
