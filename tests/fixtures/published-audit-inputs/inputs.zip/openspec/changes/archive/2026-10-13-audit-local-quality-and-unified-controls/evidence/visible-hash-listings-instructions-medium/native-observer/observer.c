#include "tad_tabla_hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

/**
 * @file tad_tabla_hash.c
 * @brief Implementación del TAD Tabla Hash.
 */

/**
 * @brief Ajunta texto formateado dentro de un buffer acotado.
 * @param destino Buffer de salida.
 * @param capacidad Tamaño total del buffer, incluido el terminador.
 * @param usado Contador de bytes usados que se actualiza o satura a capacidad.
 * @param fmt Formato de vsnprintf para los argumentos variables.
 */

static int qa_case,qa_sample;
static void qa_write(const char *tag,const char *destino,size_t cap,size_t used,int count){
 fprintf(stderr,"{\"case\":%d,\"sample\":%d,\"event\":\"%s\",\"capacity\":%zu,\"used\":%zu,\"written\":%d,\"hex\":\"",qa_case,qa_sample,tag,cap,used,count);
 for(size_t j=0;destino[j];j++)fprintf(stderr,"%02x",(unsigned char)destino[j]);
 fprintf(stderr,"\"}\n");
}

static void qa_full(const char *event){fprintf(stderr,"{\"case\":%d,\"sample\":%d,\"event\":\"%s\",\"full\":true}\n",qa_case,qa_sample,event);}
static int qa_condition(const char *event,int value){qa_full(event);return value;}

static void th_append_text(char *destino, size_t capacidad, size_t *usado, const char *fmt, ...) {
    qa_full("append_entry");
    va_list args; qa_full("args_declared");
    int escritos; qa_full("written_declared");

    if (qa_condition("append_guard", destino == NULL || usado == NULL || *usado >= capacidad)) {
        qa_full("append_return"); return;
    }

    va_start(args, fmt); qa_full("va_start");
    escritos = vsnprintf(destino + *usado, capacidad - *usado, fmt, args);
    qa_write("vsnprintf_write",destino,capacidad,*usado,escritos); qa_full("vsnprintf_write"); va_end(args); qa_full("va_end");
    if (qa_condition("encoding_guard", escritos < 0)) {
        return;
    }
    if (qa_condition("truncation_guard", (size_t)escritos >= capacidad - *usado)) {
        *usado = capacidad; qa_write("used_saturated",destino,capacidad,*usado,escritos); qa_full("used_saturated");
    } else {
        *usado += (size_t)escritos; qa_write("used_advanced",destino,capacidad,*usado,escritos); qa_full("used_advanced");
    }
    qa_full("append_return");
}

/**
 * @brief Normaliza el módulo de una clave, incluidas claves negativas.
 * @param tabla Tabla con capacidad positiva.
 * @param clave Clave entera.
 * @return Índice entre 0 y capacidad-1, o -1 ante tabla NULL o capacidad no positiva.
 */
int th_indice(const TablaHash *tabla, int clave) {
    if (!tabla || tabla->capacidad <= 0) return -1;
    int indice = clave % tabla->capacidad;
    if (indice < 0) {
        indice += tabla->capacidad;
    }
    return indice;
}

/*
 * @brief Inicializa la tabla hash.
 * @param tabla Puntero a la tabla hash.
 * @param capacidad Capacidad (número de buckets) de la tabla.
 */
/**
 * @brief Inicializa la tabla hash.
 * @param[out] tabla Puntero a la tabla hash.
 * @param[in] capacidad Capacidad (número de buckets) de la tabla.
 */
void th_inicializar(TablaHash *tabla, int capacidad) {
    if (!tabla || capacidad <= 0) return;
    
    tabla->capacidad = capacidad;
    tabla->cantidad = 0;
    tabla->buckets = (THNodo **)malloc(capacidad * sizeof(THNodo *));
    
    if (tabla->buckets) {
        for (int i = 0; i < capacidad; i++) {
            tabla->buckets[i] = NULL;
        }
    } else {
        tabla->capacidad = 0; // Error de memoria
    }
}

/*
 * @brief Inserta un par clave-valor, actualizando el valor si la clave existe.
 * @param tabla Puntero a la tabla hash.
 * @param clave Clave a insertar.
 * @param valor Valor asociado a la clave.
 * @return true si se insertó o actualizó correctamente, false en error.
 */
/**
 * @brief Inserta un par clave-valor, actualizando el valor si la clave existe.
 * @param[in,out] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a insertar.
 * @param[in] valor Valor asociado a la clave.
 * @return true si se insertó o actualizó correctamente, false en error.
 */
bool th_insertar(TablaHash *tabla, int clave, int valor) {
    if (!tabla || !tabla->buckets || tabla->capacidad <= 0) return false;
    
    int indice = th_indice(tabla, clave);
    THNodo *actual = tabla->buckets[indice];
    
    // Buscar si ya existe para actualizar
    while (actual != NULL) {
        if (actual->clave == clave) {
            actual->valor = valor;
            return true;
        }
        actual = actual->siguiente;
    }
    
    // No existe, insertar al principio del bucket
    THNodo *nuevo = (THNodo *)malloc(sizeof(THNodo));
    if (!nuevo) return false;
    
    nuevo->clave = clave;
    nuevo->valor = valor;
    nuevo->siguiente = tabla->buckets[indice];
    tabla->buckets[indice] = nuevo;
    tabla->cantidad++;
    
    return true;
}

/*
 * @brief Busca el valor asociado a una clave.
 * @param tabla Puntero a la tabla hash constante.
 * @param clave Clave a buscar.
 * @param valor Puntero donde se almacenará el valor si se encuentra.
 * @return true si se encontró la clave, false si no.
 */
/**
 * @brief Busca el valor asociado a una clave.
 * @param[in] tabla Puntero a la tabla hash constante.
 * @param[in] clave Clave a buscar.
 * @param[out] valor Puntero donde se almacenará el valor si se encuentra.
 * @return true si se encontró la clave, false si no.
 */
bool th_buscar(const TablaHash *tabla, int clave, int *valor) {
    if (!tabla || !tabla->buckets || tabla->capacidad <= 0 || !valor) return false;
    
    int indice = th_indice(tabla, clave);
    THNodo *actual = tabla->buckets[indice];
    
    while (actual != NULL) {
        if (actual->clave == clave) {
            *valor = actual->valor;
            return true;
        }
        actual = actual->siguiente;
    }
    
    return false;
}

/*
 * @brief Verifica si una clave existe en la tabla.
 * @param tabla Puntero a la tabla hash.
 * @param clave Clave a verificar.
 * @return true si la clave existe, false si no.
 */
/**
 * @brief Verifica si una clave existe en la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a verificar.
 * @return true si la clave existe, false si no.
 */
bool th_contiene(const TablaHash *tabla, int clave) {
    int dummy_valor;
    return th_buscar(tabla, clave, &dummy_valor);
}

/*
 * @brief Elimina una clave de la tabla hash.
 * @param tabla Puntero a la tabla hash.
 * @param clave Clave a eliminar.
 * @return true si fue eliminada, false si no existía o error.
 */
/**
 * @brief Elimina una clave de la tabla hash.
 * @param[in,out] tabla Puntero a la tabla hash.
 * @param[in] clave Clave a eliminar.
 * @return true si fue eliminada, false si no existía o error.
 */
bool th_eliminar(TablaHash *tabla, int clave) {
    if (!tabla || !tabla->buckets || tabla->capacidad <= 0) return false;
    
    int indice = th_indice(tabla, clave);
    THNodo *actual = tabla->buckets[indice];
    THNodo *anterior = NULL;
    
    while (actual != NULL) {
        if (actual->clave == clave) {
            if (anterior == NULL) {
                tabla->buckets[indice] = actual->siguiente;
            } else {
                anterior->siguiente = actual->siguiente;
            }
            free(actual);
            tabla->cantidad--;
            return true;
        }
        anterior = actual;
        actual = actual->siguiente;
    }
    
    return false;
}

/*
 * @brief Elimina todos los elementos manteniendo la capacidad de la tabla.
 * @param tabla Puntero a la tabla hash.
 */
/**
 * @brief Elimina todos los elementos manteniendo la capacidad de la tabla.
 * @param[in,out] tabla Puntero a la tabla hash.
 */
void th_vaciar(TablaHash *tabla) {
    if (!tabla || !tabla->buckets) return;
    
    for (int i = 0; i < tabla->capacidad; i++) {
        THNodo *actual = tabla->buckets[i];
        while (actual != NULL) {
            THNodo *siguiente = actual->siguiente;
            free(actual);
            actual = siguiente;
        }
        tabla->buckets[i] = NULL;
    }
    tabla->cantidad = 0;
}

/*
 * @brief Destruye la tabla hash liberando toda su memoria.
 * @param tabla Puntero a la tabla hash.
 */
/**
 * @brief Destruye la tabla hash liberando toda su memoria.
 * @param[in,out] tabla Puntero a la tabla hash.
 */
void th_destruir(TablaHash *tabla) {
    if (!tabla || !tabla->buckets) return;
    
    th_vaciar(tabla);
    free(tabla->buckets);
    tabla->buckets = NULL;
    tabla->capacidad = 0;
    tabla->cantidad = 0;
}

/*
 * @brief Indica si la tabla está vacía.
 * @param tabla Puntero a la tabla hash.
 * @return true si la cantidad es 0, false caso contrario.
 */
/**
 * @brief Indica si la tabla está vacía.
 * @param[in] tabla Puntero a la tabla hash.
 * @return true si la cantidad es 0, false caso contrario.
 */
bool th_vacia(const TablaHash *tabla) {
    if (!tabla) return true;
    return tabla->cantidad == 0;
}

/*
 * @brief Retorna la cantidad de elementos en la tabla.
 * @param tabla Puntero a la tabla hash.
 * @return Cantidad de elementos almacenados.
 */
/**
 * @brief Retorna la cantidad de elementos en la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Cantidad de elementos almacenados.
 */
int th_cantidad(const TablaHash *tabla) {
    if (!tabla) return 0;
    return tabla->cantidad;
}

/*
 * @brief Retorna la capacidad actual de la tabla.
 * @param tabla Puntero a la tabla hash.
 * @return Capacidad (número de buckets).
 */
/**
 * @brief Retorna la capacidad actual de la tabla.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Capacidad (número de buckets).
 */
int th_capacidad(const TablaHash *tabla) {
    if (!tabla) return 0;
    return tabla->capacidad;
}

/*
 * @brief Calcula y retorna las estadísticas de la tabla hash.
 * @param tabla Puntero a la tabla hash.
 * @return Estructura con las estadísticas calculadas.
 */
/**
 * @brief Calcula y retorna las estadísticas de la tabla hash.
 * @param[in] tabla Puntero a la tabla hash.
 * @return Estructura con las estadísticas calculadas.
 */
THEstadisticas th_estadisticas(const TablaHash *tabla) {
    THEstadisticas stats = {0};
    
    if (!tabla || !tabla->buckets || tabla->capacidad <= 0) return stats;
    
    stats.capacidad = tabla->capacidad;
    stats.cantidad = tabla->cantidad;
    stats.factor_carga = (float)tabla->cantidad / (float)tabla->capacidad;
    
    for (int i = 0; i < tabla->capacidad; i++) {
        THNodo *actual = tabla->buckets[i];
        if (actual != NULL) {
            stats.buckets_ocupados++;
            int nodos_en_bucket = 0;
            while (actual != NULL) {
                nodos_en_bucket++;
                actual = actual->siguiente;
            }
            if (nodos_en_bucket > 1) {
                stats.colisiones += (nodos_en_bucket - 1);
            }
        }
    }
    
    return stats;
}

/*
 * @brief Formatea el contenido de la tabla hash en una cadena de texto.
 * @param tabla Puntero a la tabla hash.
 * @param destino Buffer donde se escribirá la representación.
 * @param capacidad Tamaño máximo del buffer destino.
 */
/**
 * @brief Formatea el contenido de la tabla hash en una cadena de texto.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[out] destino Buffer donde se escribirá la representación.
 * @param[in] capacidad Tamaño máximo del buffer destino.
 */
void th_formatear(const TablaHash *tabla, char *destino, size_t capacidad) {
    qa_full("formatter_entry");
    if (qa_condition("destination_guard", !destino || capacidad == 0)) {qa_full("formatter_return"); return;}
    destino[0] = '\0'; qa_full("initial_terminator");
    
    if (qa_condition("table_guard", !tabla || !tabla->buckets)) {
        snprintf(destino, capacidad, "Tabla no inicializada\n"); qa_full("uninitialized_table_text");
        qa_full("formatter_return"); return;
    }
    
    size_t usado = 0; qa_full("used_declared");
    for (int i = (qa_full("bucket_init"),0); qa_condition("bucket_guard", i < tabla->capacidad && usado < capacidad); i++,qa_full("bucket_increment")) {
        qa_full("append_call"); th_append_text(destino, capacidad, &usado, "[%d] -> ", i);
        
        THNodo *actual = tabla->buckets[i]; qa_full("actual_declared");
        while (qa_condition("chain_guard", actual != NULL && usado < capacidad)) {
            qa_full("append_call"); th_append_text(destino, capacidad, &usado, "(%d:%d) -> ", actual->clave, actual->valor);
            actual = actual->siguiente; qa_full("actual_advance");
        }
        
        if (qa_condition("null_label_guard", usado < capacidad)) {
            qa_full("append_call"); th_append_text(destino, capacidad, &usado, "NULL\n");
        }
        qa_full("bucket_body_exit");
    }
    qa_full("bucket_loop_exit");
    qa_full("formatter_return");
}

/*
 * @brief Formatea las estadísticas de la tabla en una cadena de texto.
 * @param tabla Puntero a la tabla hash.
 * @param destino Buffer donde se escribirá la representación.
 * @param capacidad Tamaño máximo del buffer destino.
 */
/**
 * @brief Formatea las estadísticas de la tabla en una cadena de texto.
 * @param[in] tabla Puntero a la tabla hash.
 * @param[out] destino Buffer donde se escribirá la representación.
 * @param[in] capacidad Tamaño máximo del buffer destino.
 */
void th_formatear_estadisticas(const TablaHash *tabla, char *destino, size_t capacidad) {
    if (!destino || capacidad == 0) return;
    destino[0] = '\0';
    
    if (!tabla || !tabla->buckets) {
        snprintf(destino, capacidad, "Tabla no inicializada\n");
        return;
    }
    
    THEstadisticas stats = th_estadisticas(tabla);
    snprintf(destino, capacidad, 
             "Capacidad: %d\n"
             "Cantidad: %d\n"
             "Buckets ocupados: %d\n"
             "Colisiones: %d\n"
             "Factor de carga: %.2f\n",
             stats.capacidad, stats.cantidad, stats.buckets_ocupados, 
             stats.colisiones, stats.factor_carga);
}

_Static_assert(_Generic(&th_formatear, void (*)(const TablaHash *,char *,size_t):1,default:0),"formatter types");
_Static_assert(_Generic(&th_append_text, void (*)(char *,size_t,size_t *,const char *,...):1,default:0),"helper types");
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "tad_tabla_hash.h"
static void sample(int cid,int sample_id,const TablaHash*t,size_t cap,int null_dest){
 struct {unsigned char left[16];unsigned char buffer[4096];unsigned char right[16];} block;
 qa_case=cid;qa_sample=sample_id;memset(&block,0xA5,sizeof(block));th_formatear(t,null_dest?NULL:(char*)block.buffer,cap);
 int outside=0;for(size_t i=cap;i<sizeof(block.buffer);i++)outside+=block.buffer[i]!=0xA5;
 for(int i=0;i<16;i++){assert(block.left[i]==0xA5);assert(block.right[i]==0xA5);}assert(!outside);
 printf("{\"case\":%d,\"sample\":%d,\"capacity\":%zu,\"null_destination\":%s,\"outside_changed\":%d,\"first_byte\":%u,\"hex\":\"",cid,sample_id,cap,null_dest?"true":"false",outside,(unsigned)block.buffer[0]);
 for(size_t i=0;i<cap;i++){printf("%02x",(unsigned)block.buffer[i]);}printf("\",\"pairs\":[");int first=1;
 if(t&&t->buckets){for(int i=0;i<t->capacidad;i++){for(const THNodo*n=t->buckets[i];n;n=n->siguiente){if(!first)printf(",");first=0;printf("[%d,%d]",n->clave,n->valor);}}}printf("]}\n");}
int main(void){{TablaHash t={0};th_inicializar(&t,3);if(!t.buckets)return 1;sample(0,0,&t,0,0);sample(0,1,&t,1,0);sample(0,2,&t,2,0);sample(0,3,&t,8,0);sample(0,4,&t,16,0);sample(0,5,&t,64,0);sample(0,6,&t,128,0);sample(0,7,&t,2048,0);sample(0,8,&t,4096,0);th_destruir(&t);}{TablaHash t={0};th_inicializar(&t,3);if(!t.buckets)return 1;if(!th_insertar(&t,1,10))return 2;if(!th_insertar(&t,4,40))return 2;if(!th_insertar(&t,7,40))return 2;if(!th_insertar(&t,0,0))return 2;if(!th_insertar(&t,-1,-10))return 2;sample(1,0,&t,0,0);sample(1,1,&t,1,0);sample(1,2,&t,2,0);sample(1,3,&t,8,0);sample(1,4,&t,16,0);sample(1,5,&t,64,0);sample(1,6,&t,128,0);sample(1,7,&t,2048,0);sample(1,8,&t,4096,0);th_destruir(&t);}{TablaHash t={0};th_inicializar(&t,1);if(!t.buckets)return 1;if(!th_insertar(&t,(-2147483647-1),2147483647))return 2;if(!th_insertar(&t,2147483647,(-2147483647-1)))return 2;if(!th_insertar(&t,0,(-2147483647-1)))return 2;if(!th_insertar(&t,1,0))return 2;sample(2,0,&t,0,0);sample(2,1,&t,1,0);sample(2,2,&t,2,0);sample(2,3,&t,8,0);sample(2,4,&t,16,0);sample(2,5,&t,64,0);sample(2,6,&t,128,0);sample(2,7,&t,2048,0);sample(2,8,&t,4096,0);th_destruir(&t);}{TablaHash t={0};th_inicializar(&t,7);if(!t.buckets)return 1;if(!th_insertar(&t,-7,70))return 2;if(!th_insertar(&t,7,70))return 2;if(!th_insertar(&t,14,-14))return 2;if(!th_insertar(&t,2,2))return 2;sample(3,0,&t,0,0);sample(3,1,&t,1,0);sample(3,2,&t,2,0);sample(3,3,&t,8,0);sample(3,4,&t,16,0);sample(3,5,&t,64,0);sample(3,6,&t,128,0);sample(3,7,&t,2048,0);sample(3,8,&t,4096,0);th_destruir(&t);}sample(4,0,NULL,64,0);{TablaHash t={0};sample(4,1,&t,64,0);sample(4,2,&t,64,1);}return 0;}