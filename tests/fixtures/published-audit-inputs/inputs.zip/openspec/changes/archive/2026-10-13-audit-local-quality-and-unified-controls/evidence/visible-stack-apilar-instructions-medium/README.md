# Pila apilar: checkpoint MEDIUM recuperado; revisión LOW pendiente

Proyecto canónico D:\MisProyectos\Web_VisualEstruct. Implementación: coordination-stack-apilar-instructions-medium-20261003. Nueva instrucción de recuperación LOW: coordination-stack-apilar-documentary-recovery-low-20261003 (coordinación01a0fe61-3104-743a-b032-bcc289ad80cd). Before recuperado exit0. Tras desconexión se completa únicamente seguimiento; no implementación ni pruebas funcionales repetidas. After se guarda en evidencia.

Motor exclusivo apilar: caller ptrPila vivo, p:ptrPila* a &pila, valor:int y aux:ptrPila con scope/init reales. Guardas pNULL y mallocNULL; malloc opaco, aux indeterminado durante llamada; NULL de resultado es valor determinado. Nodo temporal con nro/sgte inválidos y máscaras0→1→3 mediante escrituras individuales, publicación posterior *p=aux. Identidad/aliases estables hasta retorno void, que termina sólo callee. Diagnósticos y conservación de estado en fallos directos privados; sin nuevas flags API ni contratos C.

Preparación stack_push_prepared_v1 ligada a digest del historial: GET sin build/dispatch, error preserva, éxito posterior/reset invalida; namespace de limpieza separado. Renderer propio representa nro/sgte y su validez sin leer campos indeterminados. Inicial sólo caller sin aux/llamada/línea futura; retorno sincallee. Restauración de valor y clave permite botón real Siguiente tras reload sin repetir POST.

Oráculo C seguro reutilizado:14calls124events27conditions,32observaciones originales,0divergencias en secuencia/ramas/raíz/heap/máscaras/campos/aliases/console/retorno. OchoAPI y seis fallosdirectos privados(pNULL y cinco mallocNULLincluido vacío). No nuevo C nativo ni UB/OOMreal.

UI ocho pushes, dos vistas160adelante144atrás, cuatro historial+traza exactos al recargar y replay real por botón Siguiente, cinco secciones,0JSerrors/extraPOST. MainDOM obtiene fuenteHTTP existente, con versión asíncrona que evita sobrescribir historial nuevo con respuesta antigua. Fuente igual normalizando LF/CRLF únicamente. Cuatro historias, dos superficies actuales:ambas cuatro mainsC17estricto,12alloc12free0live por ruta, doce posicionesNULL por ruta return1/cleanup equilibrado/sin éxito falso. No8historias ni24fixtures independientes. Doxygen real C/H+4mains por ruta:0warnings,4/4main documentados. Downloadbuilder y C/H intactos.

30IDs30pass1.07s:26originales+4disjuntos,0xfail. Logs baseline12pass14fail y QA anteriores conservados. Comparación124events/fallos, malloc/init/alias, GETno build/invalidation y main/replayreal cubiertos. No sumar corridas QA previas; qa-corrections.md distingue primera JSONrecarga de comprobación de botón y activación del modo pasoapasotrasreload.

Recursos finitos ocho llamadas: picoPython1,682,650bytes, JSONmáximo122,811bytes, máximo instrumentado0.19778499999665655s. Incluye dispatch/sesión/serialización; no RSS/browser/C/SLA ni profundidad/historial/OOMuniversales. Mayor costo que LOW513194bytes/27562JSON/.0374567s por frames/scopes/tracepersistida, registrado sin garantía de stress.

Recuperación:217/221protegidos idénticos,cuatroshared previstos, dosmódulos nuevos; C/H/copias nativas/caller descargado/motorescerrados iguales. Hashes de ocho callers actuales coinciden con reportes y copias compiladas, fuente DOM/HTTP igual;124events y27conditions reconstruidos desde reportenativo, evidenciaUI/caller/Doxvalidada por contenido. No había fotografía SHAfinal de producto antesoffline: fechas seisfuentes anteriores al log30pass y revisión fuente actual apoyan reutilización, pero no prueban criptográficamente estado histórico. Freshmanifests capturados ahora, límite explícito en recovery-verification.json; no inventar hashprevio.

Preview antiguo76444/77508 ausente y5051libre tras reconexión; restablecido único launcher17524, identidad/listener registrados en preview-recovery-identity.json y preview-recovery-listener.json, GETstack200. No detener conhost ajeno. No procesosQA supervivientes ni suitescerradas repetidas.

Pendiente LOW: revisar freshSHA/evidencia/alcance y decidir consolidación únicamente stack.apilar.instructions. Sin cierre funcional/global aquí. Preservar limpiezaPila/Cola/Prioridad, popcomunicado, Hash11/Sorting11, RN/Grafos/Dijkstra decisionespendientes. Global13/22docs121/208sin incremento; C1ledger intacto. Sin commit/push/merge/despliegue.

Evidencia: evidence/visible-stack-apilar-instructions-medium/summary.json, recovery-verification.json, product/test-source/reused-baseline manifests y reportes/logs originales.
