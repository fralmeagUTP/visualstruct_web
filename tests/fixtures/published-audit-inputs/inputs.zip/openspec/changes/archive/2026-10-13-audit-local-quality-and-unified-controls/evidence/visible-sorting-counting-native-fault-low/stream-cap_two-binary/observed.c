#include <io.h>
#include <fcntl.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "tad_ordenamiento.h"
static int *root,*counts,minv,maxv,have_min,have_max,case_id,comparisons,moves,allocs,frees;static size_t count,range,wi,hi,output;static int iw,ih,ir,io;
static uint64_t event_index, count_h1, count_h2;
_Static_assert(sizeof(size_t)==8,"safe size_t64 observer only");
static void emit(const char*t,int condition){
 static const char*names[]={"allocation_guard","array_write","bucket_test","count_fill","count_free","count_init","count_write","declare","fill_increment","fill_init","fill_test","helper_i_declare","initial","max_assign","max_compare","max_init","min_assign","min_compare","min_init","minmax_call","minmax_entry","minmax_guard","minmax_return","minmax_status","output_init","range_compute","range_guard","range_limit","rebuild_increment","rebuild_init","rebuild_test","scan_increment","scan_init","scan_test","size_guard","sort_entry","sort_guard","sort_return","valid_call","valid_entry","valid_n","valid_ptr"}; size_t id=0;uint64_t a1=0,a2=0;
 for(id=0;id<sizeof(names)/sizeof(names[0]);id++)if(!strcmp(t,names[id]))break;
 if(id==sizeof(names)/sizeof(names[0]))exit(8);
 for(size_t z=0;z<count;z++){uint64_t weight=(uint64_t)z+1,value=(uint64_t)(int64_t)root[z];a1+=weight*value;a2+=weight*weight*value;}
 uint64_t nil=UINT64_C(0xD1B54A32D192ED03);
 uint64_t row[]={event_index++,(uint64_t)id,(uint64_t)(condition<0?2:condition),a1,a2,have_min?(uint64_t)(int64_t)minv:nil,have_max?(uint64_t)(int64_t)maxv:nil,iw?(uint64_t)wi:nil,ih?(uint64_t)hi:nil,ir?(uint64_t)range:nil,io?(uint64_t)output:nil,counts?count_h1:0,counts?count_h2:0,counts?1:0,(uint64_t)comparisons,(uint64_t)moves,(uint64_t)allocs,(uint64_t)frees};
 if(fwrite(row,sizeof(row),1,stdout)!=1)exit(9);
}
static int cond(const char*t,int r){if(!strcmp(t,"min_compare")||!strcmp(t,"max_compare"))comparisons++;emit(t,r);return r;}

static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry",-1);
	return cond("valid_ptr",arreglo!=NULL) && cond("valid_n",n>0);
}
static int obtener_minimo_maximo(const int arreglo[], size_t n, int *minimo, int *maximo) {emit("minmax_entry",-1);
	size_t i;emit("helper_i_declare",-1);
	if(cond("minmax_guard",!arreglo_valido(arreglo,n) || minimo==NULL || maximo==NULL))return ORDENAMIENTO_ERROR;
	*minimo=arreglo[0];minv=*minimo;have_min=1;emit("min_init",-1);*maximo=arreglo[0];maxv=*maximo;have_max=1;emit("max_init",-1);
	for(i=1,hi=i,ih=1,emit("scan_init",-1);cond("scan_test",i<n);++i,hi=i,emit("scan_increment",-1)) {
		if(cond("min_compare",arreglo[i]<*minimo)){*minimo=arreglo[i];minv=*minimo;emit("min_assign",-1);}
		if(cond("max_compare",arreglo[i]>*maximo)){*maximo=arreglo[i];maxv=*maximo;emit("max_assign",-1);}
	}
	ih=0;emit("minmax_return",-1);return ORDENAMIENTO_OK;
}
int ordenar_counting_sort(int arreglo[], size_t n) {emit("sort_entry",-1);
	int minimo,maximo;size_t rango,i,indice;int *conteo;emit("declare",-1);
	emit("valid_call",-1);if(cond("sort_guard",!arreglo_valido(arreglo,n)))return ORDENAMIENTO_ERROR;
	emit("minmax_call",-1);if(cond("minmax_status",!obtener_minimo_maximo(arreglo,n,&minimo,&maximo)))return ORDENAMIENTO_ERROR;
	rango=(size_t)((long long)maximo-(long long)minimo+1LL);range=rango;ir=1;emit("range_compute",-1);
	if(cond("range_guard",cond("range_limit",rango>ORDENAMIENTO_RANGO_MAX) || cond("size_guard",rango>SIZE_MAX/sizeof(int))))return ORDENAMIENTO_ERROR;
	conteo=(int*)calloc(rango,sizeof(int));counts=conteo;if(conteo)allocs++;emit("count_init",-1);
	if(cond("allocation_guard",conteo==NULL))return ORDENAMIENTO_ERROR;
	for(i=0,wi=i,iw=1,emit("fill_init",-1);cond("fill_test",i<n);++i,wi=i,emit("fill_increment",-1)){++conteo[arreglo[i]-minimo];count_h1+=(uint64_t)(arreglo[i]-minimo)+1;count_h2+=((uint64_t)(arreglo[i]-minimo)+1)*((uint64_t)(arreglo[i]-minimo)+1);moves++;emit("count_fill",-1);}
	indice=0;output=indice;io=1;emit("output_init",-1);
	for(i=0,wi=i,emit("rebuild_init",-1);cond("rebuild_test",i<rango);++i,wi=i,emit("rebuild_increment",-1))
		while(cond("bucket_test",conteo[i]>0)){arreglo[indice++]=(int)i+minimo;output=indice;moves++;emit("array_write",-1);--conteo[i];count_h1-=(uint64_t)i+1;count_h2-=((uint64_t)i+1)*((uint64_t)i+1);moves++;emit("count_write",-1);}
	free(conteo);counts=NULL;frees++;emit("count_free",-1);
	iw=ir=io=have_min=have_max=0;emit("sort_return",-1);return ORDENAMIENTO_OK;
}
int main(void){_setmode(_fileno(stdout),_O_BINARY);uint16_t endian=1;if(*(unsigned char*)&endian!=1)return 7;{int a[]={999999,0};root=a;count=sizeof(a)/sizeof(a[0]);case_id=0;counts=NULL;have_min=have_max=iw=ih=ir=io=comparisons=moves=allocs=frees=0;emit("initial",-1);if(ordenar_counting_sort(a,count)!=ORDENAMIENTO_OK)return 2;}fprintf(stderr,"EVENTS %llu ALLOCS %d FREES %d\n",(unsigned long long)event_index,allocs,frees);return 0;}