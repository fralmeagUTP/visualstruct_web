#ifndef TAD_GRAFO_H
#define TAD_GRAFO_H

/**
 * @file tad_grafo.h
 * @brief TAD Grafo dirigido ponderado implementado con listas enlazadas.
 */

/** @brief Nodo de vertice. */
typedef struct NodoV {
    int dato; /**< Identificador del vértice. */
    struct NodoV* sig; /**< Siguiente nodo de la lista; NULL al terminar. */
    int marcado; /**< Marca de visita de recorridos. */
} *ListaVertice;

/** @brief Nodo de arco. */
typedef struct NodoA {
    int origen; /**< Identificador del origen del arco. */
    int destino; /**< Identificador del destino del arco. */
    int costo; /**< Peso entero del arco. */
    struct NodoA* sig; /**< Siguiente nodo de la lista; NULL al terminar. */
    } *ListaArco;

/** @brief Estructura principal del grafo. */
typedef struct nodoGrafo {
    ListaVertice v; /**< Lista de vértices. */
    ListaArco a; /**< Lista de arcos. */
} Grafo;

/** @brief Estructura auxiliar para Union-Find. */
typedef struct Conjunto {
    int *padre; /**< Arreglo de índices de padre para Union-Find. */
    int n; /**< Número de elementos del arreglo padre. */
} Conjunto;

/**
 * @brief Crea un grafo vacío.
 * @return Grafo - Un grafo vacío.
 */
Grafo grafo_crear(void);
/**
 * @brief Inserta un vértice en el grafo
 * @param g Grafo en el cual se insertará el vértice
 * @param x Vértice a insertar
 * @return Grafo con el nuevo vértice
*/
Grafo grafo_insertar_vertice(Grafo g, int x);
/**
 * @brief Inserta un arco en el grafo
 * @param g Grafo en el cual se insertará el arco
 * @param x Vértice origen
 * @param y Vértice destino
 * @param z Costo del arco
 * @return Grafo con el nuevo arco
 */
Grafo grafo_insertar_arco(Grafo g, int x, int y, int z);
/**
 * @brief Imprime la lista de vértices del grafo
 * @param g Grafo del cual se imprimirán los vértices
 */
void grafo_imprimir_vertices(Grafo g);
/**
 * @brief Imprime la lista de arcos del grafo
 * @param g Grafo del cual se imprimirán los arcos
*/
void grafo_imprimir_arcos(Grafo g);
/**
 * @brief Devuelve la lista de vértices del grafo
 * @param g Grafo del cual se devolverá la lista de vértices
 * @return ListaVertice - La lista de vértices del grafo
 */
ListaVertice grafo_vertices(Grafo g);
/**
 * @brief Devuelve la lista de arcos del grafo
 * @param g Grafo del cual se devolverá la lista de arcos
 * @return ListaArco - La lista de arcos del grafo
*/
ListaArco grafo_arcos(Grafo g);
/**
 * @brief Cambia la lista de vértices del grafo
 * @param g Grafo del cual se cambiará la lista de vértices
 * @param k Nueva lista de vértices
 * @return Grafo con la nueva lista de vértices
*/
Grafo grafo_cambiar_vertices(Grafo g, ListaVertice k);
/**
 * @brief Cambia la lista de arcos del grafo
 * @param g Grafo del cual se cambiará la lista de arcos
 * @param k Nueva lista de arcos
 * @return Grafo con la nueva lista de arcos
*/
Grafo grafo_cambiar_arcos(Grafo g, ListaArco k);
/**
 * @brief Verifica si el grafo es vacio
 * @param g Grafo del cual se verificará si es vacio
 * @return int - 1 si el grafo es vacio, 0 en caso contrario
*/
int grafo_vacio(Grafo g);
/**
 * @brief Verifica si el vértice existe en el grafo
 * @param g Grafo del cual se verificará la existencia del vértice
 * @param x Vértice a buscar
 * @return int - 1 si el vértice existe, 0 en caso contrario
*/
int grafo_existe_vertice(Grafo g, int x);
/**
 * @brief Verifica si el arco existe en el grafo
 * @param g Grafo del cual se verificará la existencia del arco
 * @param x Vértice origen
 * @param y Vértice destino
 * @return int - 1 si el arco existe, 0 en caso contrario
*/
int grafo_existe_arco(Grafo g, int x, int y);
/**
 * @brief Elimina un vértice del grafo
 * @param g Grafo del cual se eliminará el vértice
 * @param x Vértice a eliminar
 * @return Grafo con el vértice eliminado
*/
Grafo grafo_eliminar_vertice(Grafo g, int x);
/**
 * @brief Elimina un arco del grafo
 * @param g Grafo del cual se eliminará el arco
 * @param x Vértice origen
 * @param y Vértice destino
 * @return Grafo con el arco eliminado
*/
Grafo grafo_eliminar_arco(Grafo g, int x, int y);
/**
 * @brief Retorna el costo del arco que parte del vértice x al vértice y del grafo
 * @param g Grafo del cual se retornará el costo del arco
 * @param x Vértice origen
 * @param y Vértice destino
 * @return Costo del arco, o -1 si no existe; un arco válido también puede tener costo -1.
 * @note Para distinguir ausencia de costo -1, consultar grafo_existe_arco.
*/
int grafo_costo_arco(Grafo g, int x, int y);
/**
 * @brief Retorna el número de vértices asociados al grafo
 * @param g Grafo del cual se retornará el número de vértices
 * @return int - El número de vértices asociados al grafo
*/
int grafo_orden(Grafo g);
/**
 * @brief Retorna el número de arcos asociados al grafo
 * @param g Grafo del cual se retornará el número de arcos
 * @return int - El número de arcos asociados al grafo
*/
int grafo_tamano(Grafo g);
/**
 * @brief Retorna el grado del vértice x del grafo
 * @param g Grafo del cual se retornará el grado del vértice
 * @param x Vértice
 * @return int - El grado del vértice
*/
int grafo_grado_vertice(Grafo g, int x);
/**
 * @brief Desmarca un vértice de grafo
 * @param g Grafo del cual se desmarcará el vértice
 * @param x Vértice
 * @return Grafo con el vértice desmarcado  
*/
Grafo grafo_desmarcar_vertice(Grafo g, int x);
/**
 * @brief Pone a cero las marcas de todos los nodos de vertices compartidos.
 * @param[in,out] g Copia por valor del grafo; listas validas o NULL.
 * @return La misma pareja de cabezas; no reserva ni libera nodos.
 * @note Copiar Grafo no copia sus nodos: las escrituras se observan en los aliases.
 */
Grafo grafo_desmarcar(Grafo g);
/**
 * @brief Escribe 1 en la marca del primer vertice cuyo dato es x.
 * @param[in,out] g Grafo por valor con nodos prestados validos.
 * @param x Identificador entero, incluidos negativos y -1.
 * @return La misma pareja de cabezas; si x no existe no cambia nodos.
 * @note No reserva ni libera memoria; el grafo vacio es valido.
 */
Grafo grafo_marcar_vertice(Grafo g, int x);
/**
 * @brief Consulta la marca almacenada del primer vertice coincidente.
 * @param g Grafo prestado por valor; listas validas o NULL.
 * @param x Identificador entero buscado.
 * @return Valor int de marcado, o 0 si x no existe; no normaliza otro valor a 1.
 * @note No modifica nodos ni transfiere propiedad.
 */
int grafo_marcado_vertice(Grafo g, int x);
/**
 * @brief Reserva una lista independiente de destinos de arcos cuyo origen es x.
 * @param g Grafo prestado por valor; lista de arcos valida o NULL.
 * @param x Identificador entero de origen; no exige que exista un vertice x.
 * @return Lista nueva, o NULL sin coincidencias/reservas; el caller libera cada nodo.
 * @note Ante fallo malloc omite ese destino y sigue; puede retornar lista parcial.
 * @note Prepend invierte el orden de recorrido de la lista de arcos; marcado es 0.
 * @note No modifica marcas ni enlaces del grafo original y no imprime salida.
 */
ListaVertice grafo_sucesores(Grafo g, int x);
/**
 * @brief Retorna una lista con los grafo_predecesores de un vértice
 * @param g Grafo del cual se retornará la lista de grafo_predecesores
 * @param x Vértice
 * @return ListaVertice - Una lista con los grafo_predecesores de un vértice
*/
ListaVertice grafo_predecesores(Grafo g, int x);
/**
 * @brief Recorre desde inicio con FIFO y publica una lista nueva en orden BFS.
 * @param[in,out] g Grafo por valor con nodos prestados validos; comparte sus marcas.
 * @param inicio Identificador entero inicial, incluidos negativos y -1.
 * @return Lista nueva de vertices procesados; NULL si inicio no existe o no obtiene nodos.
 * @note Desmarca primero, incluso si inicio falta; luego marca al intentar encolar.
 * @note El caller libera todos los nodos del resultado; sus marcas propias son 0.
 * @note Cola y listas de sucesores son temporales y se liberan durante la ruta normal.
 * @note Fallos de reserva pueden omitir vertices o dar resultado parcial/NULL. Si
 *       cola_encolar falla, BFS puede marcar un vertice que no sera procesado.
 * @note La guarda de cola no vacia permite extraer -1 como dato valido, no como error.
 * @note Ignora costos: minimiza cantidad de arcos, no peso. Este TAD barre listas de
 *       vertices/arcos repetidamente: cota O(V*(V+E)), no O(V+E) de una implementacion
 *       con adyacencia directa y consulta de marcas constante.
 */
ListaVertice grafo_bfs(Grafo g, int inicio);
/**
 * @brief Marca un vértice y agrega su recorrido en profundidad.
 * @param g Grafo cuyos nodos de vértice se marcan.
 * @param actual Vértice actual, que debe pertenecer al grafo.
 * @param recorrido Dirección de una lista de recorrido; NULL se ignora.
 * @note Comparte los nodos y marcas de g y la cabeza referenciada por recorrido.
 * No desmarca ni comprueba que actual estuviera sin visitar: el wrapper y la
 * prueba de marcas de cada sucesor establecen ese contrato. Marca antes de
 * reservar el nodo de resultado, cuyo marcado es 0. Cada frame libera su lista
 * temporal de sucesores, no los nodos del grafo ni el resultado del caller.
 * Un fallo de reserva puede dejar marcas y resultado parciales. Recorrido NULL
 * retorna antes de marcar. Profundidad de recursion acotada por vertices alcanzables.
 */
void grafo_dfs_recursivo(Grafo g, int actual, ListaVertice *recorrido);
/**
 * @brief Desmarca el grafo y recorre desde inicio en profundidad.
 * @param g Grafo cuyos nodos se marcan durante el recorrido.
 * @param inicio Identificador del vértice inicial.
 * @return Lista nueva de vértices visitados, o NULL si inicio no existe o no se reservan nodos.
 * @note Comprueba inicio antes de desmarcar: si falta, conserva las marcas previas.
 * Identificadores negativos, incluido -1, son datos validos. Con inicio valido,
 * desmarca todos los vertices y marca los alcanzables al entrar en recursion.
 * El resultado usa nodos nuevos con marcado=0; el caller libera cada nodo.
 * No libera vertices prestados del grafo ni modifica arcos. El orden depende
 * de la lista de arcos, no de ordenar identificadores. Una reserva fallida
 * puede dejar marcas y resultado parciales; NULL no identifica por si solo la causa.
 * El TAD real barre listas: cota O(V*(V+E)), frente al modelo ideal O(V+E).
 */
ListaVertice grafo_dfs(Grafo g, int inicio);
/**
 * @brief Calcula un camino mínimo con pesos no negativos.
 * @param g Grafo dirigido ponderado.
 * @param inicio Vértice inicial.
 * @param llegada Vértice destino.
 * @return Lista nueva de arcos del camino; NULL si no hay arcos de resultado, hay pesos negativos, vértices inválidos o error de memoria.
 * @note NULL también representa el camino sin arcos de un vértice a sí mismo. El llamador libera el resultado.
 */
ListaArco grafo_dijkstra(Grafo g, int inicio, int llegada);
/**
 * @brief Calcula un camino mínimo admitiendo pesos negativos.
 * @param g Grafo dirigido ponderado.
 * @param inicio Vértice inicial.
 * @param llegada Vértice destino.
 * @return Lista nueva de arcos del camino; NULL si no hay arcos de resultado, vértices inválidos, ciclo negativo alcanzable o error de memoria.
 * @note El llamador libera el resultado. La detección de ciclo negativo escribe una advertencia en stdout.
 */
ListaArco grafo_bellman_ford(Grafo g, int inicio, int llegada);
/**
 * @brief Construye el bosque con la selección de Prim sobre los arcos disponibles.
 * @param g Grafo; para la interpretación no dirigida se requieren arcos simétricos.
 * @param inicio Vértice desde el que comienza la selección.
 * @return Lista nueva de arcos seleccionados o NULL si el bosque no tiene arcos, inicio no existe o falla memoria.
 * @note La implementación omite pesos negativos y reinicia la selección en componentes desconectadas. El llamador libera el resultado.
 */
ListaArco grafo_prim(Grafo g, int inicio);
/**
 * @brief Busca la raíz de Union-Find y comprime el camino.
 * @param c Conjunto con arreglo padre válido y sin ciclos.
 * @param x Índice del elemento.
 * @return Índice de raíz o -1 ante puntero NULL o índice fuera de rango.
 */
int grafo_encontrar_conjunto(Conjunto *c, int x);
/**
 * @brief Enlaza la raíz de y a la raíz de x si ambas son válidas.
 * @param c Conjunto Union-Find que se modifica.
 * @param x Índice del primer elemento.
 * @param y Índice del segundo elemento.
 */
void grafo_unir_conjuntos(Conjunto *c, int x, int y);
/**
 * @brief Selecciona arcos por costo evitando ciclos mediante Union-Find.
 * @param g Grafo cuyos arcos se consideran como conexiones para la selección.
 * @return Lista nueva del bosque seleccionado; NULL si no hay arcos de resultado o falla memoria.
 * @note El llamador libera los nodos del resultado; no se modifica la lista de arcos del grafo.
 */
ListaArco grafo_kruskal(Grafo g);

#endif
