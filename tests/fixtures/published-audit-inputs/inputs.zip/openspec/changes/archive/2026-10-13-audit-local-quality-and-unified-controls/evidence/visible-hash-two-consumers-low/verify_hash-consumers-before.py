import private_limits
private_limits.require_guarded_job()
from pathlib import Path
import sys,os,json
P=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path.cwd()/"tests"))
os.environ.update(PYTHONDONTWRITEBYTECODE="1",SESSION_CACHE_DIR=str(P/"sessions-focal"),FLASK_SECRET_KEY="focal-oracle")
from app.services.hash_structure_service import HashStructureService
original=HashStructureService.execute_operation
captures=[]
def observed(*args,**kwargs):
 r=original(*args,**kwargs);captures.append(r);return r
HashStructureService.execute_operation=staticmethod(observed)
class Capture:
 def pytest_sessionfinish(self,session,exitstatus):
  (P/"hash-consumers-before-traces.json").write_text(json.dumps(captures,indent=2)+"\n",encoding="utf-8")
import pytest
raise SystemExit(pytest.main(["-q","--disable-warnings","--junitxml="+str(P/"hash-consumers-before.xml"),"tests/test_didactic_qa_findings.py::test_hash_001_backend_keeps_c_fixed_capacity","tests/test_execution_trace_golden.py::test_hash_trace_golden"],plugins=[Capture()]))
