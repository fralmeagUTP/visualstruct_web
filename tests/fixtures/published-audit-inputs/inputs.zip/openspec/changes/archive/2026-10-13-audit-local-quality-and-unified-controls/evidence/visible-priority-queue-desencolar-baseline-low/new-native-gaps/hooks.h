#include <stddef.h>
#include <stdbool.h>
#include "tad_cola_prioridad.h"
void qa_event(const char*,ColaPrioridad*,int);bool qa_test(const char*,bool,ColaPrioridad*);void qa_alias(int,CPNodo*);void qa_result(int);void qa_value_written(void);void qa_priority_written(void);void*qa_malloc(size_t);void qa_free(void*);
