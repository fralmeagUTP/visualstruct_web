#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
#include "tad_cola.h"
#define NODE struct NodoCola
static NODE *nodes,*front,*rear,*current_aux;
static int count,fixture,sample;
static void *caller_address;
static char output[4096];
static int identity(NODE *p) { if(p==NULL){return -1;} for(int i=0;i<count;i++){if(p==&nodes[i]){return i;}} assert(0);return -2; }
static void json_string(const char *s) { putchar('"');for(;*s;s++){if(*s=='\n'){printf("\\n");}else if(*s=='\t'){printf("\\t");}else if(*s=='"'||*s=='\\'){putchar('\\');putchar(*s);}else{putchar(*s);}}putchar('"'); }
void qa_event(const char *phase,NODE *aux,int initialized,int condition) {
 printf("{\"method\":\"cola_mostrar\",\"fixture\":%d,\"sample\":%d,\"phase\":",fixture,sample);json_string(phase);
 printf(",\"aux_initialized\":%d,\"aux_id\":%d,\"condition\":%d,\"front_id\":%d,\"rear_id\":%d,\"console\":",initialized,initialized?identity(aux):-2,condition,identity(front),identity(rear));json_string(output);printf(",\"nodes\":[");
 for(int i=0;i<count;i++){if(i){putchar(',');}printf("{\"id\":%d,\"nro\":%d,\"next_id\":%d}",i,nodes[i].nro,identity(nodes[i].sgte));}printf("]}\n");current_aux=aux;
}
void qa_entry(NODE *f,NODE *r,void *parameter_address) {assert(f==front&&r==rear&&parameter_address!=caller_address);qa_event("entry",NULL,0,-1);}
int qa_condition(const char *phase,NODE *aux,int result) {qa_event(phase,aux,1,result);return result;}
void qa_printf(const char *format,...) {size_t n=strlen(output);va_list ap;va_start(ap,format);int written=vsnprintf(output+n,sizeof(output)-n,format,ap);va_end(ap);assert(written>=0&&(size_t)written<sizeof(output)-n);qa_event("printf",current_aux,1,-1);}
static void run(struct Cola q) {
 int old_values[8];NODE *old_links[8];for(int i=0;i<count;i++){old_values[i]=nodes[i].nro;old_links[i]=nodes[i].sgte;}
 caller_address=&q;
 for(int repeat=0;repeat<2;repeat++){output[0]=0;current_aux=NULL;cola_mostrar(q);assert(q.delante==front&&q.atras==rear);for(int i=0;i<count;i++){assert(nodes[i].nro==old_values[i]&&nodes[i].sgte==old_links[i]);}sample++;}
 caller_address=NULL;
}
int main(void) {
 _Static_assert(_Generic(&cola_mostrar,void (*)(struct Cola):1,default:0),"exact void byvalue signature");
 {fixture=0;count=0;nodes=NULL;front=NULL;rear=NULL;struct Cola q={front,rear};run(q);}
 {fixture=1;count=1;NODE fixture_nodes[1];nodes=fixture_nodes;nodes[0].nro=17;nodes[0].sgte=NULL;front=&nodes[0];rear=&nodes[0];struct Cola q={front,rear};run(q);}
 {fixture=2;count=3;NODE fixture_nodes[3];nodes=fixture_nodes;nodes[0].nro=17;nodes[0].sgte=&fixture_nodes[1];nodes[1].nro=9;nodes[1].sgte=&fixture_nodes[2];nodes[2].nro=3;nodes[2].sgte=NULL;front=&nodes[0];rear=&nodes[2];struct Cola q={front,rear};run(q);}
 {fixture=3;count=2;NODE fixture_nodes[2];nodes=fixture_nodes;nodes[0].nro=7;nodes[0].sgte=&fixture_nodes[1];nodes[1].nro=7;nodes[1].sgte=NULL;front=&nodes[0];rear=&nodes[1];struct Cola q={front,rear};run(q);}
 {fixture=4;count=1;NODE fixture_nodes[1];nodes=fixture_nodes;nodes[0].nro=-1;nodes[0].sgte=NULL;front=&nodes[0];rear=&nodes[0];struct Cola q={front,rear};run(q);}
 {fixture=5;count=2;NODE fixture_nodes[2];nodes=fixture_nodes;nodes[0].nro=-1;nodes[0].sgte=&fixture_nodes[1];nodes[1].nro=17;nodes[1].sgte=NULL;front=&nodes[0];rear=&nodes[1];struct Cola q={front,rear};run(q);}
 {fixture=6;count=2;NODE fixture_nodes[2];nodes=fixture_nodes;nodes[0].nro=17;nodes[0].sgte=&fixture_nodes[1];nodes[1].nro=-1;nodes[1].sgte=NULL;front=&nodes[0];rear=&nodes[1];struct Cola q={front,rear};run(q);}
 {fixture=7;count=3;NODE fixture_nodes[3];nodes=fixture_nodes;nodes[0].nro=INT_MIN;nodes[0].sgte=&fixture_nodes[1];nodes[1].nro=0;nodes[1].sgte=&fixture_nodes[2];nodes[2].nro=INT_MAX;nodes[2].sgte=NULL;front=&nodes[0];rear=&nodes[2];struct Cola q={front,rear};run(q);}
 {fixture=8;count=3;NODE fixture_nodes[3];nodes=fixture_nodes;nodes[0].nro=INT_MAX;nodes[0].sgte=&fixture_nodes[1];nodes[1].nro=0;nodes[1].sgte=&fixture_nodes[2];nodes[2].nro=INT_MIN;nodes[2].sgte=NULL;front=&nodes[0];rear=&nodes[2];struct Cola q={front,rear};run(q);}
 {fixture=9;count=1;NODE fixture_nodes[1];nodes=fixture_nodes;nodes[0].nro=19;nodes[0].sgte=NULL;front=&nodes[0];rear=NULL;struct Cola q={front,rear};run(q);}
 {fixture=10;count=1;NODE fixture_nodes[1];nodes=fixture_nodes;nodes[0].nro=19;nodes[0].sgte=NULL;front=NULL;rear=&nodes[0];struct Cola q={front,rear};run(q);}
return 0;}
