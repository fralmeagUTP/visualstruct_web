#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
#include "tad_ordenamiento.h"
static int wrapper_declared,helper_declared,negative_status,positive_status,output_status,have_magnitude;static uint32_t obs_magnitude;static int block_kind,have_index;
static int *root;static size_t root_n;static int case_id,wrapper_active,helper_active,valid_active;
static uint32_t *obs_neg,*obs_pos,*obs_out,*obs_work;static size_t ng,pg,work_n,wi,di,output_index;static uint32_t obs_exp,obs_max,obs_value,obs_digit;static int have_wi,have_di,have_max,have_exp,have_value,have_digit;
static size_t *obs_counts;static unsigned char output_mask[80];
static void *ptrs[256];static int live[256],used,allocs,frees,attempts,fail_at,max_comp,sign_tests,work_writes,count_writes,output_writes,caller_writes;
static int is_live(void*p){for(int i=0;i<used;i++)if(live[i]&&ptrs[i]==p)return 1;return 0;}
static void *qa_malloc(size_t n){attempts++;if(fail_at && attempts==fail_at)return NULL;void*p=malloc(n);if(p){assert(used<256);ptrs[used]=p;live[used++]=1;allocs++;}return p;}
static void qa_free(void*p){if(p){int found=0;for(int i=0;i<used;i++)if(live[i]&&ptrs[i]==p){live[i]=0;found=1;break;}assert(found);if(p==obs_neg){obs_neg=NULL;negative_status=4;}if(p==obs_pos){obs_pos=NULL;positive_status=4;}if(p==obs_out){obs_out=NULL;output_status=4;}frees++;}free(p);}
static void json_u32(uint32_t*p,size_t n,unsigned char*mask){printf("[");for(size_t i=0;i<n;i++){if(i)printf(",");if(mask&&!mask[i])printf("null");else printf("%u",p[i]);}printf("]");}
static void scalar(const char*name,int have,unsigned long long value){printf(",\"%s\":",name);if(have)printf("%llu",value);else printf("null");}
static void emit(const char*t,int condition,int status){
 printf("{\"case\":%d,\"token\":\"%s\",\"condition\":",case_id,t);if(condition<0)printf("null");else printf(condition?"true":"false");printf(",\"array\":[");for(size_t z=0;z<root_n;z++){if(z)printf(",");printf("%d",root[z]);}printf("]");
 printf(",\"negative\":");if(obs_neg)json_u32(obs_neg,ng,NULL);else printf("null");printf(",\"positive\":");if(obs_pos)json_u32(obs_pos,pg,NULL);else printf("null");printf(",\"digit_output\":");if(obs_out)json_u32(obs_out,work_n,output_mask);else printf("null");printf(",\"counts\":");if(helper_active&&obs_counts){printf("[");for(int z=0;z<10;z++){if(z)printf(",");printf("%zu",obs_counts[z]);}printf("]");}else printf("null");
 printf(",\"wrapper_active\":%s,\"helper_active\":%s,\"valid_active\":%s",wrapper_active?"true":"false",helper_active?"true":"false",valid_active?"true":"false");scalar("wrapper_i",have_wi,wi);scalar("helper_i",have_di,di);scalar("maximo",have_max,obs_max);scalar("exp",have_exp,obs_exp);scalar("valor",have_value,obs_value);scalar("digito",have_digit,obs_digit);
 printf(",\"negative_count\":%zu,\"positive_count\":%zu,\"caller_output_index\":%zu,\"allocations\":%d,\"frees\":%d,\"live\":%d,\"max_value_comparisons\":%d,\"sign_tests\":%d,\"work_writes\":%d,\"count_writes\":%d,\"digit_output_writes\":%d,\"caller_writes\":%d",ng,pg,output_index,allocs,frees,allocs-frees,max_comp,sign_tests,work_writes,count_writes,output_writes,caller_writes);scalar("return_status",status>=0,(unsigned long long)status);
 printf(",\"typed_observation\":{\"wrapper_declared\":%s,\"helper_declared\":%s,\"negative_status\":%d,\"positive_status\":%d,\"output_status\":%d,\"helper_n\":",wrapper_declared?"true":"false",helper_declared?"true":"false",negative_status,positive_status,output_status);if(helper_active)printf("%zu",work_n);else printf("null");
 printf(",\"helper_alias\":");if(helper_active)printf(obs_work==obs_neg?"\"negative\"":"\"positive\"");else printf("null");
 scalar("magnitud",have_magnitude,obs_magnitude);
 printf(",\"negative_initialized\":");if(obs_neg){printf("[");for(size_t j=0;j<root_n;j++){if(j)printf(",");printf(j<ng?"true":"false");}printf("]");}else printf("null");
 printf(",\"positive_initialized\":");if(obs_pos){printf("[");for(size_t j=0;j<root_n;j++){if(j)printf(",");printf(j<pg?"true":"false");}printf("]");}else printf("null");
 printf(",\"output_initialized\":");if(obs_out){printf("[");for(size_t j=0;j<work_n;j++){if(j)printf(",");printf(output_mask[j]?"true":"false");}printf("]");}else printf("null");
 printf(",\"block\":%d,\"index_initialized\":%s}}\n",block_kind,have_index?"true":"false");
}
static int cond(const char*t,int value){if(strstr(t,"max_compare"))max_comp++;if(!strcmp(t,"sign_test"))sign_tests++;emit(t,value,-1);return value;}
#define DIG_RETURN(s) do{helper_active=helper_declared=have_di=have_value=have_digit=0;obs_counts=NULL;obs_work=NULL;emit("digit_return",-1,(s));return(s);}while(0)
#define RAD_RETURN(s) do{block_kind=0;wrapper_active=wrapper_declared=have_wi=have_max=have_exp=have_magnitude=0;emit("radix_return",-1,(s));return(s);}while(0)
#define malloc qa_malloc
#define free qa_free

/**
 * @file tad_ordenamiento.c
 * @brief Implementacion didactica de metodos clasicos de ordenamiento en C estandar.
 *
 * Este archivo contiene implementaciones autocontenidas de algoritmos de ordenamiento
 * internos sobre arreglos de enteros. Incluye metodos directos y avanzados:
 * intercambio, seleccion, insercion, burbuja, Shell, QuickSort, MergeSort,
 * HeapSort, Counting Sort, Binsort y Radix Sort.
 *
 * @details
 * Compilacion sugerida:
 * @code
 * gcc -std=c17 -Wall -Wextra -pedantic -c tad_ordenamiento.c
 * @endcode
 *
 * @author Francisco Alejandro Medina Aguirre
 * @date 2026
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdint.h>
#include "tad_ordenamiento.h"


/**
 * @brief Intercambia el contenido de dos variables enteras.
 *
 * @param a Puntero al primer entero.
 * @param b Puntero al segundo entero.
 */
static void intercambiar(int *a, int *b) {
	int temporal;
	if (a == NULL || b == NULL) return;
	temporal = *a;
	*a = *b;
	*b = temporal;
}

/**
 * @brief Verifica si un arreglo puede procesarse.
 *
 * @param arreglo Arreglo de enteros.
 * @param n Número de elementos del arreglo.
 * @return 1 si el arreglo es válido; 0 en caso contrario.
 */
static int arreglo_valido(const int arreglo[], size_t n) {valid_active=1;emit("valid_entry",-1,-1);
	int observed=cond("valid_ptr",arreglo != NULL) && cond("valid_n",n > 0);valid_active=0;emit("valid_return",-1,observed);return observed;
}

/**
 * @brief Imprime un arreglo de enteros en una línea.
 *
 * @param arreglo Arreglo de enteros.
 * @param n Número de elementos del arreglo.
 */
void imprimir_arreglo(const int arreglo[], size_t n) {
	size_t i;
	if (!arreglo_valido(arreglo, n)) { printf("[]\n"); return; }
	printf("[");
	for (i = 0; i < n; ++i) {
		printf("%d", arreglo[i]);
		if (i + 1 < n) printf(", ");
	}
	printf("]\n");
}

/**
 * @brief Copia los elementos de un arreglo origen hacia un arreglo destino.
 *
 * @param destino Arreglo destino.
 * @param origen Arreglo origen.
 * @param n Número de elementos a copiar.
 * @return ORDENAMIENTO_OK si la copia fue correcta; ORDENAMIENTO_ERROR en caso contrario.
 */
int copiar_arreglo(int destino[], const int origen[], size_t n) {
	if (destino == NULL || origen == NULL || n == 0) return ORDENAMIENTO_ERROR;
	memcpy(destino, origen, n * sizeof(int));
	return ORDENAMIENTO_OK;
}

/**
 * @brief Ordena un arreglo usando el método de intercambio directo.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @note Tiempo O(n^2), memoria O(1); no estable por intercambios no adyacentes.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
void ordenar_intercambio(int arreglo[], size_t n) {
	size_t i, j;
	if (!arreglo_valido(arreglo, n)) return;
	for (i = 0; i + 1 < n; ++i)
		for (j = i + 1; j < n; ++j)
			if (arreglo[i] > arreglo[j]) intercambiar(&arreglo[i], &arreglo[j]);
}

/**
 * @brief Ordena un arreglo usando selección directa.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @note Tiempo O(n^2), memoria O(1); no estable por intercambio con el minimo distante.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
void ordenar_seleccion(int arreglo[], size_t n) {
	size_t i, j, indice_menor;
	if (!arreglo_valido(arreglo, n)) return;
	for (i = 0; i + 1 < n; ++i) {
		indice_menor = i;
		for (j = i + 1; j < n; ++j)
			if (arreglo[j] < arreglo[indice_menor]) indice_menor = j;
		if (indice_menor != i) intercambiar(&arreglo[i], &arreglo[indice_menor]);
	}
}

/**
 * @brief Ordena un arreglo usando inserción directa.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @note Mejor O(n), peor O(n^2), memoria O(1); estable por desplazar solo valores estrictamente mayores.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
void ordenar_insercion(int arreglo[], size_t n) {
	size_t i;
	if (!arreglo_valido(arreglo, n)) return;
	for (i = 1; i < n; ++i) {
		int clave = arreglo[i];
		size_t j = i;
		while (j > 0 && arreglo[j - 1] > clave) {
			arreglo[j] = arreglo[j - 1];
			--j;
		}
		arreglo[j] = clave;
	}
}

/**
 * @brief Ordena un arreglo usando burbuja mejorada.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @note Mejor O(n), peor O(n^2), memoria O(1); estable por intercambiar vecinos solo si son estrictamente mayores.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
void ordenar_burbuja(int arreglo[], size_t n) {
	size_t pasada, j;
	int hubo_intercambio;
	if (!arreglo_valido(arreglo, n)) return;
	for (pasada = 0; pasada + 1 < n; ++pasada) {
		hubo_intercambio = 0;
		for (j = 0; j + 1 < n - pasada; ++j) {
			if (arreglo[j] > arreglo[j + 1]) {
				intercambiar(&arreglo[j], &arreglo[j + 1]);
				hubo_intercambio = 1;
			}
		}
		if (!hubo_intercambio) break;
	}
}

/**
 * @brief Ordena un arreglo usando Shell Sort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @note Gaps n/2, n/4, ...; peor O(n^2), memoria O(1); no estable.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
void ordenar_shell(int arreglo[], size_t n) {
	size_t intervalo;
	if (!arreglo_valido(arreglo, n)) return;
	for (intervalo = n / 2; intervalo > 0; intervalo /= 2) {
		size_t i;
		for (i = intervalo; i < n; ++i) {
			int temporal = arreglo[i];
			size_t j = i;
			while (j >= intervalo && arreglo[j - intervalo] > temporal) {
				arreglo[j] = arreglo[j - intervalo];
				j -= intervalo;
			}
			arreglo[j] = temporal;
		}
	}
}

/**
 * @brief Particiona un arreglo para QuickSort usando pivote central (función auxiliar).
 *
 * @param arreglo Arreglo de enteros.
 * @param primero Índice inicial.
 * @param ultimo Índice final.
 */
static void quicksort_recursivo(int arreglo[], int primero, int ultimo) {
	int i = primero, j = ultimo, pivote = arreglo[(primero + ultimo) / 2];
	while (i <= j) {
		while (arreglo[i] < pivote) ++i;
		while (arreglo[j] > pivote) --j;
		if (i <= j) {
			intercambiar(&arreglo[i], &arreglo[j]);
			++i; --j;
		}
	}
	if (primero < j) quicksort_recursivo(arreglo, primero, j);
	if (i < ultimo) quicksort_recursivo(arreglo, i, ultimo);
}

/**
 * @brief Ordena un arreglo usando QuickSort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @note Promedio O(n log n), peor O(n^2); pila O(log n) promedio, O(n) peor; no estable. n debe permitir indices int y suma de extremos int.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
void ordenar_quicksort(int arreglo[], size_t n) {
	if (!arreglo_valido(arreglo, n)) return;
	quicksort_recursivo(arreglo, 0, (int)n - 1);
}

/**
 * @brief Mezcla dos subarreglos ordenados dentro del arreglo principal (función auxiliar para MergeSort).
 *
 * @param arreglo Arreglo de enteros.
 * @param auxiliar Arreglo auxiliar.
 * @param izquierda Índice inicial.
 * @param medio Índice medio.
 * @param derecha Índice final.
 */
static void mezclar(int arreglo[], int auxiliar[], size_t izquierda, size_t medio, size_t derecha) {
	size_t i = izquierda, j = medio + 1, k = izquierda;
	while (i <= medio && j <= derecha) {
		if (arreglo[i] <= arreglo[j]) auxiliar[k++] = arreglo[i++];
		else auxiliar[k++] = arreglo[j++];
	}
	while (i <= medio) auxiliar[k++] = arreglo[i++];
	while (j <= derecha) auxiliar[k++] = arreglo[j++];
	for (i = izquierda; i <= derecha; ++i) arreglo[i] = auxiliar[i];
}

/**
 * @brief Función recursiva auxiliar de MergeSort.
 *
 * @param arreglo Arreglo de enteros.
 * @param auxiliar Arreglo auxiliar.
 * @param izquierda Índice inicial.
 * @param derecha Índice final.
 */
static void mergesort_recursivo(int arreglo[], int auxiliar[], size_t izquierda, size_t derecha) {
	if (izquierda >= derecha) return;
	size_t medio = izquierda + (derecha - izquierda) / 2;
	mergesort_recursivo(arreglo, auxiliar, izquierda, medio);
	mergesort_recursivo(arreglo, auxiliar, medio + 1, derecha);
	mezclar(arreglo, auxiliar, izquierda, medio, derecha);
}

/**
 * @brief Ordena un arreglo usando MergeSort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0 o fallo de memoria.
 * @note Tiempo O(n log n), auxiliar O(n), pila O(log n); estable porque la mezcla toma primero el lado izquierdo en igualdad.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
int ordenar_mergesort(int arreglo[], size_t n) {
	int *auxiliar;
	if (!arreglo_valido(arreglo, n)) return ORDENAMIENTO_ERROR;
	auxiliar = (int *)malloc(n * sizeof(int));
	if (auxiliar == NULL) return ORDENAMIENTO_ERROR;
	mergesort_recursivo(arreglo, auxiliar, 0, n - 1);
	free(auxiliar);
	return ORDENAMIENTO_OK;
}

/**
 * @brief Restaura la propiedad de montículo máximo desde un índice dado (función auxiliar para HeapSort).
 *
 * @param arreglo Arreglo de enteros.
 * @param n Tamaño lógico del montículo.
 * @param raiz Índice de la raíz del submontículo.
 */
static void heapify(int arreglo[], size_t n, size_t raiz) {
	size_t mayor = raiz, izquierdo = 2 * raiz + 1, derecho = 2 * raiz + 2;
	if (izquierdo < n && arreglo[izquierdo] > arreglo[mayor]) mayor = izquierdo;
	if (derecho < n && arreglo[derecho] > arreglo[mayor]) mayor = derecho;
	if (mayor != raiz) {
		intercambiar(&arreglo[raiz], &arreglo[mayor]);
		heapify(arreglo, n, mayor);
	}
}

/**
 * @brief Ordena un arreglo usando HeapSort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @note Tiempo O(n log n), sin arreglo auxiliar; heapify recursivo usa pila O(log n), no espacio total O(1); no estable.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
void ordenar_heapsort(int arreglo[], size_t n) {
	size_t i;
	if (!arreglo_valido(arreglo, n)) return;
	for (i = n / 2; i > 0; --i) heapify(arreglo, n, i - 1);
	for (i = n; i > 1; --i) {
		intercambiar(&arreglo[0], &arreglo[i - 1]);
		heapify(arreglo, i - 1, 0);
	}
}

/**
 * @brief Obtiene el menor y mayor valor de un arreglo (función auxiliar).
 *
 * @param arreglo Arreglo de enteros.
 * @param n Número de elementos.
 * @param minimo Dirección donde se almacena el mínimo.
 * @param maximo Dirección donde se almacena el máximo.
 * @return ORDENAMIENTO_OK si se calcularon los valores; ORDENAMIENTO_ERROR en caso contrario.
 */
static int obtener_minimo_maximo(const int arreglo[], size_t n, int *minimo, int *maximo) {
	size_t i;
	if (!arreglo_valido(arreglo, n) || minimo == NULL || maximo == NULL) return ORDENAMIENTO_ERROR;
	*minimo = arreglo[0]; *maximo = arreglo[0];
	for (i = 1; i < n; ++i) {
		if (arreglo[i] < *minimo) *minimo = arreglo[i];
		if (arreglo[i] > *maximo) *maximo = arreglo[i];
	}
	return ORDENAMIENTO_OK;
}

/**
 * @brief Ordena un arreglo usando Counting Sort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0, rango mayor que ORDENAMIENTO_RANGO_MAX, tamaño no representable o fallo de memoria.
 * @note Tiempo O(n+k), memoria O(k), k=max-min+1 <= ORDENAMIENTO_RANGO_MAX; reconstruye enteros por frecuencia, sin preservar identidad de registros iguales.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
int ordenar_counting_sort(int arreglo[], size_t n) {
	int minimo, maximo; size_t rango, i, indice; int *conteo;
	if (!arreglo_valido(arreglo, n)) return ORDENAMIENTO_ERROR;
	if (!obtener_minimo_maximo(arreglo, n, &minimo, &maximo)) return ORDENAMIENTO_ERROR;
	rango = (size_t)((long long)maximo - (long long)minimo + 1LL);
	if (rango > ORDENAMIENTO_RANGO_MAX || rango > SIZE_MAX / sizeof(int)) return ORDENAMIENTO_ERROR;
	conteo = (int *)calloc(rango, sizeof(int));
	if (conteo == NULL) return ORDENAMIENTO_ERROR;
	for (i = 0; i < n; ++i) ++conteo[arreglo[i] - minimo];
	indice = 0;
	for (i = 0; i < rango; ++i)
		while (conteo[i] > 0) { arreglo[indice++] = (int)i + minimo; --conteo[i]; }
	free(conteo);
	return ORDENAMIENTO_OK;
}

/**
 * @brief Ordena delegando en Counting Sort; conserva sus límites de rango y códigos de error.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0, rango mayor que ORDENAMIENTO_RANGO_MAX, tamaño no representable o fallo de memoria.
 * @note Delegacion exacta a Counting Sort: O(n+k) tiempo, O(k) memoria y mismo limite; no es una implementacion independiente de buckets.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
int ordenar_binsort(int arreglo[], size_t n) {
	return ordenar_counting_sort(arreglo, n);
}

/**
 * @brief Ordena por conteo según un dígito decimal específico para Radix Sort (función auxiliar).
 *
 * @param arreglo Arreglo de enteros no negativos.
 * @param n Número de elementos.
 * @param exp Potencia de 10 que representa el dígito a procesar.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR si falló memoria.
 */
static int counting_por_digito(uint32_t arreglo[], size_t n, uint32_t exp) {_Static_assert(_Generic(arreglo,uint32_t*:1,default:0),"helper uint32 pointer");_Static_assert(_Generic(n,size_t:1,default:0),"helper size_t");_Static_assert(_Generic(exp,uint32_t:1,default:0),"helper uint32 exp");helper_active=1;obs_work=arreglo;work_n=n;obs_exp=exp;obs_counts=NULL;have_di=have_value=have_digit=0;emit("digit_entry",-1,-1);
	size_t conteo[10] = {0}; uint32_t *salida; size_t i;_Static_assert(_Generic(&conteo,size_t(*)[10]:1,default:0),"counts size_t10");_Static_assert(_Generic(salida,uint32_t*:1,default:0),"output uint32 pointer");_Static_assert(_Generic(i,size_t:1,default:0),"helper index size_t");obs_counts=conteo;helper_declared=1;output_status=1;memset(output_mask,0,sizeof(output_mask));emit("digit_declare",-1,-1);
	salida = (uint32_t *)malloc(n * sizeof(uint32_t));obs_out=salida;output_status=salida?3:2;if(salida)assert(is_live(salida));emit("digit_allocate",-1,-1);
	if(cond("digit_allocation_guard",salida==NULL))DIG_RETURN(ORDENAMIENTO_ERROR);
	for(i=0,di=i,have_di=1,emit("digit_fill_init",-1,-1);cond("digit_fill_test",i<n);++i,di=i,emit("digit_fill_increment",-1,-1)){++conteo[(arreglo[i]/exp)%10];count_writes++;emit("digit_frequency_write",-1,-1);}
	for(i=1,di=i,emit("digit_prefix_init",-1,-1);cond("digit_prefix_test",i<10);++i,di=i,emit("digit_prefix_increment",-1,-1)){conteo[i]+=conteo[i-1];count_writes++;emit("digit_prefix_write",-1,-1);}
	for(i=n,di=i,emit("digit_reverse_init",-1,-1);cond("digit_reverse_test",i>0);--i,di=i,have_value=have_digit=0,emit("digit_reverse_decrement",-1,-1)){
		uint32_t valor=arreglo[i-1];_Static_assert(_Generic(valor,uint32_t:1,default:0),"value uint32");obs_value=valor;have_value=1;have_digit=0;emit("digit_value_read",-1,-1);
		uint32_t digito=(valor/exp)%10U;_Static_assert(_Generic(digito,uint32_t:1,default:0),"digit uint32");obs_digit=digito;have_digit=1;emit("digit_select",-1,-1);
		salida[conteo[digito]-1]=valor;output_mask[conteo[digito]-1]=1;output_writes++;emit("digit_output_write",-1,-1);
		--conteo[digito];count_writes++;emit("digit_frequency_decrement",-1,-1);
	}
	for(i=0,di=i,emit("digit_copy_init",-1,-1);cond("digit_copy_test",i<n);++i,di=i,emit("digit_copy_increment",-1,-1)){arreglo[i]=salida[i];work_writes++;emit("digit_work_copy",-1,-1);}
	free(salida);emit("digit_free",-1,-1);
	DIG_RETURN(ORDENAMIENTO_OK);
}

/**
 * @brief Ordena un arreglo usando Radix Sort LSD en base 10.
 *
 * Esta implementación acepta enteros negativos separándolos de los no negativos,
 * ordenando magnitudes y recombinando al final.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0 o fallo de memoria.
 * @note Base 10, O(d(n+10)) tiempo y O(n+10) memoria. Conteo por digito estable; la inversion final del grupo negativo no garantiza estabilidad de registros negativos iguales. INT_MIN usa magnitud uint32_t y recomposicion protegida.
 * @note Arreglo NULL o n==0 no se procesa; funciones int retornan ERROR y funciones void no comunican estado.
 */
int ordenar_radixsort(int arreglo[], size_t n) {_Static_assert(_Generic(arreglo,int*:1,default:0),"wrapper int pointer");_Static_assert(_Generic(n,size_t:1,default:0),"wrapper size_t");wrapper_active=1;emit("radix_entry",-1,-1);
	uint32_t *negativos, *positivos; size_t cant_negativos=0,cant_positivos=0,i,indice;_Static_assert(_Generic(negativos,uint32_t*:1,default:0),"negative uint32 pointer");_Static_assert(_Generic(positivos,uint32_t*:1,default:0),"positive uint32 pointer");_Static_assert(_Generic(i,size_t:1,default:0),"wrapper index size_t");wrapper_declared=1;negative_status=positive_status=1;emit("radix_declare",-1,-1);
	if(cond("radix_invalid_guard",!arreglo_valido(arreglo,n)))RAD_RETURN(ORDENAMIENTO_ERROR);
	negativos=(uint32_t*)malloc(n*sizeof(uint32_t));obs_neg=negativos;negative_status=negativos?3:2;emit("negative_allocate",-1,-1);
	positivos=(uint32_t*)malloc(n*sizeof(uint32_t));obs_pos=positivos;positive_status=positivos?3:2;emit("positive_allocate",-1,-1);
	if(cond("split_reserve_guard",cond("negative_null",negativos==NULL)||cond("positive_null",positivos==NULL))){free(negativos);emit("negative_free",-1,-1);free(positivos);emit("positive_free",-1,-1);RAD_RETURN(ORDENAMIENTO_ERROR);}
	for(i=0,wi=i,have_wi=1,emit("split_init",-1,-1);cond("split_test",i<n);++i,wi=i,emit("split_increment",-1,-1)){
		if(cond("sign_test",arreglo[i]<0)){negativos[cant_negativos++]=0U-(uint32_t)arreglo[i];ng=cant_negativos;work_writes++;emit("negative_write",-1,-1);}else{positivos[cant_positivos++]=(uint32_t)arreglo[i];pg=cant_positivos;work_writes++;emit("positive_write",-1,-1);}
	}
	if(cond("negative_group_guard",cant_negativos>0)){
		uint32_t maximo=negativos[0],exp=1U;_Static_assert(_Generic(maximo,uint32_t:1,default:0),"maximum uint32");block_kind=1;obs_max=maximo;obs_exp=exp;have_max=have_exp=1;emit("negative_max_exp_init",-1,-1);
		for(i=1,wi=i,emit("negative_scan_init",-1,-1);cond("negative_scan_test",i<cant_negativos);++i,wi=i,emit("negative_scan_increment",-1,-1))if(cond("negative_max_compare",negativos[i]>maximo)){maximo=negativos[i];obs_max=maximo;emit("negative_max_assign",-1,-1);}
		for (;;) {
			emit("negative_digit_call",-1,-1);if(cond("negative_digit_status",!counting_por_digito(negativos,cant_negativos,exp))){free(negativos);emit("negative_free",-1,-1);free(positivos);emit("positive_free",-1,-1);RAD_RETURN(ORDENAMIENTO_ERROR);}
			if(cond("negative_exp_guard",exp>maximo/10U)){emit("negative_break",-1,-1);break;}
			exp*=10U;obs_exp=exp;emit("negative_exp_multiply",-1,-1);
		}
	}
	block_kind=0;have_max=have_exp=0;emit("negative_block_exit",-1,-1);if(cond("positive_group_guard",cant_positivos>0)){
		uint32_t maximo=positivos[0],exp=1U;block_kind=2;obs_max=maximo;obs_exp=exp;have_max=have_exp=1;emit("positive_max_exp_init",-1,-1);
		for(i=1,wi=i,emit("positive_scan_init",-1,-1);cond("positive_scan_test",i<cant_positivos);++i,wi=i,emit("positive_scan_increment",-1,-1))if(cond("positive_max_compare",positivos[i]>maximo)){maximo=positivos[i];obs_max=maximo;emit("positive_max_assign",-1,-1);}
		if(cond("positive_nonzero_guard",maximo>0U))for(;;){
			emit("positive_digit_call",-1,-1);if(cond("positive_digit_status",!counting_por_digito(positivos,cant_positivos,exp))){free(negativos);emit("negative_free",-1,-1);free(positivos);emit("positive_free",-1,-1);RAD_RETURN(ORDENAMIENTO_ERROR);}
			if(cond("positive_exp_guard",exp>maximo/10U)){emit("positive_break",-1,-1);break;}
			exp*=10U;obs_exp=exp;emit("positive_exp_multiply",-1,-1);
		}
	}
	block_kind=0;have_max=have_exp=0;emit("positive_block_exit",-1,-1);indice=0;have_index=1;output_index=indice;emit("caller_index_init",-1,-1);
	for(i=cant_negativos,wi=i,emit("negative_join_init",-1,-1);cond("negative_join_test",i>0);--i,wi=i,have_magnitude=0,emit("negative_join_decrement",-1,-1)){
		uint32_t magnitud=negativos[i-1];_Static_assert(_Generic(magnitud,uint32_t:1,default:0),"magnitude uint32");obs_magnitude=magnitud;have_magnitude=1;emit("negative_magnitude_read",-1,-1);
		arreglo[indice++]=cond("INT_MIN_magnitude_guard",magnitud==(uint32_t)INT_MAX+1U)?INT_MIN:-(int)magnitud;output_index=indice;caller_writes++;emit("negative_caller_write",-1,-1);
	}
	for(i=0,wi=i,emit("positive_join_init",-1,-1);cond("positive_join_test",i<cant_positivos);++i,wi=i,emit("positive_join_increment",-1,-1)){arreglo[indice++]=(int)positivos[i];output_index=indice;caller_writes++;emit("positive_caller_write",-1,-1);}
	free(negativos);emit("negative_free",-1,-1);free(positivos);emit("positive_free",-1,-1);
	RAD_RETURN(ORDENAMIENTO_OK);
}

/**
 * @brief Ejecuta y muestra un algoritmo de ordenamiento sobre una copia del arreglo base.
 *
 * @param nombre Nombre descriptivo del algoritmo.
 * @param ordenar Función de ordenamiento que no retorna estado.
 * @param base Arreglo base.
 * @param n Número de elementos.
 */
void probar_algoritmo_void(const char *nombre, void (*ordenar)(int[], size_t), const int base[], size_t n) {
	int *copia;
	if (nombre == NULL || ordenar == NULL || !arreglo_valido(base, n)) return;
	copia = (int *)malloc(n * sizeof(int));
	if (copia == NULL) { printf("%s: error de memoria\n", nombre); return; }
	copiar_arreglo(copia, base, n);
	ordenar(copia, n);
	printf("%-18s: ", nombre);
	imprimir_arreglo(copia, n);
	free(copia);
}

/**
 * @brief Ejecuta y muestra un algoritmo de ordenamiento que retorna estado.
 *
 * @param nombre Nombre descriptivo del algoritmo.
 * @param ordenar Función de ordenamiento que retorna ORDENAMIENTO_OK o ORDENAMIENTO_ERROR.
 * @param base Arreglo base.
 * @param n Número de elementos.
 */
void probar_algoritmo_int(const char *nombre, int (*ordenar)(int[], size_t), const int base[], size_t n) {
	int *copia;
	if (nombre == NULL || ordenar == NULL || !arreglo_valido(base, n)) return;
	copia = (int *)malloc(n * sizeof(int));
	if (copia == NULL) { printf("%s: error de memoria\n", nombre); return; }
	copiar_arreglo(copia, base, n);
	if (!ordenar(copia, n)) { printf("%s: error al ordenar\n", nombre); free(copia); return; }
	printf("%-18s: ", nombre);
	imprimir_arreglo(copia, n);
	free(copia);
}

#undef malloc
#undef free
static void setup(int*a,size_t n,int id,int fault){block_kind=have_index=0;wrapper_declared=helper_declared=negative_status=positive_status=output_status=have_magnitude=0;root=a;root_n=n;case_id=id;wrapper_active=helper_active=valid_active=have_wi=have_di=have_max=have_exp=have_value=have_digit=0;obs_neg=obs_pos=obs_out=obs_work=NULL;obs_counts=NULL;ng=pg=wi=di=output_index=0;used=allocs=frees=attempts=max_comp=sign_tests=work_writes=count_writes=output_writes=caller_writes=0;fail_at=fault;memset(live,0,sizeof(live));emit("initial",-1,-1);}
static void outcome(const char*name,int status){assert(allocs==frees);assert(wrapper_active==0);printf("{\"outcome\":\"%s\",\"case\":%d,\"status\":%d,\"array\":[",name,case_id,status);for(size_t i=0;i<root_n;i++){if(i)printf(",");printf("%d",root[i]);}printf("],\"allocations\":%d,\"frees\":%d,\"live\":%d,\"attempts\":%d}\n",allocs,frees,allocs-frees,attempts);}
int main(void){_Static_assert(sizeof(int)==4,"int32");_Static_assert(sizeof(size_t)==8,"size_t64");{int a[]={7};setup(a,sizeof(a)/sizeof(a[0]),0,0);int s=ordenar_radixsort(a,root_n);outcome("single",s);}{int a[]={170,45,75,90};setup(a,sizeof(a)/sizeof(a[0]),1,0);int s=ordenar_radixsort(a,root_n);outcome("normal",s);}{int a[]={-3,-5,-3,-4};setup(a,sizeof(a)/sizeof(a[0]),2,0);int s=ordenar_radixsort(a,root_n);outcome("negative_duplicates",s);}{int a[]={170,45,75,-90,802,24,2,66};setup(a,sizeof(a)/sizeof(a[0]),3,0);int s=ordenar_radixsort(a,root_n);outcome("mixed_outside_four",s);}{int a[]={0,0,0};setup(a,sizeof(a)/sizeof(a[0]),4,0);int s=ordenar_radixsort(a,root_n);outcome("zeros",s);}{int a[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};setup(a,sizeof(a)/sizeof(a[0]),5,0);int s=ordenar_radixsort(a,root_n);outcome("eighty_zeros",s);}{int a[]={2147483647,-2147483648,0,-1};setup(a,sizeof(a)/sizeof(a[0]),6,0);int s=ordenar_radixsort(a,root_n);outcome("int32_extremes",s);}{int a[]={-1,0,1};setup(a,sizeof(a)/sizeof(a[0]),7,0);int s=ordenar_radixsort(a,root_n);outcome("sign_boundary",s);}{int a[]={-5,2};setup(a,2,20,1);int s=ordenar_radixsort(a,2);outcome("fault_1",s);}{int a[]={-5,2};setup(a,2,21,2);int s=ordenar_radixsort(a,2);outcome("fault_2",s);}{int a[]={-5,2};setup(a,2,22,3);int s=ordenar_radixsort(a,2);outcome("fault_3",s);}{int a[]={-5,2};setup(a,2,23,4);int s=ordenar_radixsort(a,2);outcome("fault_4",s);}{int a[]={5};setup(a,0,30,0);int s=ordenar_radixsort(a,0);assert(a[0]==5);outcome("empty",s);}{setup(NULL,0,31,0);int s=ordenar_radixsort(NULL,2);outcome("null",s);}{int a[]={-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647,-2147483648,2147483647};setup(a,80,40,0);int s=ordenar_radixsort(a,80);outcome("maximum",s);}{int a[]={45,75,90,170};setup(a,sizeof(a)/sizeof(a[0]),50,0);int s=ordenar_radixsort(a,root_n);outcome("normal_second",s);}{int a[]={-5,-4,-3,-3};setup(a,sizeof(a)/sizeof(a[0]),51,0);int s=ordenar_radixsort(a,root_n);outcome("negative_second",s);}{int a[]={-2147483648,-1,0,2147483647};setup(a,sizeof(a)/sizeof(a[0]),52,0);int s=ordenar_radixsort(a,root_n);outcome("extremes_second",s);}return 0;}