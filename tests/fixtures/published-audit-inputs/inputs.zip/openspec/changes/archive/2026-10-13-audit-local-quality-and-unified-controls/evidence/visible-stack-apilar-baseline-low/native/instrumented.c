/**
 * @file tad_pila.c
 * @brief Implementación del TAD Pila LIFO.
 */

#include <stdio.h>
#include <stdlib.h>

/**
 * @brief Nodo de una pila enlazada.
 */
struct NodoPila {
    int nro; /**< Dato entero almacenado. */
    struct NodoPila *sgte; /**< Enlace al siguiente nodo. */
};

/** @brief Puntero a nodo o cima de pila; NULL representa pila vacía. */
typedef struct NodoPila* ptrPila;


//---------------------------------------------------------------
/*
 * @brief Apila un nuevo valor en la pila.
 * @param p Puntero a la pila.
 * @param valor Valor entero que se apilará.
 */
/**
 * @brief Inserta un elemento en la cima de la pila.
 * @param[in,out] p Puntero a la pila.
 * @param[in] valor Valor a apilar.
 */
void pila_apilar(ptrPila *p, int valor) {
    qa_event("entry",p,-1);
    if (qa_guard("root_guard",p,p == NULL)) {
        qa_printf("Error: pila no inicializada.\n");qa_event("root_error_printf",p,-1);
        qa_event("return",p,-1);return;
    }

    ptrPila aux = (ptrPila) malloc(sizeof(struct NodoPila));
    _Static_assert(_Generic(aux,ptrPila:1,default:0),"aux type");
    qa_capture(aux);qa_event("aux_allocated",p,-1);
    if (qa_guard("allocation_guard",p,aux == NULL)) {
        qa_printf("Error: No se pudo asignar memoria.\n");qa_event("allocation_error_printf",p,-1);
        qa_event("return",p,-1);return;
    }
    aux->nro = valor;qa_field(aux,1);qa_event("value_assigned",p,-1);
    aux->sgte = *p;qa_field(aux,2);qa_event("link_assigned",p,-1);
    *p = aux;qa_event("root_assigned",p,-1);
    qa_event("return",p,-1);
}


//---------------------------------------------------------------
/*
 * @brief Desapila y devuelve el valor en la cima de la pila.
 * @param p Puntero a la pila.
 * @return int Valor desapilado.
 */
/**
 * @brief Extrae el elemento en la cima de la pila.
 * @param[in,out] p Puntero a la pila.
 * @return Valor extraido, o -1 si no se puede extraer; -1 también puede ser un dato válido.
 */
int pila_desapilar(ptrPila *p) {
    if (p == NULL || *p == NULL) {
        printf("Pila vacía. No se puede desapilar.\n");
        return -1;  // Valor de error
    }

    ptrPila aux = *p;
    int num = aux->nro;
    *p = aux->sgte;
    free(aux);
    return num;
}

/**
 * @brief Consulta la cima sin modificar la pila.
 * @param p Pila a consultar; puede ser NULL.
 * @return Valor de la cima, o -1 si está vacía. El valor -1 también puede estar almacenado.
 */
int pila_cima(ptrPila p) {
    return p == NULL ? -1 : p->nro;
}


//---------------------------------------------------------------
/*
 * @brief Muestra todos los elementos de la pila.
 * @param p Pila a mostrar.
 */
/**
 * @brief Muestra el contenido de la pila en orden de cima a fondo.
 * @param[in] p Pila a mostrar.
 */
void pila_mostrar(ptrPila p) {
    ptrPila aux = p;
    if (aux == NULL) {
        printf("Pila vacia.\n");
        return;
    }

    while (aux != NULL) {
        printf("\t%d\n", aux->nro);
        aux = aux->sgte;
    }
}


//---------------------------------------------------------------
/*
 * @brief Elimina todos los elementos de la pila.
 * @param p Puntero a la pila.
 */
/**
 * @brief Libera todos los nodos de la pila.
 * @param[in,out] p Puntero a la pila.
 */
void pila_destruir(ptrPila *p) {
    ptrPila aux;
    if (p == NULL) {
        return;
    }

    while (*p != NULL) {
        aux = *p;
        *p = aux->sgte;
        free(aux);
    }
}
