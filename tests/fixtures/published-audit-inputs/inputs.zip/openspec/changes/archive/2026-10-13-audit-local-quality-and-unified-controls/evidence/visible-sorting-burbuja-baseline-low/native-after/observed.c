
#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#include <string.h>
static int *root,*pa,*pb,*pt,*pf;static size_t count,*pp,*pj,cp,cj;
static int has_p,has_j,has_t,has_flag,ct,cf,comparisons,swaps,moves,fixture;
static void emit(const char *token,const char *function,int condition){
 if(pp && has_p){cp=*pp;}if(pj && has_j){cj=*pj;}if(pt && has_t){ct=*pt;}if(pf && has_flag){cf=*pf;}
 printf("{\"case\":%d,\"event\":{\"token\":\"%s\",\"function\":",fixture,token);
 if(function){printf("\"%s\"",function);}else{printf("null");}
 printf(",\"pasada\":");if(has_p){printf("%zu",cp);}else{printf("null");}
 printf(",\"j\":");if(has_j){printf("%zu",cj);}else{printf("null");}
 printf(",\"hubo_intercambio\":");if(has_flag){printf("%d",cf);}else{printf("null");}
 printf(",\"temporal\":");if(pt && has_t){printf("%d",ct);}else{printf("null");}
 printf(",\"a\":");if(pa){printf("%td",pa-root);}else{printf("null");}
 printf(",\"b\":");if(pb){printf("%td",pb-root);}else{printf("null");}
 printf(",\"comparisons\":%d,\"swaps\":%d,\"moves\":%d},\"condition\":",comparisons,swaps,moves);
 if(condition<0){printf("null");}else{printf(condition?"true":"false");}
 printf(",\"array\":[");for(size_t k=0;k<count;k++){if(k){printf(",");}printf("%d",root[k]);}puts("]}");
}
static int cond(const char*t,const char*f,int r){if(!strcmp(t,"compare")){comparisons++;}emit(t,f,r);return r;}
static int checked(int r){emit("valid_return","arreglo_valido",-1);return cond("sort_guard","ordenar_burbuja",!r);}

static void intercambiar(int *a, int *b) {pa=a;pb=b;emit("swap_entry","intercambiar",-1);
	int temporal;pt=&temporal;has_t=0;emit("swap_declare","intercambiar",-1);
	if (cond("swap_guard","intercambiar",a==NULL || b==NULL)) return;
	temporal=*a;has_t=1;moves++;emit("swap_temp","intercambiar",-1);
	*a=*b;moves++;emit("swap_assign_a","intercambiar",-1);
	*b=temporal;moves++;swaps++;emit("swap_assign_b","intercambiar",-1);
}
static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry","arreglo_valido",-1);
	return cond("valid_ptr","arreglo_valido",arreglo!=NULL) && cond("valid_n","arreglo_valido",n>0);
}
void ordenar_burbuja(int arreglo[], size_t n) {emit("sort_entry","ordenar_burbuja",-1);
	size_t pasada,j;pp=&pasada;pj=&j;emit("sort_declare_indices","ordenar_burbuja",-1);
	int hubo_intercambio;pf=&hubo_intercambio;emit("sort_declare_flag","ordenar_burbuja",-1);
	emit("valid_call","ordenar_burbuja",-1);if(checked(arreglo_valido(arreglo,n))){pp=pj=NULL;pf=NULL;emit("guard_return","ordenar_burbuja",-1);return;}
	for(pasada=0,has_p=1,emit("outer_init","ordenar_burbuja",-1);cond("outer_test","ordenar_burbuja",pasada+1<n);++pasada,emit("outer_increment","ordenar_burbuja",-1)) {
		hubo_intercambio=0;has_flag=1;emit("flag_reset","ordenar_burbuja",-1);
		for(j=0,has_j=1,emit("inner_init","ordenar_burbuja",-1);cond("inner_test","ordenar_burbuja",j+1<n-pasada);++j,emit("inner_increment","ordenar_burbuja",-1)) {
			if(cond("compare","ordenar_burbuja",arreglo[j]>arreglo[j+1])) {
				emit("swap_call","ordenar_burbuja",-1);intercambiar(&arreglo[j],&arreglo[j+1]);pa=pb=pt=NULL;has_t=0;emit("swap_return","intercambiar",-1);emit("swap_resume","ordenar_burbuja",-1);
				hubo_intercambio=1;emit("flag_set","ordenar_burbuja",-1);
			}
		}
		if(cond("stop_test","ordenar_burbuja",!hubo_intercambio)){emit("early_break","ordenar_burbuja",-1);break;}
emit("outer_complete","ordenar_burbuja",-1);	}
pp=pj=NULL;pf=NULL;}

int main(void){
{int a[]={7};root=a;count=sizeof(a)/sizeof(a[0]);fixture=0;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(a,count);emit("sort_return","ordenar_burbuja",-1);}
{int a[]={1,2,3,4};root=a;count=sizeof(a)/sizeof(a[0]);fixture=1;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(a,count);emit("sort_return","ordenar_burbuja",-1);}
{int a[]={4,3,2,1};root=a;count=sizeof(a)/sizeof(a[0]);fixture=2;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(a,count);emit("sort_return","ordenar_burbuja",-1);}
{int a[]={2,2,2};root=a;count=sizeof(a)/sizeof(a[0]);fixture=3;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(a,count);emit("sort_return","ordenar_burbuja",-1);}
{int a[]={-3,0,-1,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=4;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(a,count);emit("sort_return","ordenar_burbuja",-1);}
{int a[]={2147483647,-2147483648,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=5;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(a,count);emit("sort_return","ordenar_burbuja",-1);}
{int a[]={2,1,3,4};root=a;count=sizeof(a)/sizeof(a[0]);fixture=6;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(a,count);emit("sort_return","ordenar_burbuja",-1);}
{int a=42;root=&a;count=0;fixture=7;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(&a,0);}
{root=NULL;count=0;fixture=8;has_p=has_j=has_t=has_flag=comparisons=swaps=moves=0;pp=pj=NULL;pa=pb=pt=pf=NULL;emit("initial",NULL,-1);ordenar_burbuja(NULL,1);}
return 0;}
