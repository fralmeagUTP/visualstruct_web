#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
static void *ptrs[4096];static int live[4096],total,allocs,frees;
static void *track(void*p){if(p){assert(total<4096);ptrs[total]=p;live[total++]=1;allocs++;}return p;}
void *owned_malloc(size_t n){return track(malloc(n));}
void *owned_calloc(size_t n,size_t z){return track(calloc(n,z));}
void owned_free(void*p){if(p){int found=0;for(int i=0;i<total;i++){if(live[i]&&ptrs[i]==p){live[i]=0;found=1;break;}}assert(found);frees++;}free(p);}
void ownership_done(void){for(int i=0;i<total;i++)assert(live[i]==0);assert(allocs==frees);printf("OWNERSHIP %d %d 0\n",allocs,frees);}
