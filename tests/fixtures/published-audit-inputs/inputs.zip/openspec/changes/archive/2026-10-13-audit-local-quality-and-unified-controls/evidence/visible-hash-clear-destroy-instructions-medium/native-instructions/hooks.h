#include "tad_tabla_hash.h"
void qa_event(const char*,TablaHash*,int,int);
int qa_guard(const char*,TablaHash*,int,int);
int qa_init(TablaHash*);
void qa_local(THNodo*,int);
void qa_slot(int);
void *qa_malloc(size_t);
void qa_free(void*);
