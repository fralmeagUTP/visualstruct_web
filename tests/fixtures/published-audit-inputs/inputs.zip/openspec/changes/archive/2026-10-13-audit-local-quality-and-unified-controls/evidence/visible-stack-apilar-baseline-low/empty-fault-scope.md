# Hueco de fallo con raíz válida vacía

Los cuatro mallocNULL iniciales ocurrieron después de dos pushes, con *p noNULL. Se agrega sólo un driverdisjunto que llama con p=&raíz y *p=NULL más mallocNULLsimulado;0alloc/free,8eventos/2conditions,sin leerfieldssininit. No repite8API/Cnormales ni guardNULL. Original13calls116/25 preservado; unión14calls124/27,5mallocfaults+1paramNULL.
