#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tad_tabla_hash.h"
_Static_assert(_Generic(&th_vaciar, void(*)(TablaHash*):1,default:0),"clear signature");
_Static_assert(_Generic(&th_destruir, void(*)(TablaHash*):1,default:0),"destroy signature");
static void*objects[512];static int alive[512],kind[512],used,allocs,frees,new_bucket;
static int recording,sample_id,cap0,array_alive,ptr_valid,slot_valid[64],actual_valid,actual_present,actual_key,saved_present,saved_key,has_actual,has_saved,count_pending,call_frees;
static TablaHash*root;
void *qa_malloc(size_t size){void*p=malloc(size);assert(p&&used<512);objects[used]=p;alive[used]=1;kind[used]=new_bucket?1:2;new_bucket=0;used++;allocs++;return p;}
void qa_free(void*p){if(!p)return;int found=-1;for(int j=0;j<used;j++)if(alive[j]&&objects[j]==p){found=j;break;}assert(found>=0);
 if(recording){call_frees++;if(kind[found]==1){ptr_valid=0;array_alive=0;for(int i=0;i<cap0;i++)slot_valid[i]=0;}
 else {assert(root&&ptr_valid&&array_alive);for(int i=0;i<cap0;i++)if(slot_valid[i]&&root->buckets[i]==p)slot_valid[i]=0;actual_valid=0;actual_present=0;count_pending=1;}}
 alive[found]=0;objects[found]=NULL;frees++;free(p);}
void qa_local(THNodo*p,int next){if(!recording)return;if(next){has_saved=1;saved_present=p!=NULL;saved_key=p?p->clave:0;}else {has_actual=1;actual_valid=1;actual_present=p!=NULL;actual_key=p?p->clave:0;}}
void qa_slot(int i){if(recording)slot_valid[i]=1;}
void qa_event(const char*event,TablaHash*t,int i,int cond){if(!recording)return;assert(t==root);
 if(!strcmp(event,"root_buckets_NULL"))ptr_valid=1;
 if(!strcmp(event,"iteration_exit"))has_saved=0;
 if(!strcmp(event,"bucket_body_exit"))has_actual=0;
 if(!strcmp(event,"clear_count_zero"))count_pending=0;
 printf("{\"sample\":%d,\"event\":\"%s\",\"condition\":%d,\"i\":%d,\"root_alive\":%d,\"capacity\":%d,\"size\":%d,\"array_alive\":%d,\"pointer_valid\":%d,\"pointer_NULL\":%d,\"count_pending\":%d,\"frees\":%d,\"has_actual\":%d,\"actual_valid\":%d,\"actual_present\":%d,\"actual_key\":%d,\"has_saved\":%d,\"saved_present\":%d,\"saved_key\":%d,\"slots\":[",sample_id,event,cond,i,t!=NULL,t?t->capacidad:0,t?t->cantidad:0,array_alive,ptr_valid,ptr_valid&&t?t->buckets==NULL:1,count_pending,call_frees,has_actual,actual_valid,actual_present,actual_key,has_saved,saved_present,saved_key);
 for(int j=0;j<cap0;j++){if(j)putchar(',');printf("{\"valid\":%d,\"key\":",slot_valid[j]);if(array_alive&&slot_valid[j]&&t->buckets[j])printf("%d",t->buckets[j]->clave);else fputs("null",stdout);putchar('}');}
 fputs("],\"live_keys\":[",stdout);int comma=0;for(int j=0;j<used;j++)if(alive[j]&&kind[j]==2){if(comma++)putchar(',');printf("%d",((THNodo*)objects[j])->clave);}puts("]}");}
int qa_guard(const char*e,TablaHash*t,int i,int value){qa_event(e,t,i,value);return value;}
int qa_init(TablaHash*t){qa_event("bucket_init",t,0,-1);return 0;}
static void sample(TablaHash*t,int op){root=t;cap0=t?t->capacidad:0;assert(cap0<64);array_alive=t&&t->buckets;ptr_valid=1;for(int i=0;i<cap0;i++)slot_valid[i]=1;has_actual=has_saved=actual_present=saved_present=count_pending=call_frees=0;actual_valid=1;recording=1;if(op)th_destruir(t);else th_vaciar(t);recording=0;sample_id++;}
int main(void){{TablaHash t={0};new_bucket=1;th_inicializar(&t,3);sample(&t,0);sample(&t,0);th_destruir(&t);}{TablaHash t={0};new_bucket=1;th_inicializar(&t,3);sample(&t,1);sample(&t,1);th_destruir(&t);}{TablaHash t={0};new_bucket=1;th_inicializar(&t,3);assert(th_insertar(&t,1,10));assert(th_insertar(&t,4,40));assert(th_insertar(&t,7,70));sample(&t,0);sample(&t,0);th_destruir(&t);}{TablaHash t={0};new_bucket=1;th_inicializar(&t,3);assert(th_insertar(&t,1,10));assert(th_insertar(&t,4,40));assert(th_insertar(&t,7,70));sample(&t,1);sample(&t,1);th_destruir(&t);}{TablaHash t={0};new_bucket=1;th_inicializar(&t,7);assert(th_insertar(&t,-7,70));assert(th_insertar(&t,7,70));assert(th_insertar(&t,14,-14));assert(th_insertar(&t,2,2));sample(&t,0);sample(&t,0);th_destruir(&t);}{TablaHash t={0};new_bucket=1;th_inicializar(&t,7);assert(th_insertar(&t,-7,70));assert(th_insertar(&t,7,70));assert(th_insertar(&t,14,-14));assert(th_insertar(&t,2,2));sample(&t,1);sample(&t,1);th_destruir(&t);}{TablaHash t={0};new_bucket=1;th_inicializar(&t,3);assert(th_insertar(&t,1,1));assert(th_insertar(&t,4,4));th_destruir(&t);sample(&t,0);sample(&t,0);th_destruir(&t);}{TablaHash t={0};new_bucket=1;th_inicializar(&t,3);assert(th_insertar(&t,1,1));assert(th_insertar(&t,4,4));th_destruir(&t);sample(&t,1);sample(&t,1);th_destruir(&t);} {TablaHash t={0};new_bucket=1;th_inicializar(&t,3);assert(th_insertar(&t,1,10));assert(th_insertar(&t,4,40));assert(th_insertar(&t,7,70));sample(&t,0);assert(th_insertar(&t,8,80));sample(&t,0);th_destruir(&t);} {TablaHash t={0};new_bucket=1;th_inicializar(&t,3);assert(th_insertar(&t,1,10));assert(th_insertar(&t,4,40));assert(th_insertar(&t,7,70));sample(&t,1);new_bucket=1;th_inicializar(&t,5);assert(th_insertar(&t,8,80));sample(&t,1);th_destruir(&t);}sample(NULL,0);sample(NULL,1);{TablaHash t={0};sample(&t,0);sample(&t,1);}assert(allocs==frees);for(int j=0;j<used;j++)assert(!alive[j]);return 0;}