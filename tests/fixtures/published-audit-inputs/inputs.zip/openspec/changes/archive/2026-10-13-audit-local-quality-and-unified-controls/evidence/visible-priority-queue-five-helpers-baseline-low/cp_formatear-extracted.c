/**
 * @brief Genera una representación textual de la cola de prioridad.
 *
 * @details
 * Escribe en @p destino una cadena con el formato:
 * @code
 * frente -> v1(p=p1) | v2(p=p2) | ... | vN(p=pN)
 * @endcode
 * donde @c vK es el valor y @c pK la prioridad del k-ésimo elemento
 * en orden de inserción. Si la cola está vacía escribe
 * @c "Cola de prioridad vacia".
 * La cadena siempre queda terminada en @c '\0' si @p capacidad >= 1.
 *
 * @param[in]  cola      Puntero constante a la ColaPrioridad.
 * @param[out] destino   Buffer donde se escribirá la cadena resultante.
 * @param[in]  capacidad Tamaño en bytes del buffer @p destino.
 *
 * @pre  @p destino debe apuntar a un buffer de al menos @p capacidad bytes.
 * @post @p destino contiene una cadena terminada en @c '\0'.
 * @note Si el contenido supera @p capacidad se trunca de forma segura.
 * @note Si @p destino es NULL o @p capacidad es 0, no hace nada.
 * @note Complejidad temporal: O(n).
 */
void cp_formatear(const ColaPrioridad *cola, char *destino, size_t capacidad) {
    CPNodo *aux;
    size_t usado = 0;

    if (destino == NULL || capacidad == 0) {
        return;
    }

    destino[0] = '\0';

    if (cola == NULL || cola->delante == NULL) {
        snprintf(destino, capacidad, "Cola de prioridad vacia");
        return;
    }

    cp_append_text(destino, capacidad, &usado, "frente -> ");

    aux = cola->delante;
    while (aux != NULL && usado < capacidad) {
        cp_append_text(destino, capacidad, &usado, "%d(p=%d)", aux->valor, aux->prioridad);
        aux = aux->sgte;
        if (aux != NULL && usado < capacidad) {
            cp_append_text(destino, capacidad, &usado, " | ");
        }
    }
}