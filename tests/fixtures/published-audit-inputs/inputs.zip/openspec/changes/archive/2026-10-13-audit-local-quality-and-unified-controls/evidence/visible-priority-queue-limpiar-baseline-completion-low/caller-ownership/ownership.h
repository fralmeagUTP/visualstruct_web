#include <stddef.h>
void*audit_malloc(size_t);
void audit_free(void*);
