#include <stdio.h>
#include "tad_cola_prioridad.h"
/** @file main.c @brief Reproduce el historial de Prioridad y libera su propiedad. */
/** @brief Ejecuta el historial y comprueba cada reserva antes de anunciar éxito. @return 0 en éxito, 1 ante reserva fallida o entero fuera de int C. */
int main(void) {
    ColaPrioridad cp;
    cp_inicializar(&cp);
    // Historial de ejecucion del usuario
    if (!cp_encolar(&cp, 10, 3)) {
        fputs("No se aplico encolar: fallo de reserva.\n", stderr);
        cp_vaciar(&cp);
        return 1;
    }
    puts("Operacion aplicada.");
    if (!cp_encolar(&cp, 20, 1)) {
        fputs("No se aplico encolar: fallo de reserva.\n", stderr);
        cp_vaciar(&cp);
        return 1;
    }
    puts("Operacion aplicada.");
    if (!cp_encolar(&cp, 30, 1)) {
        fputs("No se aplico encolar: fallo de reserva.\n", stderr);
        cp_vaciar(&cp);
        return 1;
    }
    puts("Operacion aplicada.");
    printf("Resultado: %d\n", cp_desencolar(&cp));
    printf("Resultado: %d\n", cp_desencolar(&cp));
    /* Liberar propiedad del caller al terminar */ cp_vaciar(&cp);
    return 0;
}
