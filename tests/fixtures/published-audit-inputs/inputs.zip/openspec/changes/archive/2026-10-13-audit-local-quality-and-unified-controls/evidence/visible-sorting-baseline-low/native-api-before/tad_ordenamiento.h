/**
 * @file tad_ordenamiento.h
 * @brief Declaraciones de métodos clásicos de ordenamiento y utilidades para arreglos de enteros.
 *
 * Este archivo contiene las declaraciones de funciones para algoritmos de ordenamiento
 * y utilidades asociadas, para uso modular en C.
 *
 * @author Francisco Alejandro Medina Aguirre
 * @date 2026
 */

#ifndef TAD_ORDENAMIENTO_H
#define TAD_ORDENAMIENTO_H

#include <stddef.h>

/**
 * @brief Código de éxito: 1.
 */
#define ORDENAMIENTO_OK 1
/**
 * @brief Código de error: 0.
 */
#define ORDENAMIENTO_ERROR 0
/**
 * @brief Límite de rango admitido por Counting Sort y Binsort (que delega en Counting Sort).
 */
#define ORDENAMIENTO_RANGO_MAX 1000000U

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Imprime un arreglo de enteros en una línea.
 *
 * @param arreglo Arreglo de enteros.
 * @param n Número de elementos del arreglo.
 */
void imprimir_arreglo(const int arreglo[], size_t n);
/**
 * @brief Copia los elementos de un arreglo origen hacia un arreglo destino.
 *
 * @param destino Arreglo destino.
 * @param origen Arreglo origen.
 * @param n Número de elementos a copiar.
 * @return ORDENAMIENTO_OK si la copia fue correcta; ORDENAMIENTO_ERROR en caso contrario.
 */
int copiar_arreglo(int destino[], const int origen[], size_t n);

/**
 * @brief Ordena un arreglo usando el método de intercambio directo.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 */
void ordenar_intercambio(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando selección directa.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 */
void ordenar_seleccion(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando inserción directa.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 */
void ordenar_insercion(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando burbuja mejorada.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 */
void ordenar_burbuja(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando Shell Sort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 */
void ordenar_shell(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando QuickSort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 */
void ordenar_quicksort(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando MergeSort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0 o fallo de memoria.
 */
int  ordenar_mergesort(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando HeapSort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 */
void ordenar_heapsort(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando Counting Sort.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0, rango mayor que ORDENAMIENTO_RANGO_MAX, tamaño no representable o fallo de memoria.
 */
int  ordenar_counting_sort(int arreglo[], size_t n);
/**
 * @brief Ordena delegando en Counting Sort; conserva sus límites de rango y códigos de error.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0, rango mayor que ORDENAMIENTO_RANGO_MAX, tamaño no representable o fallo de memoria.
 */
int  ordenar_binsort(int arreglo[], size_t n);
/**
 * @brief Ordena un arreglo usando Radix Sort LSD en base 10.
 *
 * Esta implementación acepta enteros negativos separándolos de los no negativos,
 * ordenando magnitudes y recombinando al final.
 *
 * @param arreglo Arreglo de enteros a ordenar.
 * @param n Número de elementos del arreglo.
 * @return ORDENAMIENTO_OK si se ordenó correctamente; ORDENAMIENTO_ERROR ante arreglo NULL, n == 0 o fallo de memoria.
 */
int  ordenar_radixsort(int arreglo[], size_t n);

/**
 * @brief Ejecuta y muestra un algoritmo de ordenamiento sobre una copia del arreglo base.
 *
 * @param nombre Nombre descriptivo del algoritmo.
 * @param ordenar Función de ordenamiento que no retorna estado.
 * @param base Arreglo base.
 * @param n Número de elementos.
 */
void probar_algoritmo_void(const char *nombre, void (*ordenar)(int[], size_t), const int base[], size_t n);
/**
 * @brief Ejecuta y muestra un algoritmo de ordenamiento que retorna estado.
 *
 * @param nombre Nombre descriptivo del algoritmo.
 * @param ordenar Función de ordenamiento que retorna ORDENAMIENTO_OK o ORDENAMIENTO_ERROR.
 * @param base Arreglo base.
 * @param n Número de elementos.
 */
void probar_algoritmo_int(const char *nombre, int (*ordenar)(int[], size_t), const int base[], size_t n);

#ifdef __cplusplus
}
#endif

#endif // TAD_ORDENAMIENTO_H
