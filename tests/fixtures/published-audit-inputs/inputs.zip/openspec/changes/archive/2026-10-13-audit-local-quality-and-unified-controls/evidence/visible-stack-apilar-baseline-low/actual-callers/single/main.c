#include <stdio.h>
#include "tad_pila.h"
int main(void) {
    // Declaracion de la estructura
    ptrPila pila = NULL;
 
    // Historial de ejecucion del usuario
    pila_apilar(&pila, 7);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    pila_apilar(&pila, -1);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    pila_apilar(&pila, -1);
    printf("Operacion aplicada.\n");
    // Operacion aplicada.
    return 0;
}
