# Correcciones exclusivas de QA

Driver: indentación gccstrict corregida; MinGW redirigeprintf pesealdefine,porloquehook directoqa_printf registra el mismo texto sin tocarCcanónico. Logs iniciales preservados.

Browserreutilizado dePrioridad intentóencolar como seed dePila;emptyera válidopuestoque no seeds. Tresfixtures se recapturan sólo conapilar yassertsuccess;empty se reutiliza sinrerun. Reportoriginal ycallersiniciales preservados; no sumar loops inválidos como cobertura.
