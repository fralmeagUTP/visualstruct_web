
#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#include <string.h>
static int *root,*pt,ct;static size_t count,*pg,*pi,*pj,cg,ci,cj;
static int hg,hi,hj,ht,comparisons,moves,fixture;
static void emit(const char*t,const char*f,int condition){
 if(pg && hg){cg=*pg;}if(pi && hi){ci=*pi;}if(pj && hj){cj=*pj;}if(pt && ht){ct=*pt;}
 printf("{\"case\":%d,\"event\":{\"token\":\"%s\",\"function\":",fixture,t);
 if(f){printf("\"%s\"",f);}else{printf("null");}
 printf(",\"intervalo\":");if(hg){printf("%zu",cg);}else{printf("null");}
 printf(",\"i\":");if(hi){printf("%zu",ci);}else{printf("null");}
 printf(",\"j\":");if(hj){printf("%zu",cj);}else{printf("null");}
 printf(",\"temporal\":");if(ht){printf("%d",ct);}else{printf("null");}
 printf(",\"comparisons\":%d,\"moves\":%d},\"condition\":",comparisons,moves);
 if(condition<0){printf("null");}else{printf(condition?"true":"false");}
 printf(",\"array\":[");for(size_t k=0;k<count;k++){if(k){printf(",");}printf("%d",root[k]);}puts("]}");
}
static int cond(const char*t,const char*f,int r){if(!strcmp(t,"while_compare")){comparisons++;}emit(t,f,r);return r;}
static int checked(int r){emit("valid_return","arreglo_valido",-1);return cond("sort_guard","ordenar_shell",!r);}

static int arreglo_valido(const int arreglo[], size_t n) {emit("valid_entry","arreglo_valido",-1);
	return cond("valid_ptr","arreglo_valido",arreglo!=NULL) && cond("valid_n","arreglo_valido",n>0);
}
void ordenar_shell(int arreglo[], size_t n) {emit("sort_entry","ordenar_shell",-1);
	size_t intervalo;pg=&intervalo;emit("gap_declare","ordenar_shell",-1);
	emit("valid_call","ordenar_shell",-1);if(checked(arreglo_valido(arreglo,n))){pg=NULL;emit("guard_return","ordenar_shell",-1);return;}
	for(intervalo=n/2,hg=1,emit("gap_init","ordenar_shell",-1);cond("gap_test","ordenar_shell",intervalo>0);intervalo/=2,emit("gap_divide","ordenar_shell",-1)) {
		size_t i;pi=&i;hi=0;emit("i_declare","ordenar_shell",-1);
		for(i=intervalo,hi=1,emit("i_init","ordenar_shell",-1);cond("i_test","ordenar_shell",i<n);++i,emit("i_increment","ordenar_shell",-1)) {
			int temporal=arreglo[i];pt=&temporal;ht=1;moves++;emit("temp_take","ordenar_shell",-1);
			size_t j=i;pj=&j;hj=1;emit("j_init","ordenar_shell",-1);
			while(cond("while_test","ordenar_shell",cond("while_left","ordenar_shell",j>=intervalo) && cond("while_compare","ordenar_shell",arreglo[j-intervalo]>temporal))) {
				arreglo[j]=arreglo[j-intervalo];moves++;emit("shift","ordenar_shell",-1);
				j-=intervalo;emit("j_subtract","ordenar_shell",-1);
			}
			arreglo[j]=temporal;moves++;emit("temp_write","ordenar_shell",-1);
		pt=NULL;pj=NULL;ht=hj=0;emit("inner_body_exit","ordenar_shell",-1);}
	pi=NULL;hi=0;emit("gap_body_exit","ordenar_shell",-1);}
pg=NULL;}

int main(void){
{int a[]={7};root=a;count=sizeof(a)/sizeof(a[0]);fixture=0;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(a,count);emit("sort_return","ordenar_shell",-1);}
{int a[]={1,2,3,4};root=a;count=sizeof(a)/sizeof(a[0]);fixture=1;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(a,count);emit("sort_return","ordenar_shell",-1);}
{int a[]={4,3,2,1};root=a;count=sizeof(a)/sizeof(a[0]);fixture=2;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(a,count);emit("sort_return","ordenar_shell",-1);}
{int a[]={2,2,2};root=a;count=sizeof(a)/sizeof(a[0]);fixture=3;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(a,count);emit("sort_return","ordenar_shell",-1);}
{int a[]={-3,0,-1,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=4;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(a,count);emit("sort_return","ordenar_shell",-1);}
{int a[]={2147483647,-2147483648,0};root=a;count=sizeof(a)/sizeof(a[0]);fixture=5;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(a,count);emit("sort_return","ordenar_shell",-1);}
{int a=42;root=&a;count=0;fixture=6;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(&a,0);}
{root=NULL;count=0;fixture=7;hg=hi=hj=ht=comparisons=moves=0;pg=pi=pj=NULL;pt=NULL;emit("initial",NULL,-1);ordenar_shell(NULL,1);}
return 0;}
