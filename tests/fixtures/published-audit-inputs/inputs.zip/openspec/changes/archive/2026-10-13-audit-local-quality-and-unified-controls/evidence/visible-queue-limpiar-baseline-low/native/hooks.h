#include <stddef.h>
struct NodoCola;struct Cola;
void qa_event(const char*,struct Cola*,int);
int qa_guard(const char*,struct Cola*,int);
void qa_capture(struct NodoCola*);
void qa_rear_NULL(void);
void *qa_malloc(size_t);
void qa_free(void*);
