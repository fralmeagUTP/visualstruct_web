from pathlib import Path
import os,time,json,ctypes
from ctypes import wintypes as w
from job_structures import Extended

def require_guarded_job():
 P=Path(__file__).resolve().parent;label=os.environ['VS_RETENTION_LABEL'];jobname=os.environ['VS_RETENTION_JOB'];marker=P/(label+'-job-allowed');start=time.monotonic()
 while not marker.exists():
  if time.monotonic()-start>10:raise RuntimeError('No guarded2GiB handshake')
  time.sleep(.05)
 assert marker.read_text(encoding='utf-8')==jobname
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=w.HANDLE;k.OpenJobObjectW.argtypes=[w.DWORD,w.BOOL,w.LPCWSTR];k.OpenJobObjectW.restype=w.HANDLE;k.IsProcessInJob.argtypes=[w.HANDLE,w.HANDLE,ctypes.POINTER(w.BOOL)];k.QueryInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD,ctypes.c_void_p];job=k.OpenJobObjectW(4,False,jobname);assert job;member=w.BOOL();assert k.IsProcessInJob(k.GetCurrentProcess(),job,ctypes.byref(member)) and member.value;info=Extended();assert k.QueryInformationJobObject(job,9,ctypes.byref(info),ctypes.sizeof(info),None);assert info.ProcessMemoryLimit==2147483648
 (P/(label+'-effective-worker-limit.json')).write_text(json.dumps({'actual_worker_PID':os.getpid(),'job':jobname,'self_membership':True,'ProcessMemoryLimit':info.ProcessMemoryLimit,'LimitFlags':info.BasicLimitInformation.LimitFlags,'before_app_imports':True},indent=2),encoding='utf-8')
