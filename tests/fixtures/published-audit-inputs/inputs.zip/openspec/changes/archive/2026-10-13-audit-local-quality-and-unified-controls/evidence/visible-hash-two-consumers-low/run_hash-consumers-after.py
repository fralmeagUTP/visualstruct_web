from pathlib import Path
import os,sys,json,subprocess,ctypes,time
from ctypes import wintypes as w
P=Path(__file__).resolve().parent;R=Path.cwd();AID="coordination-hash-two-consumers-low-20261008";OP="audit.hash-two-consumers"
assert not (P/"hash-consumers-after-start.json").exists()
x=subprocess.run([sys.executable,"-B","scripts/check_session_continuity.py","--change","audit-local-quality-and-unified-controls","--operation",OP,"--assignment-id",AID,"--phase","before"],capture_output=True);(P/"hash-consumers-after-before.json").write_bytes(x.stdout+x.stderr);assert x.returncode==0
from job_structures import k,Extended
name="VisualStructBF20SavedWire_"+str(os.getpid());job=k.CreateJobObjectW(None,name);limits=Extended();limits.BasicLimitInformation.LimitFlags=0x100|0x2000;limits.ProcessMemoryLimit=2147483648;assert job and k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits))
(P/"hash-consumers-after-start.json").write_text(json.dumps({"test_only_no_C_runtime_changes":True,"cap_seconds":120,"hard_RAM":2147483648}),encoding="utf-8")
with (P/"hash-consumers-after-stdout.log").open("w",encoding="utf-8") as out,(P/"hash-consumers-after-stderr.log").open("w",encoding="utf-8") as err:
 env=dict(os.environ,VS_RETENTION_JOB=name,VS_RETENTION_LABEL="hash-consumers-after",PYTHONDONTWRITEBYTECODE="1");child=subprocess.Popen([sys.executable,"-B",str(P/"verify_hash-consumers-after.py")],env=env,cwd=R,stdout=out,stderr=err)
 assert k.AssignProcessToJobObject(job,w.HANDLE(int(child._handle)));(P/"hash-consumers-after-job-allowed").write_text(name,encoding="utf-8");start=time.monotonic()
 try:
  while child.poll() is None:
   if time.monotonic()-start>=120:k.TerminateJobObject(job,124);break
   time.sleep(.5)
  rc=child.wait()
 finally:k.CloseHandle(job)
(P/"hash-consumers-after-result.json").write_text(json.dumps({"exit":rc,"seconds":time.monotonic()-start,"test_only_no_C_runtime_changes":True}),encoding="utf-8");print("Focal test verification",rc,flush=True)
