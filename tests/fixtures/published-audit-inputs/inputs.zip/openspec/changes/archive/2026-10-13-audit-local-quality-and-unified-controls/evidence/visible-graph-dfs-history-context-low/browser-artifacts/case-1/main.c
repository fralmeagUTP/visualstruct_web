/** @file main.c @brief Historial de operaciones; BFS/DFS imprimen su resultado C y libera su lista propia. */
#include "tad_grafo.h"
#include <stdio.h>
#include <stdlib.h>
/** @brief Ejecuta el historial. @return 0 tras liberar el grafo final. */
int main(void) {
    Grafo g = grafo_crear();

    // Historial de ejecucion del usuario
    /* TAD nuevo: reinicio del grafo (dirigido=true didáctico). */ g = grafo_crear();
    printf("Operación aplicada.\n");
    // Operación aplicada.
    g = grafo_insertar_vertice(g, -1);
    printf("Operación aplicada.\n");
    // Operación aplicada.
    ListaVertice rec_3 = grafo_dfs(g, -1); printf("DFS:"); for (ListaVertice it_3 = rec_3; it_3 != NULL; it_3 = it_3->sig) printf(" %d", it_3->dato); printf("\n"); while (rec_3 != NULL) { ListaVertice next_3 = rec_3->sig; free(rec_3); rec_3 = next_3; }
    ListaVertice rec_4 = grafo_dfs(g, -1); printf("DFS:"); for (ListaVertice it_4 = rec_4; it_4 != NULL; it_4 = it_4->sig) printf(" %d", it_4->dato); printf("\n"); while (rec_4 != NULL) { ListaVertice next_4 = rec_4->sig; free(rec_4); rec_4 = next_4; }
    while (g.a != NULL) { ListaArco next = g.a->sig; free(g.a); g.a = next; }
    while (g.v != NULL) { ListaVertice next = g.v->sig; free(g.v); g.v = next; }
    return 0;
}