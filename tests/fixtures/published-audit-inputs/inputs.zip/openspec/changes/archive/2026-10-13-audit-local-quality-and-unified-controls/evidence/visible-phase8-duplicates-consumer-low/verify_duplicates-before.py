import private_limits
private_limits.require_guarded_job()
from pathlib import Path
import sys,os,json
P=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path.cwd()/"tests"))
os.environ.update(PYTHONDONTWRITEBYTECODE="1",SESSION_CACHE_DIR=str(P/"sessions-focal"),FLASK_SECRET_KEY="focal-oracle")
from app.services.structure_service import StructureService
from app.services.sorting_structure_service import SortingStructureService
from app.services.hierarchical_structure_service import HierarchicalStructureService
from flask.testing import FlaskClient
captures=[]
def save(kind,structure,op,body):
 name="duplicates-before-call-"+str(len(captures)+1)+"-"+str(structure)+"-"+str(op)+"-"+kind+".json"
 with (P/name).open("w",encoding="utf-8") as f:json.dump(body,f,ensure_ascii=True,separators=(",",":"))
 captures.append({"structure":structure,"operation":op,"kind":kind,"file":name})
def observer(original):
 def observed(*args,**kwargs):
  r=original(*args,**kwargs)
  structure=kwargs.get("structure_id",args[0] if len(args)>0 else None);op=kwargs.get("operation_name",args[1] if len(args)>1 else None)
  save("service",structure,op,r);return r
 return observed
for cls in (StructureService,SortingStructureService,HierarchicalStructureService):cls.execute_operation=staticmethod(observer(cls.execute_operation))
http_original=FlaskClient.open
def http(self,*args,**kwargs):
 r=http_original(self,*args,**kwargs);path=args[0] if args else kwargs.get("path","");op=kwargs.get("json",{}).get("operation")
 if path in {"/sequential/stack/operate","/sequential/sublist/operate"}:save("wire",path.split("/")[2],op,{"status":r.status_code,"body":r.get_json()})
 return r
FlaskClient.open=http
class Capture:
 def pytest_sessionfinish(self,session,exitstatus):(P/"duplicates-before-capture-manifest.json").write_text(json.dumps(captures,indent=2),encoding="utf-8")
import pytest
raise SystemExit(pytest.main(["-q","--disable-warnings","--junitxml="+str(P/"duplicates-before.xml"),"tests/test_phase8_visual_integration.py::test_duplicate_values_keep_temporaries_identities_links_and_auxiliary_states"],plugins=[Capture()]))
