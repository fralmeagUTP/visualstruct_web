# Manual de Usuario

## 1. Objetivo

El **Visualizador Web de Estructuras de Datos** permite practicar TAD reales con visualizacion y soporte didactico en modo interprete de C.

Modulos:

- Secuencial
- Jerarquico
- Grafos
- Tablas Hash

## 2. Requisitos

- Windows 10/11
- Python 3.10 o superior
- Conexion local habilitada (`127.0.0.1`)

## 3. Instalacion y arranque

Desde `c:\Users\fralm\Web_VisualEstruct`:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
.\start_local.bat
```

Abrir en navegador:

```text
http://127.0.0.1:5050/
```

## 4. Navegacion principal

Desde la barra superior:

- `Inicio`
- `Modulo Secuencial`
- `Modulo Jerarquico`
- `Modulo Grafos`
- `Modulo Hash`
- ayudas por modulo

## 5. Flujo de uso por estructura

1. Entrar al modulo.
2. Seleccionar estructura.
3. Elegir operacion en el panel izquierdo.
4. Completar campos requeridos.
5. Pulsar `Ejecutar`.
6. Revisar:
   - mensaje didactico,
   - estado visual actualizado,
   - `Estructura del TAD`,
   - `Codigo C: <Operacion>` o seudocodigo (segun cobertura),
   - historial.
7. Usar `Reiniciar` para limpiar estado de esa estructura.

## 6. Modo interprete C

Cuando la estructura tiene cobertura C:

- `Estructura del TAD` muestra declaraciones reales de `docs/tads_C`.
- El bloque de operacion muestra la funcion C real correspondiente.
- El historial se muestra como `Programa principal (main)` con llamadas C coherentes a las acciones ejecutadas por el usuario.

Nota:

- La linea de destruccion final (por ejemplo `*_destruir`) aparece comentada en el `main` para evitar confundir el flujo interactivo continuo de la UI.

## 7. Reglas de tipos de entrada

- Secuenciales/Jerarquicas: `valor` entero.
- Grafos: `vertice`, `origen`, `destino`, `inicio`, `fin` enteros.
- Grafos: `peso` numerico.
- Hash: `clave` y `valor` texto.

Si el dato es invalido, la operacion no se ejecuta y se muestra mensaje didactico.

## 8. Modulos

### 8.1 Secuencial

Estructuras:

- Pila
- Cola
- Cola de prioridad
- Lista enlazada
- Lista circular
- Sublista

### 8.2 Jerarquico

Estructuras:

- ABB
- AVL
- Rojo-Negro
- Monticulo Binario

Notas:

- AVL muestra FE (factor de equilibrio).
- Rojo-Negro muestra hojas `NULL` como negras.
- Monticulo muestra arreglo y arbol sincronizados.

### 8.3 Grafos

Permite:

- crear grafo dirigido/no dirigido,
- insertar/eliminar vertices y aristas,
- ejecutar BFS, DFS, Dijkstra, Bellman-Ford, Prim y Kruskal,
- simulacion paso a paso de algoritmos.

Recomendaciones:

- Prim/Kruskal: usar grafo no dirigido.
- Pesos negativos: usar Bellman-Ford (Dijkstra bloquea este caso).

### 8.4 Hash

Permite:

- crear tabla,
- insertar/actualizar,
- consultar/eliminar,
- revisar buckets, colisiones y factor de carga.

## 9. Solucion de problemas

### `ERR_CONNECTION_REFUSED`

1. Verifica que la consola del servidor siga abierta.
2. Confirma `Running on http://127.0.0.1:5050`.
3. Recarga con `Ctrl + F5`.
4. Si falla, usa:

```powershell
.\run_server_debug.bat
```

### Puerto ocupado

Si otro proceso usa `5050`, cierra procesos Python activos y reinicia `start_local.bat`.

## 10. Pruebas

```powershell
python -m pytest -q
```
