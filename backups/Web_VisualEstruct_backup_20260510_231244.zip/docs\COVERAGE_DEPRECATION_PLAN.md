﻿# Plan de Mejora: Cobertura y Deprecaciones

Fecha base: 10 de mayo de 2026

## 1. Objetivo

Incrementar confianza tecnica del proyecto mediante:

- eliminacion de deprecaciones activas,
- mejora de cobertura automatizada,
- reduccion de riesgo de regresiones en el modo interprete C.

## 2. Estado actual

- Suite: `131 passed, 2 skipped`.
- Cobertura global: `90%`.
- Deprecacion de `Flask-Session` backend `filesystem`: migrada a `cachelib` y `redis`.

## 3. Plan por fases

### Fase A - Deprecaciones (completada)

- Migracion a `SESSION_TYPE=cachelib`.
- Soporte `SESSION_TYPE=redis`.
- Pruebas de inicializacion y fallback.

Resultado: completada y validada.

### Fase B - Cobertura jerarquica (completada)

- Pruebas profundas de `ABB`, `AVL`, `RojoNegro`, `MonticuloBinario` jerarquico.

Resultado: cobertura alta en dominio jerarquico.

### Fase C - Cobertura grafos + adapters (completada)

- `app/domain/graph/lista_enlazada.py` -> 98%.
- `app/domain/graph/monticulo_binario.py` -> 96%.
- adapters jerarquicos (`abb`, `avl`, `red_black`, `binary_heap`) -> 95%+.

Resultado: meta global >=88% alcanzada (90%).

### Fase D - Regresiones modo interprete C (completada)

- Contrato de render de nodos `NULL` negros en rojo-negro.
- Eliminaciones sucesivas AVL/RN con validacion por paso.
- Coherencia entre historial de operaciones y estado visual reconstruido.

Resultado: cobertura de regresion agregada en pruebas automatizadas.

### Fase E - E2E UI Playwright (parcial, dependiente de entorno)

- Se agregaron pruebas E2E opcionales para:
  - scroll del panel de codigo,
  - sincronizacion historial-main,
  - render visual en jerarquicas y grafos.
- Se ejecutan solo cuando Playwright + navegadores estan instalados.

Pendiente operativo:

1. Instalar Playwright en CI.
2. Ejecutar `playwright install chromium`.
3. Agregar job E2E dedicado.

## 4. Criterios de aceptacion actuales

- `pytest` en verde: cumplido.
- Cobertura >=88%: cumplido.
- Deprecaciones principales mitigadas: cumplido.
- Regresiones criticas del modo interprete C: cubiertas.

## 5. Comandos de verificacion

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m pytest --cov=app --cov-report=term-missing
```

Comandos opcionales E2E:

```powershell
pip install playwright
python -m playwright install chromium
.\.venv\Scripts\python.exe -m pytest tests\test_ui_playwright_e2e.py -q
```
