# Visualizador Web de Estructuras de Datos

Aplicacion web didactica construida con Flask para aprender estructuras de datos mediante interaccion, visualizacion y modo interprete de codigo C.

## Modulos disponibles

- Secuencial
- Jerarquico
- Grafos
- Tablas Hash

## Modo interprete C (estado actual)

La app prioriza fragmentos reales de `docs/tads_C` cuando existen para la estructura.

Cobertura C-first:

- Secuenciales: lista enlazada, pila, cola, cola de prioridad, lista circular, sublista.
- Jerarquicas: ABB, AVL, Rojo-Negro, Monticulo Binario.
- Grafos: grafo (operaciones estructurales y algoritmos).

Comportamiento en UI:

- `Estructura del TAD`: declaraciones C reales.
- `Codigo C: <Operacion>`: funcion C asociada a la operacion seleccionada.
- `Historial de ejecucion`: renderizado como `Programa principal (main)` con llamadas C coherentes a lo ejecutado.

Fallback:

- Si no hay cobertura C para una estructura, se usa `app/services/pseudocode_service.py`.
- Tablas Hash se mantiene principalmente en modo didactico/pseudocodigo.

## Reglas de tipos (actual)

- En estructuras de nodos, el campo `valor/dato` se valida como **entero**.
- En grafos, `vertice`, `origen`, `destino`, `inicio` y `fin` se validan como **enteros**.
- En grafos, el `peso` se valida como numerico (entero o decimal).
- En tablas hash, `key/value` se manejan como texto.

## Arquitectura

Proyecto organizado por capas:

- `app/domain/`: TAD reales por modulo (`sequential`, `hierarchical`, `graph`, `hash`).
- `app/adapters/`: adaptadores por estructura con contrato comun.
- `app/services/`: casos de uso, orquestacion, ayuda didactica y sesion.
- `app/routes/`: blueprints Flask (sin logica de dominio).
- `templates/`: vistas HTML reutilizables (`base`, `header`, `navbar`, `footer`).
- `static/css/` y `static/js/`: estilos y JS de presentacion.
- `tests/`: pruebas unitarias e integracion.

Servicios didacticos clave:

- `app/services/c_code_service.py`: extrae estructuras y funciones C desde `docs/tads_C`.
- `app/services/pseudocode_service.py`: fallback didactico cuando no hay cobertura C.

Contrato comun de adaptadores:

- `create()`
- `execute(operation_name, payload)`
- `to_visual_state()`
- `reset()`
- `get_supported_operations()`

## Endpoints principales

- Inicio: `GET /`
- Secuencial: `GET /sequential/`
- Jerarquico: `GET /hierarchical/`
- Grafos: `GET /graph/`
- Hash: `GET /hash/`

## Scripts de arranque

- `start_local.bat`: arranque recomendado en Windows.
- `run_server_debug.bat`: arranque con salida detallada para depuracion.
- `start_5050_verified.bat`: arranque con verificacion de puerto y apertura de navegador.
- `start_local.ps1`: variante PowerShell.

Parametros locales:

- Host: `127.0.0.1`
- Puerto: `5050`

## Ejecutar localmente

1. Crear entorno virtual:

```powershell
python -m venv .venv
```

2. Activar entorno virtual:

```powershell
.\.venv\Scripts\Activate.ps1
```

3. Instalar dependencias:

```powershell
pip install -r requirements.txt
```

4. Ejecutar app:

```powershell
.\start_local.bat
```

5. Abrir:

```text
http://127.0.0.1:5050/
```

6. Ejecutar pruebas:

```powershell
python -m pytest -q
```

## Publicacion para uso simultaneo

Para despliegue concurrente:

1. Usar servidor WSGI (no `flask run`).
2. Usar sesiones server-side (`Flask-Session`).
3. En produccion, usar `SESSION_TYPE=redis`.
4. Configurar `FLASK_SECRET_KEY` fuerte y `SESSION_COOKIE_SECURE=true` bajo HTTPS.

Variables recomendadas:

```text
FLASK_SECRET_KEY=una-clave-larga-y-segura
SESSION_TYPE=redis
SESSION_REDIS_URL=redis://host:6379/0
SESSION_COOKIE_SECURE=true
SESSION_COOKIE_SAMESITE=Lax
SESSION_LIFETIME_MINUTES=240
SESSION_MAX_HISTORY=300
```

Ejecucion con Waitress:

```powershell
python -m waitress --host=0.0.0.0 --port=5050 wsgi:app
```

Health check:

```text
GET /healthz
```

## Limitaciones conocidas

- `lista_circular.py`: no incluye `eliminar_final` ni `eliminar_posicion`.
- `sublista.py`: no incluye `eliminar_hijo` ni borrado masivo de hijos por padre.
- `avl.py`: el TAD no expone detalle textual interno de rotaciones.
- `rojo_negro.py`: el TAD no expone detalle textual interno de recoloreos/rotaciones.
- `monticulo_binario.py`: no expone cambio dinamico min-heap <-> max-heap sin recrear.
- `tabla_hash.py`: no expone API publica de snapshot didactico de buckets.

## Documentacion relacionada

- Guia de usuario: `docs/USER_GUIDE.md`
- Referencia historica de pseudocodigos: `docs/PSEUDOCODIGOS_TAD.md`
- Codigo C fuente de referencia didactica: `docs/tads_C/`

## Troubleshooting rapido

Si aparece `ERR_CONNECTION_REFUSED`:

1. Verifica que la consola del servidor siga abierta.
2. Confirma `http://127.0.0.1:5050`.
3. Reintenta con `start_local.bat`.
4. Si falla, usa `run_server_debug.bat` y revisa el traceback.
