"""Adapter layer package."""
