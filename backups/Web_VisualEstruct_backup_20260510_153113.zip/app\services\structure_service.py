"""Service layer for sequential structure orchestration."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from app.adapters.base_adapter import BaseAdapter
from app.adapters.circular_list_adapter import CircularListAdapter
from app.adapters.linked_list_adapter import LinkedListAdapter
from app.adapters.priority_queue_adapter import PriorityQueueAdapter
from app.adapters.queue_adapter import QueueAdapter
from app.adapters.stack_adapter import StackAdapter
from app.adapters.sublist_adapter import SublistAdapter
from app.services.pseudocode_service import PseudocodeService
from app.domain.sequential import (
    ElementoNoEncontradoError,
    EstructuraVaciaError,
    PosicionInvalidaError,
    TADError,
)


class StructureService:
    """Coordinate adapters and transform errors into didactic messages."""

    _REGISTRY: dict[str, dict[str, Any]] = {
        "stack": {
            "name": "Pila",
            "description": "Estructura LIFO para apilar y desapilar elementos.",
            "adapter": StackAdapter,
        },
        "queue": {
            "name": "Cola",
            "description": "Estructura FIFO para encolar y desencolar elementos.",
            "adapter": QueueAdapter,
        },
        "priority_queue": {
            "name": "Cola de Prioridad",
            "description": "Los elementos se atienden por prioridad numérica.",
            "adapter": PriorityQueueAdapter,
        },
        "linked_list": {
            "name": "Lista Enlazada",
            "description": "Secuencia de nodos con operaciones por posición y valor.",
            "adapter": LinkedListAdapter,
        },
        "circular_list": {
            "name": "Lista Circular",
            "description": "Lista donde el último nodo vuelve al primero.",
            "adapter": CircularListAdapter,
        },
        "sublist": {
            "name": "Sublista",
            "description": "Padres con sublistas de hijos.",
            "adapter": SublistAdapter,
        },
    }

    @staticmethod
    def list_structures() -> list[dict[str, str]]:
        """Return metadata for all sequential structures."""
        items: list[dict[str, str]] = []
        for structure_id, data in StructureService._REGISTRY.items():
            items.append(
                {
                    "id": structure_id,
                    "name": data["name"],
                    "description": data["description"],
                }
            )
        return items

    @staticmethod
    def get_structure(structure_id: str) -> dict[str, Any]:
        """Return one structure metadata dictionary."""
        structure = StructureService._REGISTRY.get(structure_id)
        if structure is None:
            raise KeyError(f"Estructura no registrada: {structure_id}.")
        return structure

    @staticmethod
    def _new_adapter(structure_id: str) -> BaseAdapter:
        structure = StructureService.get_structure(structure_id)
        adapter_class: type[BaseAdapter] = structure["adapter"]
        return adapter_class()

    @staticmethod
    def _rebuild_adapter(
        structure_id: str,
        history: list[dict[str, Any]],
    ) -> tuple[BaseAdapter, list[dict[str, Any]]]:
        """Replay mutating history and return a ready adapter and valid history."""
        adapter = StructureService._new_adapter(structure_id)
        valid_history: list[dict[str, Any]] = []

        for step in history:
            operation = step.get("operation")
            payload = step.get("payload", {})
            if not isinstance(operation, str) or not isinstance(payload, dict):
                continue
            try:
                adapter.execute(operation, payload)
            except Exception:
                continue
            valid_history.append({"operation": operation, "payload": deepcopy(payload)})

        return adapter, valid_history

    @staticmethod
    def _didactic_error(error: Exception) -> str:
        """Translate technical exceptions to didactic messages."""
        if isinstance(error, EstructuraVaciaError):
            return "No se puede ejecutar la operación porque la estructura está vacía."
        if isinstance(error, PosicionInvalidaError):
            return "La posición ingresada es inválida para el estado actual."
        if isinstance(error, ElementoNoEncontradoError):
            return str(error)
        if isinstance(error, ValueError):
            return str(error)
        if isinstance(error, TADError):
            return str(error)
        return "Ocurrió un error inesperado durante la operación."

    @staticmethod
    def get_view_model(structure_id: str, history: list[dict[str, Any]]) -> dict[str, Any]:
        """Build the data needed to render one structure page."""
        structure = StructureService.get_structure(structure_id)
        adapter, valid_history = StructureService._rebuild_adapter(structure_id, history)
        return {
            "id": structure_id,
            "name": structure["name"],
            "description": structure["description"],
            "operations": adapter.get_supported_operations(),
            "visual_state": adapter.to_visual_state(),
            "didactic": PseudocodeService.get_structure_data(structure_id),
            "history": valid_history,
        }

    @staticmethod
    def execute_operation(
        structure_id: str,
        operation_name: str,
        payload: dict[str, Any],
        history: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Execute an operation over a rebuilt structure state."""
        adapter, valid_history = StructureService._rebuild_adapter(structure_id, history)
        operations = adapter.get_supported_operations()
        operation_meta = next((item for item in operations if item["name"] == operation_name), None)

        if operation_meta is None:
            return {
                "success": False,
                "message": "La operación solicitada no está soportada por esta estructura.",
                "visual_state": adapter.to_visual_state(),
                "history": valid_history,
            }

        try:
            result = adapter.execute(operation_name, payload)
        except (TADError, ValueError, TypeError) as error:
            return {
                "success": False,
                "message": StructureService._didactic_error(error),
                "visual_state": adapter.to_visual_state(),
                "history": valid_history,
            }

        if operation_meta.get("mutates", False):
            valid_history.append({"operation": operation_name, "payload": deepcopy(payload)})

        return {
            "success": True,
            "message": result.get("message", "Operación ejecutada correctamente."),
            "result": result.get("result"),
            "visual_state": adapter.to_visual_state(),
            "history": valid_history,
        }
