﻿# Visualizador Web de Estructuras de Datos

Aplicacion web didactica construida con Flask para aprender estructuras de datos mediante interaccion y visualizacion.

## Modulos disponibles

- Secuencial
- Jerarquico
- Grafos
- Tablas Hash

## Reglas de tipos (actual)

- En estructuras de nodos, el campo `valor/dato` se valida como **entero**.
- En grafos, `vertice`, `origen`, `destino`, `inicio` y `fin` se validan como **enteros**.
- Si el dato no es entero, la app responde con mensaje didactico de validacion.
- Excepcion: en **Tablas Hash** las claves y valores siguen siendo texto.

Resumen rapido:

- Secuenciales (pila, cola, prioridad, lista enlazada, lista circular, sublista): enteros.
- Jerarquicas (ABB, AVL, Rojo-Negro, Monticulo): enteros.
- Grafos: vertices enteros, pesos numericos.
- Hash: `key/value` texto.

## Arquitectura

Proyecto organizado por capas:

- `app/domain/`: TAD reales por modulo (`sequential`, `hierarchical`, `graph`, `hash`).
- `app/adapters/`: adaptadores por estructura con contrato comun.
- `app/services/`: casos de uso, orquestacion, ayuda didactica y sesion.
- `app/routes/`: blueprints Flask (sin logica de dominio).
- `templates/`: vistas HTML reutilizables (`base`, `header`, `navbar`, `footer`).
- `static/css/` y `static/js/`: estilos y JS de presentacion.
- `tests/`: pruebas unitarias e integracion.

Contrato comun de adaptadores:

- `create()`
- `execute(operation_name, payload)`
- `to_visual_state()`
- `reset()`
- `get_supported_operations()`

## Endpoints principales

- Inicio: `GET /`
- Secuencial: `GET /sequential/`
- Jerarquico: `GET /hierarchical/`
- Grafos: `GET /graph/`
- Hash: `GET /hash/`

## Scripts de arranque

- `start_local.bat`: arranque recomendado en Windows (instala dependencias y levanta servidor).
- `run_server_debug.bat`: arranque con salida detallada para depuracion.
- `start_5050_verified.bat`: arranque con verificacion de puerto y apertura automatica del navegador.
- `start_local.ps1`: variante PowerShell del arranque.

Los scripts levantan Flask con:

- Host: `127.0.0.1`
- Puerto: `5050`

## Ejecutar localmente

1. Crear entorno virtual:

```powershell
python -m venv .venv
```

2. Activar entorno virtual:

```powershell
.\.venv\Scripts\Activate.ps1
```

3. Instalar dependencias:

```powershell
pip install -r requirements.txt
```

4. Ejecutar app (opcion recomendada):

```powershell
.\start_local.bat
```

5. O ejecutar directo:

```powershell
python -m flask --app app run --host 127.0.0.1 --port 5050 --no-reload
```

6. Abrir en navegador:

```text
http://127.0.0.1:5050/
```

7. Ejecutar pruebas:

```powershell
python -m pytest -q
```

## Publicacion para uso simultaneo

Para un despliegue con multiples usuarios concurrentes:

1. Usa un servidor WSGI (no `flask run`).
2. Usa sesiones del lado del servidor (`Flask-Session`).
3. En produccion, usa `SESSION_TYPE=redis` con una instancia Redis compartida.
4. Configura `FLASK_SECRET_KEY` fuerte y `SESSION_COOKIE_SECURE=true` si usas HTTPS.

Variables recomendadas:

```text
FLASK_SECRET_KEY=una-clave-larga-y-segura
SESSION_TYPE=redis
SESSION_REDIS_URL=redis://host:6379/0
SESSION_COOKIE_SECURE=true
SESSION_COOKIE_SAMESITE=Lax
SESSION_LIFETIME_MINUTES=240
SESSION_MAX_HISTORY=300
```

Ejecucion con Waitress (Windows/Linux):

```powershell
python -m waitress --host=0.0.0.0 --port=5050 wsgi:app
```

Health check:

```text
GET /healthz
```

## Archivos historicos

Los archivos `*.py` de la raiz se movieron a `old/` para mantener limpia la carpeta principal.

## Operaciones pendientes / limitaciones de TAD

- `lista_circular.py`: no incluye `eliminar_final` ni `eliminar_posicion`.
- `sublista.py`: no incluye `eliminar_hijo` ni borrado masivo de hijos por padre.
- `avl.py`: el TAD no expone el detalle interno textual de rotaciones.
- `rojo_negro.py`: el TAD no expone detalle interno textual de recoloreos/rotaciones.
- `monticulo_binario.py`: no expone cambio dinamico min-heap <-> max-heap sin recrear.
- `tabla_hash.py`: no expone API publica para snapshot didactico de buckets; la visualizacion usa inspeccion temporal interna documentada en el adaptador.

## Seudocodigo didactico

- La interfaz usa seudocodigo con estilo cercano a C:
  - `if (...) { ... }`
  - `return ...;`
  - llamadas tipo `Subrutina(...);`
- Se conserva el formato pedagogico de bloques:
  - `SubProceso ...`
  - `FinSubProceso`
- La fuente activa del seudocodigo esta en:
  - `app/services/pseudocode_service.py`

## Troubleshooting rapido

Si aparece `ERR_CONNECTION_REFUSED`:

1. Verifica que la consola de Flask siga abierta.
2. Confirma que la app este en `http://127.0.0.1:5050`.
3. Reintenta con `./start_local.bat`.
4. Si falla, usa `run_server_debug.bat` y revisa el traceback mostrado.
