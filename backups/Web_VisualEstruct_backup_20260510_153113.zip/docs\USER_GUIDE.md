# Manual de Usuario

## 1. Objetivo

El **Visualizador Web de Estructuras de Datos** permite practicar estructuras de datos mediante operaciones reales y visualizaciones didácticas.

Modulos disponibles:

- Secuencial
- Jerarquico
- Grafos
- Tablas Hash

## 2. Requisitos

- Windows 10/11
- Python 3.10 o superior
- Conexion local habilitada (`127.0.0.1`)

## 3. Instalacion y arranque

Desde `c:\Users\fralm\Web_VisualEstruct`:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
.\start_local.bat
```

Abrir en navegador:

```text
http://127.0.0.1:5050/
```

## 4. Navegacion principal

Desde la barra superior:

- `Inicio`
- `Modulo Secuencial`
- `Modulo Jerarquico`
- `Modulo Grafos`
- `Modulo Hash`
- ayudas por modulo

## 5. Uso general de una estructura

1. Entrar al modulo.
2. Seleccionar estructura.
3. Elegir operacion en el panel izquierdo.
4. Completar campos requeridos.
5. Pulsar `Ejecutar`.
6. Revisar:
   - mensaje didactico,
   - estado visual actualizado,
   - notas didacticas.
7. Usar `Reiniciar` para limpiar el estado de esa estructura.

## 5.1 Regla de tipos de entrada

- Para TAD con nodos (secuenciales y jerarquicos), el campo `valor` debe ser entero.
- En grafos, los vertices (`vertice`, `origen`, `destino`, `inicio`, `fin`) deben ser enteros.
- En grafos, el `peso` puede ser numerico (entero o decimal).
- En tablas hash, `clave` y `valor` se manejan como texto.

Si se ingresa un dato invalido, el sistema muestra un mensaje didactico y no ejecuta la operacion.

## 6. Modulo Secuencial

Estructuras:

- Pila
- Cola
- Cola de prioridad
- Lista enlazada
- Lista circular
- Sublista (padres e hijos)

Recomendacion:

- Inserta varios datos y luego prueba operaciones de consulta/eliminacion para entender el comportamiento.

## 7. Modulo Jerarquico

Estructuras:

- ABB
- AVL
- Rojo-Negro
- Monticulo Binario

Recomendacion:

- En AVL observa `fe` (factor de equilibrio).
- En Monticulo observa arreglo y arbol al mismo tiempo.

## 8. Modulo Grafos

Permite:

- crear grafo dirigido/no dirigido,
- insertar/eliminar vertices y aristas,
- ejecutar BFS, DFS, Dijkstra, Bellman-Ford, Prim y Kruskal,
- visualizar simulacion paso a paso.

Recomendacion:

- Usa Prim/Kruskal solo en no dirigidos.
- Si hay peso negativo, usa Bellman-Ford.
- Ingresa vertices como enteros (por ejemplo: `1`, `2`, `10`).

## 9. Modulo Hash

Permite:

- crear tabla con capacidad positiva,
- insertar/actualizar clave-valor,
- buscar, verificar existencia y eliminar claves,
- consultar claves/valores/items,
- ver tamaño, capacidad y factor de carga,
- visualizar buckets, colisiones y redimensionamiento.

Recomendacion:

- Compara el estado de buckets antes y despues de insertar claves para entender colisiones.

## 10. Solucion de problemas

### `ERR_CONNECTION_REFUSED`

1. Verifica que la consola donde corriste `start_local.bat` siga abierta.
2. Confirma que indique:
   - `Running on http://127.0.0.1:5050`
3. Recarga con `Ctrl + F5`.
4. Si el servidor se cierra, usa:

```powershell
.\run_server_debug.bat
```

y revisa el traceback mostrado en consola.

### Puerto ocupado

Si otro proceso usa `5050`, cierra procesos Python activos y vuelve a iniciar `start_local.bat`.

## 11. Ejecutar pruebas

```powershell
python -m pytest -q
```

## 12. Nota didactica

Algunas operaciones pueden no existir porque dependen del TAD real suministrado. En esos casos la interfaz muestra restricciones como parte del aprendizaje.
