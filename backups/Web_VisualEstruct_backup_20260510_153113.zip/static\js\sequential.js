"use strict";

function byId(id) {
  return document.getElementById(id);
}

function renderOperationInputs(operation, container) {
  container.innerHTML = "";
  if (!operation || !operation.inputs) {
    return;
  }

  operation.inputs.forEach((field) => {
    const wrapper = document.createElement("div");
    const label = document.createElement("label");
    label.setAttribute("for", `field-${field.name}`);
    label.textContent = field.label;

    const input = document.createElement("input");
    input.id = `field-${field.name}`;
    input.name = field.name;
    input.type = field.type === "number" ? "number" : "text";
    input.required = true;
    if (field.type === "number" && Object.prototype.hasOwnProperty.call(field, "min")) {
      input.min = String(field.min);
    }

    wrapper.appendChild(label);
    wrapper.appendChild(input);
    container.appendChild(wrapper);
  });
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function nodeBox(content, options = {}) {
  const cls = options.className ? ` ${options.className}` : "";
  return `<div class="viz-node${cls}">${content}</div>`;
}

function drawCircularLoop(visualContainer) {
  const wrap = visualContainer.querySelector(".circular-wrap");
  if (!wrap) {
    return;
  }

  const row = wrap.querySelector(".viz-row");
  if (!row) {
    return;
  }

  const nodes = row.querySelectorAll(".viz-node");
  if (nodes.length < 2) {
    return;
  }

  const previous = wrap.querySelector(".viz-loop-svg");
  if (previous) {
    previous.remove();
  }

  const first = nodes[0];
  const last = nodes[nodes.length - 1];
  const wrapRect = wrap.getBoundingClientRect();
  const rowRect = row.getBoundingClientRect();
  const firstRect = first.getBoundingClientRect();
  const lastRect = last.getBoundingClientRect();

  const headX = firstRect.left - wrapRect.left + 12;
  const tailX = lastRect.right - wrapRect.left - 12;
  const downY = rowRect.top - wrapRect.top + 2;
  const topY = Math.max(30, downY - 24);

  const headLabel = wrap.querySelector(".viz-pointer.head");
  const tailLabel = wrap.querySelector(".viz-pointer.tail");
  if (headLabel) {
    headLabel.style.left = `${Math.max(6, headX - 10)}px`;
    headLabel.style.top = `${Math.max(2, topY - 24)}px`;
  }
  if (tailLabel) {
    tailLabel.style.left = `${tailX + 8}px`;
    tailLabel.style.top = `${Math.max(2, topY - 24)}px`;
  }

  const width = Math.max(wrap.scrollWidth, tailX + 14);
  const height = Math.max(wrap.scrollHeight, downY + 8);

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "viz-loop-svg");
  svg.setAttribute("width", String(Math.ceil(width)));
  svg.setAttribute("height", String(Math.ceil(height)));
  svg.setAttribute("viewBox", `0 0 ${Math.ceil(width)} ${Math.ceil(height)}`);

  const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
  const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker");
  marker.setAttribute("id", "viz-loop-arrow");
  marker.setAttribute("markerWidth", "12");
  marker.setAttribute("markerHeight", "10");
  marker.setAttribute("refX", "9");
  marker.setAttribute("refY", "5");
  marker.setAttribute("orient", "auto");
  marker.setAttribute("markerUnits", "strokeWidth");
  const arrowPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
  arrowPath.setAttribute("d", "M 0 0 L 9 5 L 0 10 z");
  arrowPath.setAttribute("class", "viz-loop-arrow-head");
  marker.appendChild(arrowPath);
  defs.appendChild(marker);
  svg.appendChild(defs);

  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute(
    "d",
    `M ${tailX} ${downY} L ${tailX} ${topY} L ${headX} ${topY} L ${headX} ${downY}`,
  );
  path.setAttribute("class", "viz-loop-path");
  path.setAttribute("marker-end", "url(#viz-loop-arrow)");
  svg.appendChild(path);
  wrap.appendChild(svg);
}

function renderLinearWithHeadTail(state, circular, hint) {
  const items = state.items || [];
  if (!items.length) {
    return '<p class="viz-empty">Estructura vacia.</p>';
  }

  let html = `<div class="viz-row-wrap${circular ? " circular-wrap" : ""}">`;
  if (circular) {
    html += '<span class="viz-pointer head">HEAD</span>';
    html += '<span class="viz-pointer tail">COLA</span>';
  } else {
    html += '<div class="viz-row-label head">HEAD</div>';
  }
  html += '<div class="viz-row">';

  items.forEach((item, index) => {
    const value = escapeHtml(item.value);
    const isHead = index === 0;
    const isTail = index === items.length - 1;

    const badges = [];
    if (isHead && !circular) {
      badges.push('<span class="viz-badge ok">N</span>');
    }
    if (hint && hint.operation === "insertar_final" && isTail) {
      badges.push('<span class="viz-badge new">NEW</span>');
    }
    html += `<div class="viz-node${isHead ? " is-head" : ""}">${value}${badges.join("")}</div>`;
    if (!isTail) {
      html += '<div class="viz-arrow">&rarr;</div>';
    }
  });

  if (!circular) {
    html += '<div class="viz-arrow">&rarr;</div><div class="viz-row-label null">NULL</div>';
  }
  html += "</div>";
  if (circular && items.length > 1) {
    html += '<div class="viz-loop-host"></div>';
  }
  html += "</div>";
  return html;
}

function renderQueue(state, hint) {
  const items = state.items || [];
  if (!items.length) {
    return '<p class="viz-empty">Cola vacia.</p>';
  }

  let html = '<div class="viz-row-wrap queue-wrap"><div class="viz-row-label front">FRONT</div><div class="viz-row">';
  items.forEach((item, index) => {
    const isFront = index === 0;
    const isBack = index === items.length - 1;
    let className = "";
    if (isFront || isBack) {
      className = " is-end";
    }
    let badge = "";
    if (hint && hint.operation === "encolar" && isBack) {
      badge = '<span class="viz-badge new">NEW</span>';
    }
    html += nodeBox(escapeHtml(item.value) + badge, { className });
    if (!isBack) {
      html += '<div class="viz-arrow">&rarr;</div>';
    }
  });
  html += '</div><div class="viz-row-tail"><span class="viz-row-label back">BACK</span></div>';
  if (hint && hint.operation === "desencolar" && hint.result) {
    html += `<div class="viz-out">OUT: ${escapeHtml(hint.result)}</div>`;
  }
  html += "</div>";
  return html;
}

function renderPriorityQueue(state, hint) {
  const items = state.items || [];
  if (!items.length) {
    return '<p class="viz-empty">Cola de prioridad vacia.</p>';
  }

  let html = '<div class="viz-row">';
  items.forEach((item, index) => {
    const content = `V:${escapeHtml(item.value)}<br>P:${escapeHtml(item.priority)}`;
    let className = "";
    let badge = "";
    if (index === 0) {
      className = " is-out";
      badge = '<span class="viz-badge out">OUT</span>';
    }
    html += nodeBox(content + badge, { className });
    if (index < items.length - 1) {
      html += '<div class="viz-arrow">&rarr;</div>';
    }
  });
  html += "</div>";
  if (hint && hint.operation === "desencolar" && hint.result) {
    html += `<div class="viz-out">Atendido: ${escapeHtml(hint.result)}</div>`;
  }
  return html;
}

function renderStack(state, hint) {
  const items = state.items || [];
  if (!items.length) {
    return '<p class="viz-empty">Pila vacia.</p>';
  }

  let html = '<div class="viz-stack-wrap"><div class="viz-row-label top">TOPE</div><div class="viz-stack">';
  items.forEach((item, index) => {
    const isTop = index === 0;
    const value = escapeHtml(item.value);
    let className = isTop ? " is-top" : "";
    let badge = "";
    if (isTop) {
      badge = '<span class="viz-badge new">NEW</span>';
      if (hint && hint.operation === "desapilar") {
        badge = "";
      }
    }
    html += nodeBox(value + badge, { className });
  });
  html += "</div>";
  if (hint && hint.operation === "desapilar" && hint.result) {
    html += `<div class="viz-out">OUT: ${escapeHtml(hint.result)}</div>`;
  }
  html += "</div>";
  return html;
}

function renderSublist(state) {
  const items = state.items || [];
  if (!items.length) {
    return '<p class="viz-empty">No hay padres en la sublista.</p>';
  }

  const nodeW = 96;
  const nodeH = 42;
  const rowGap = 24;
  const startX = 10;
  const startY = 36;
  const subStartX = 130;
  const arrowGap = 20;
  const nullGap = 44;
  const fontNode = 24;
  const fontLabel = 18;

  let maxX = subStartX + 80;

  items.forEach((item) => {
    const childCount = (item.children || []).length;
    if (childCount > 0) {
      const right =
        subStartX +
        childCount * nodeW +
        (childCount - 1) * arrowGap +
        arrowGap +
        nullGap;
      maxX = Math.max(maxX, right);
    } else {
      maxX = Math.max(maxX, subStartX + 190);
    }
  });

  const width = Math.max(520, maxX + 20);
  const height = startY + items.length * (nodeH + rowGap) + 26;

  let svg = `<svg class="viz-sub-svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">`;
  svg += `<text x="${startX}" y="${startY - 10}" class="viz-svg-label">HEAD</text>`;

  items.forEach((item, index) => {
    const y = startY + index * (nodeH + rowGap);
    const parent = escapeHtml(item.parent);
    const children = item.children || [];
    const hasChildren = children.length > 0;

    svg += `<rect x="${startX}" y="${y}" width="${nodeW}" height="${nodeH}" rx="6" ry="6" class="viz-svg-node${hasChildren ? " has-children" : ""}" />`;
    svg += `<text x="${startX + 14}" y="${y + fontNode}" class="viz-svg-node-text">${parent}</text>`;

    if (index < items.length - 1) {
      const downX = startX + nodeW / 2;
      const downY = y + nodeH + 14;
      svg += `<text x="${downX}" y="${downY}" text-anchor="middle" class="viz-svg-arrow">↓</text>`;
    } else {
      const nullX = startX + nodeW / 2;
      const nullY = y + nodeH + 24;
      svg += `<text x="${nullX}" y="${nullY}" text-anchor="middle" class="viz-svg-null">NULL</text>`;
    }

    svg += `<text x="${startX + nodeW + 8}" y="${y + fontLabel}" class="viz-svg-arrow">→</text>`;

    if (children.length > 0) {
      let childX = subStartX;
      children.forEach((child, childIndex) => {
        const childValue = escapeHtml(child);
        svg += `<rect x="${childX}" y="${y}" width="${nodeW}" height="${nodeH}" rx="6" ry="6" class="viz-svg-node" />`;
        svg += `<text x="${childX + 14}" y="${y + fontNode}" class="viz-svg-node-text">${childValue}</text>`;

        if (childIndex < children.length - 1) {
          svg += `<text x="${childX + nodeW + 8}" y="${y + fontLabel}" class="viz-svg-arrow">→</text>`;
          childX += nodeW + arrowGap;
        } else {
          const nullX = childX + nodeW + 14;
          svg += `<text x="${nullX}" y="${y + fontLabel}" class="viz-svg-arrow">→</text>`;
          svg += `<text x="${nullX + 18}" y="${y + fontLabel}" class="viz-svg-null">NULL</text>`;
        }
      });
    } else {
      const textX = subStartX;
      svg += `<text x="${textX}" y="${y + fontLabel}" class="viz-svg-empty">(sin hijos)</text>`;
      svg += `<text x="${textX + 122}" y="${y + fontLabel}" class="viz-svg-arrow">→</text>`;
      svg += `<text x="${textX + 142}" y="${y + fontLabel}" class="viz-svg-null">NULL</text>`;
    }
  });

  svg += "</svg>";
  return `<div class="viz-sub-svg-wrap">${svg}</div>`;
}

function renderVisualState(structureId, state, container, hint) {
  if (!state || !container) {
    return;
  }

  let inner = `<div class="viz-meta"><strong>${escapeHtml(state.title || "Estado")}</strong> | Tamano: ${escapeHtml(state.size ?? 0)}</div>`;

  if (structureId === "stack") {
    inner += renderStack(state, hint);
  } else if (structureId === "queue") {
    inner += renderQueue(state, hint);
  } else if (structureId === "priority_queue") {
    inner += renderPriorityQueue(state, hint);
  } else if (structureId === "linked_list") {
    inner += renderLinearWithHeadTail(state, false, hint);
  } else if (structureId === "circular_list") {
    inner += renderLinearWithHeadTail(state, true, hint);
  } else if (structureId === "sublist") {
    inner += renderSublist(state);
  } else {
    inner += '<p class="viz-empty">Tipo de visualizacion no soportado.</p>';
  }

  container.innerHTML = `<div class="viz-canvas"><div class="viz-stage">${inner}</div></div>`;
  if (structureId === "circular_list") {
    requestAnimationFrame(() => {
      drawCircularLoop(container);
    });
  }
}

function showMessage(text, success) {
  const box = byId("message-box");
  if (!box) {
    return;
  }
  box.textContent = text || "";
  box.className = success ? "message ok" : "message error";
}

function updateDidacticPanel(model, operationName) {
  const recordBox = byId("tad-record");
  const pseudoTitle = byId("op-pseudocode-title");
  const pseudoBox = byId("op-pseudocode");
  if (!recordBox || !pseudoTitle || !pseudoBox) {
    return;
  }

  const didactic = model && model.didactic ? model.didactic : {};
  const opMap = didactic.operations || {};
  const fallback = didactic.default_operation || "Seudocodigo no disponible para esta operacion.";
  const selectedOp = operationName || "";
  const selectedMeta = (model.operations || []).find((item) => item.name === selectedOp);
  const selectedLabel = selectedMeta ? selectedMeta.label : selectedOp;

  recordBox.textContent = didactic.record || "Estructura no documentada.";
  pseudoTitle.textContent = selectedLabel ? `Seudocodigo: ${selectedLabel}` : "Seudocodigo";
  pseudoBox.textContent = opMap[selectedOp] || fallback;
}

function summarizePayload(payload) {
  if (!payload || typeof payload !== "object") {
    return "";
  }
  const parts = Object.entries(payload)
    .filter(([, value]) => String(value).trim() !== "")
    .map(([key, value]) => `${key}=${value}`);
  return parts.join(", ");
}

function extractSubroutineName(pseudoCode, fallback) {
  if (!pseudoCode) {
    return fallback;
  }
  const firstLine = String(pseudoCode).split("\n").find((line) => String(line).trim()) || "";
  const match = firstLine.match(/(?:SubProceso|Funcion|Procedimiento|Proceso)\s+([A-Za-z_][A-Za-z0-9_]*)/i);
  if (match && match[1]) {
    return match[1];
  }
  return fallback;
}

function getSubroutineName(model, operationName, fallback) {
  const didactic = model && model.didactic ? model.didactic : {};
  const opMap = didactic.operations || {};
  const pseudoCode = opMap[operationName] || "";
  return extractSubroutineName(pseudoCode, fallback || operationName || "Operacion");
}

function createHistoryEntry(subroutine, payloadText, resultText) {
  return {
    subroutine: subroutine || "Operacion",
    payload: payloadText || "-",
    result: resultText || "-",
  };
}

function renderActionHistory(history, container) {
  if (!container) {
    return;
  }
  if (!history.length) {
    container.innerHTML = "<li class=\"didactic-history-item empty\">Sin acciones ejecutadas.</li>";
    return;
  }
  container.innerHTML = history
    .map((item, index) => {
      if (typeof item === "string") {
        return (
          "<li class=\"didactic-history-item\">" +
          `<div class="didactic-history-head">Paso ${index + 1}: Historial</div>` +
          `<div class="didactic-history-line"><span class="k">Salida:</span> ${escapeHtml(item)}</div>` +
          "</li>"
        );
      }
      return (
        "<li class=\"didactic-history-item\">" +
        `<div class="didactic-history-head">Paso ${index + 1}: ${escapeHtml(item.subroutine || "Operacion")}</div>` +
        `<div class="didactic-history-line"><span class="k">Entrada:</span> ${escapeHtml(item.payload || "-")}</div>` +
        `<div class="didactic-history-line"><span class="k">Salida:</span> ${escapeHtml(item.result || "-")}</div>` +
        "</li>"
      );
    })
    .join("");
}

function initStructurePage(model) {
  const form = byId("operation-form");
  const operationSelect = byId("operation-select");
  const inputsContainer = byId("operation-inputs");
  const resetButton = byId("reset-button");
  const visualContainer = byId("visual-state");
  const historyBox = byId("action-history");

  if (!form || !operationSelect || !inputsContainer || !visualContainer) {
    return;
  }

  const operations = model.operations || [];
  let selected = operations[0] || null;
  const operationLabel = new Map(operations.map((op) => [op.name, op.label]));
  const actionHistory = [];

  operations.forEach((operation) => {
    const option = document.createElement("option");
    option.value = operation.name;
    option.textContent = operation.label;
    operationSelect.appendChild(option);
  });

  renderOperationInputs(selected, inputsContainer);
  updateDidacticPanel(model, selected ? selected.name : "");
  renderVisualState(model.id, model.visual_state, visualContainer, null);

  (model.history || []).forEach((step) => {
    const opName = String(step.operation || "");
    const label = operationLabel.get(opName) || opName;
    const subroutine = getSubroutineName(model, opName, label);
    const payloadText = summarizePayload(step.payload || {});
    actionHistory.push(createHistoryEntry(subroutine, payloadText || "-", "Operacion aplicada."));
  });
  renderActionHistory(actionHistory, historyBox);

  operationSelect.addEventListener("change", () => {
    selected = operations.find((item) => item.name === operationSelect.value) || null;
    renderOperationInputs(selected, inputsContainer);
    updateDidacticPanel(model, selected ? selected.name : "");
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const current = operations.find((item) => item.name === operationSelect.value);
    if (!current) {
      showMessage("Debes seleccionar una operacion valida.", false);
      return;
    }

    const payload = {};
    current.inputs.forEach((field) => {
      const element = byId(`field-${field.name}`);
      payload[field.name] = element ? element.value : "";
    });

    const response = await fetch(form.dataset.operateUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ operation: current.name, payload }),
    });
    const data = await response.json();
    showMessage(data.message, Boolean(data.success));
    updateDidacticPanel(model, current.name);
    const payloadText = summarizePayload(payload);
    const subroutine = getSubroutineName(model, current.name, current.label);
    actionHistory.push(createHistoryEntry(subroutine, payloadText || "-", data.message));
    renderActionHistory(actionHistory, historyBox);
    if (data.visual_state) {
      renderVisualState(model.id, data.visual_state, visualContainer, {
        operation: current.name,
        payload,
        result: data.result,
      });
    }
  });

  resetButton?.addEventListener("click", async () => {
    const response = await fetch(form.dataset.resetUrl, { method: "POST" });
    const data = await response.json();
    showMessage(data.message, Boolean(data.success));
    updateDidacticPanel(model, selected ? selected.name : "");
    actionHistory.length = 0;
    renderActionHistory(actionHistory, historyBox);
    if (data.visual_state) {
      renderVisualState(model.id, data.visual_state, visualContainer, null);
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  if (window.SEQ_VIEW_MODEL) {
    initStructurePage(window.SEQ_VIEW_MODEL);
  }
});
