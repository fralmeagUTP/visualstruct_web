"""Routes for didactic help pages."""

from __future__ import annotations

from flask import Blueprint, render_template

from app.services.hash_help_service import HashHelpService
from app.services.hash_structure_service import HashStructureService
from app.services.graph_help_service import GraphHelpService
from app.services.graph_structure_service import GraphStructureService
from app.services.hierarchical_help_service import HierarchicalHelpService
from app.services.hierarchical_structure_service import HierarchicalStructureService
from app.services.help_service import HelpService
from app.services.structure_service import StructureService

help_bp = Blueprint("help", __name__, url_prefix="/help")


@help_bp.get("/sequential")
def sequential_help() -> str:
    """Render sequential module help page."""
    module_help = HelpService.get_module_help()
    structures = StructureService.list_structures()
    return render_template("help/sequential.html", module_help=module_help, structures=structures)


@help_bp.get("/sequential/<structure_id>")
def structure_help(structure_id: str) -> str:
    """Render a specific structure help page."""
    data = HelpService.get_structure_help(structure_id)
    return render_template("help/structure.html", help_data=data, structure_id=structure_id)


@help_bp.get("/hierarchical")
def hierarchical_help() -> str:
    """Render hierarchical module help page."""
    module_help = HierarchicalHelpService.get_module_help()
    structures = HierarchicalStructureService.list_structures()
    return render_template("help/hierarchical.html", module_help=module_help, structures=structures)


@help_bp.get("/hierarchical/<structure_id>")
def hierarchical_structure_help(structure_id: str) -> str:
    """Render one hierarchical structure help page."""
    data = HierarchicalHelpService.get_structure_help(structure_id)
    return render_template(
        "help/hierarchical_structure.html",
        help_data=data,
        structure_id=structure_id,
    )


@help_bp.get("/graph")
def graph_help() -> str:
    """Render graph module help page."""
    module_help = GraphHelpService.get_module_help()
    structures = GraphStructureService.list_structures()
    return render_template("help/graph.html", module_help=module_help, structures=structures)


@help_bp.get("/graph/<structure_id>")
def graph_structure_help(structure_id: str) -> str:
    """Render one graph structure help page."""
    data = GraphHelpService.get_structure_help(structure_id)
    return render_template(
        "help/graph_structure.html",
        help_data=data,
        structure_id=structure_id,
    )


@help_bp.get("/hash")
def hash_help() -> str:
    """Render hash module help page."""
    module_help = HashHelpService.get_module_help()
    structures = HashStructureService.list_structures()
    return render_template("help/hash.html", module_help=module_help, structures=structures)


@help_bp.get("/hash/<structure_id>")
def hash_structure_help(structure_id: str) -> str:
    """Render one hash structure help page."""
    data = HashHelpService.get_structure_help(structure_id)
    return render_template(
        "help/hash_structure.html",
        help_data=data,
        structure_id=structure_id,
    )
