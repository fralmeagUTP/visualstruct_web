"""Integration tests for Flask routes."""

from __future__ import annotations


def test_homepage_loads(client) -> None:
    """Home page should return 200."""
    response = client.get("/")
    assert response.status_code == 200
    assert "Visualizador Web de Estructuras de Datos".encode("utf-8") in response.data


def test_sequential_index_loads(client) -> None:
    """Sequential index should return cards."""
    response = client.get("/sequential/")
    assert response.status_code == 200
    assert "Módulo de Estructuras Secuenciales".encode("utf-8") in response.data


def test_structure_page_loads(client) -> None:
    """Each structure page should load."""
    response = client.get("/sequential/stack")
    assert response.status_code == 200
    assert "Pila".encode("utf-8") in response.data


def test_operate_stack_success(client) -> None:
    """Stack operation endpoint should mutate state."""
    response = client.post(
        "/sequential/stack/operate",
        json={"operation": "apilar", "payload": {"value": "10"}},
    )
    assert response.status_code == 200
    data = response.get_json()
    assert data["success"] is True
    assert data["visual_state"]["size"] == 1


def test_operate_stack_empty_error(client) -> None:
    """Empty stack pop should return didactic error."""
    response = client.post(
        "/sequential/stack/operate",
        json={"operation": "desapilar", "payload": {}},
    )
    assert response.status_code == 400
    data = response.get_json()
    assert data["success"] is False
    assert "vacía" in data["message"]
