"use strict";

function hById(id) {
  return document.getElementById(id);
}

function hEscape(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function buildOperationInputs(operation, container) {
  container.innerHTML = "";
  if (!operation || !operation.inputs) {
    return;
  }

  operation.inputs.forEach((field) => {
    const wrap = document.createElement("div");
    const label = document.createElement("label");
    label.textContent = field.label;
    label.setAttribute("for", `h-field-${field.name}`);

    const input = document.createElement("input");
    input.id = `h-field-${field.name}`;
    input.name = field.name;
    input.type = field.type === "number" ? "number" : "text";
    input.required = field.required !== false;

    wrap.appendChild(label);
    wrap.appendChild(input);
    container.appendChild(wrap);
  });
}

function flattenTree(root) {
  if (!root) {
    return [];
  }

  const nodes = [];
  let cursor = 0;

  function walk(node, depth, parentKey) {
    if (!node) {
      return null;
    }

    const leftKey = walk(node.left, depth + 1, node.heap_index !== undefined ? `idx-${node.heap_index}` : String(node.value));
    const key = node.heap_index !== undefined ? `idx-${node.heap_index}` : String(node.value);
    const id = `n-${cursor}`;
    cursor += 1;

    const leftHeight = node.left && node.left.height !== undefined && node.left.height !== null ? Number(node.left.height) : 0;
    const rightHeight = node.right && node.right.height !== undefined && node.right.height !== null ? Number(node.right.height) : 0;
    const inferredBalance = leftHeight - rightHeight;

    const currentNode = {
      id,
      key,
      value: node.value,
      x: cursor * 88,
      y: depth * 86 + 48,
      color: node.color || null,
      height: node.height ?? null,
      balanceFactor: node.balance_factor ?? inferredBalance,
      leftKey,
      rightKey: null,
      parentKey,
    };

    nodes.push(currentNode);
    currentNode.rightKey = walk(node.right, depth + 1, key);
    return key;
  }

  walk(root, 0, null);
  return nodes;
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function isSearchLikeStructure(modelId) {
  return modelId === "abb" || modelId === "avl" || modelId === "red_black";
}

function normalizeCompareValue(rawValue) {
  if (rawValue === null || rawValue === undefined) {
    return null;
  }
  const text = String(rawValue).trim();
  if (!text) {
    return null;
  }
  const asNumber = Number(text);
  if (Number.isFinite(asNumber)) {
    return asNumber;
  }
  return text;
}

function buildComparisonPath(root, targetValue) {
  const pathKeys = [];
  let current = root;
  let found = false;

  while (current) {
    const key = String(current.value);
    pathKeys.push(key);
    if (targetValue === current.value) {
      found = true;
      break;
    }
    current = targetValue < current.value ? current.left : current.right;
  }

  return {
    pathKeys,
    found,
  };
}

function getNodeHeightForInference(node) {
  if (!node) {
    return 0;
  }
  if (node.height !== null && node.height !== undefined) {
    return Number(node.height);
  }
  const leftHeight = getNodeHeightForInference(node.left);
  const rightHeight = getNodeHeightForInference(node.right);
  return 1 + Math.max(leftHeight, rightHeight);
}

function inferAvlInsertionRotation(root, insertedValue) {
  let detected = null;

  function walk(node) {
    if (!node) {
      return { height: 1, inserted: true };
    }

    if (insertedValue === node.value) {
      return { height: getNodeHeightForInference(node), inserted: false };
    }

    let leftHeight = getNodeHeightForInference(node.left);
    let rightHeight = getNodeHeightForInference(node.right);
    let inserted = false;

    if (insertedValue < node.value) {
      const leftResult = walk(node.left);
      inserted = leftResult.inserted;
      leftHeight = leftResult.height;
    } else {
      const rightResult = walk(node.right);
      inserted = rightResult.inserted;
      rightHeight = rightResult.height;
    }

    const balance = leftHeight - rightHeight;
    if (!detected && inserted && (balance > 1 || balance < -1)) {
      if (balance > 1) {
        const childValue = node.left ? node.left.value : insertedValue;
        detected = {
          type: insertedValue < childValue ? "LL" : "LR",
          pivot: String(node.value),
          child: String(childValue),
          inserted: String(insertedValue),
        };
      } else {
        const childValue = node.right ? node.right.value : insertedValue;
        detected = {
          type: insertedValue > childValue ? "RR" : "RL",
          pivot: String(node.value),
          child: String(childValue),
          inserted: String(insertedValue),
        };
      }
    }

    return {
      height: 1 + Math.max(leftHeight, rightHeight),
      inserted,
    };
  }

  walk(root);
  return detected;
}

function inferAvlDeletionRotation(root, deletedValue) {
  if (!root) {
    return null;
  }

  let detected = null;

  function infoFromNode(node) {
    if (!node) {
      return {
        height: 0,
        leftHeight: 0,
        rightHeight: 0,
        deleted: false,
      };
    }
    const leftHeight = getNodeHeightForInference(node.left);
    const rightHeight = getNodeHeightForInference(node.right);
    return {
      height: 1 + Math.max(leftHeight, rightHeight),
      leftHeight,
      rightHeight,
      deleted: false,
    };
  }

  function composeInfo(node, leftInfo, rightInfo, deleted) {
    const leftHeight = leftInfo.height;
    const rightHeight = rightInfo.height;
    const balance = leftHeight - rightHeight;

    if (!detected && deleted && (balance > 1 || balance < -1)) {
      if (balance > 1) {
        const childBalance = leftInfo.leftHeight - leftInfo.rightHeight;
        detected = {
          type: childBalance >= 0 ? "LL" : "LR",
          pivot: String(node.value),
          child: node.left ? String(node.left.value) : "",
          affected: String(deletedValue),
        };
      } else {
        const childBalance = rightInfo.leftHeight - rightInfo.rightHeight;
        detected = {
          type: childBalance <= 0 ? "RR" : "RL",
          pivot: String(node.value),
          child: node.right ? String(node.right.value) : "",
          affected: String(deletedValue),
        };
      }
    }

    return {
      height: 1 + Math.max(leftHeight, rightHeight),
      leftHeight,
      rightHeight,
      deleted,
    };
  }

  function deleteMin(node) {
    if (!node) {
      return {
        height: 0,
        leftHeight: 0,
        rightHeight: 0,
        deleted: false,
      };
    }

    if (!node.left) {
      const rightInfo = infoFromNode(node.right);
      return {
        height: rightInfo.height,
        leftHeight: rightInfo.leftHeight,
        rightHeight: rightInfo.rightHeight,
        deleted: true,
      };
    }

    const leftInfo = deleteMin(node.left);
    const rightInfo = infoFromNode(node.right);
    return composeInfo(node, leftInfo, rightInfo, leftInfo.deleted);
  }

  function walk(node) {
    if (!node) {
      return {
        height: 0,
        leftHeight: 0,
        rightHeight: 0,
        deleted: false,
      };
    }

    if (deletedValue < node.value) {
      const leftInfo = walk(node.left);
      if (!leftInfo.deleted) {
        return infoFromNode(node);
      }
      const rightInfo = infoFromNode(node.right);
      return composeInfo(node, leftInfo, rightInfo, true);
    }

    if (deletedValue > node.value) {
      const rightInfo = walk(node.right);
      if (!rightInfo.deleted) {
        return infoFromNode(node);
      }
      const leftInfo = infoFromNode(node.left);
      return composeInfo(node, leftInfo, rightInfo, true);
    }

    if (!node.left && !node.right) {
      return {
        height: 0,
        leftHeight: 0,
        rightHeight: 0,
        deleted: true,
      };
    }

    if (!node.left) {
      const rightInfo = infoFromNode(node.right);
      return {
        height: rightInfo.height,
        leftHeight: rightInfo.leftHeight,
        rightHeight: rightInfo.rightHeight,
        deleted: true,
      };
    }

    if (!node.right) {
      const leftInfo = infoFromNode(node.left);
      return {
        height: leftInfo.height,
        leftHeight: leftInfo.leftHeight,
        rightHeight: leftInfo.rightHeight,
        deleted: true,
      };
    }

    const leftInfo = infoFromNode(node.left);
    const rightInfo = deleteMin(node.right);
    return composeInfo(node, leftInfo, rightInfo, true);
  }

  walk(root);
  return detected;
}

function comparisonHighlight(compareState) {
  const highlights = {
    visitedKeys: new Set(),
    activeKeys: new Set(),
  };

  if (!compareState) {
    return highlights;
  }

  if (Array.isArray(compareState.activeKeys)) {
    compareState.activeKeys.forEach((key) => {
      highlights.activeKeys.add(String(key));
    });
  }

  if (Array.isArray(compareState.pathKeys) && compareState.index >= 0) {
    const maxIndex = Math.min(compareState.index, compareState.pathKeys.length - 1);
    for (let i = 0; i <= maxIndex; i += 1) {
      const key = String(compareState.pathKeys[i]);
      highlights.visitedKeys.add(key);
      if (i === maxIndex) {
        highlights.activeKeys.add(key);
      }
    }
  }

  return highlights;
}

function getRotationNodeClass(nodeKey, rotationHint) {
  if (!rotationHint || !nodeKey) {
    return "";
  }

  const pivot = String(rotationHint.pivot || "");
  const child = String(rotationHint.child || "");
  const inserted = String(rotationHint.inserted || rotationHint.affected || "");
  const type = String(rotationHint.type || "");

  if (type === "LL") {
    if (nodeKey === pivot) {
      return " rot-cw";
    }
    if (nodeKey === child || nodeKey === inserted) {
      return " rot-ccw";
    }
  }
  if (type === "RR") {
    if (nodeKey === pivot) {
      return " rot-ccw";
    }
    if (nodeKey === child || nodeKey === inserted) {
      return " rot-cw";
    }
  }
  if (type === "LR") {
    if (nodeKey === pivot) {
      return " rot-cw";
    }
    if (nodeKey === child || nodeKey === inserted) {
      return " rot-ccw";
    }
  }
  if (type === "RL") {
    if (nodeKey === pivot) {
      return " rot-ccw";
    }
    if (nodeKey === child || nodeKey === inserted) {
      return " rot-cw";
    }
  }

  return "";
}

function rotationHintText(rotationHint) {
  if (!rotationHint) {
    return "";
  }
  const type = String(rotationHint.type || "");
  const pivot = String(rotationHint.pivot || "");
  const child = String(rotationHint.child || "");

  if (type === "LL") {
    return `Rotacion AVL LL: rotacion a la derecha en ${pivot}.`;
  }
  if (type === "RR") {
    return `Rotacion AVL RR: rotacion a la izquierda en ${pivot}.`;
  }
  if (type === "LR") {
    return `Rotacion AVL LR: izquierda en ${child} y luego derecha en ${pivot}.`;
  }
  if (type === "RL") {
    return `Rotacion AVL RL: derecha en ${child} y luego izquierda en ${pivot}.`;
  }
  return "Rotacion AVL detectada.";
}

function drawTreeSvgFromNodes(nodes, options = {}) {
  if (!nodes.length) {
    return "<p class=\"viz-empty\">Estructura vacia.</p>";
  }

  const nodeMap = new Map(nodes.map((node) => [node.key, node]));
  let maxX = 0;
  let maxY = 0;
  nodes.forEach((node) => {
    maxX = Math.max(maxX, node.x);
    maxY = Math.max(maxY, node.y);
  });

  const compare = comparisonHighlight(options.compareState);

  let svg = `<svg class="viz-tree-svg" width="${maxX + 90}" height="${maxY + 70}" viewBox="0 0 ${maxX + 90} ${maxY + 70}" xmlns="http://www.w3.org/2000/svg">`;

  nodes.forEach((node) => {
    if (node.leftKey && nodeMap.has(node.leftKey)) {
      const left = nodeMap.get(node.leftKey);
      svg += `<line x1="${node.x}" y1="${node.y + 18}" x2="${left.x}" y2="${left.y - 18}" class="viz-tree-edge" />`;
    }
    if (node.rightKey && nodeMap.has(node.rightKey)) {
      const right = nodeMap.get(node.rightKey);
      svg += `<line x1="${node.x}" y1="${node.y + 18}" x2="${right.x}" y2="${right.y - 18}" class="viz-tree-edge" />`;
    }
  });

  nodes.forEach((node) => {
    let nodeClass = "viz-tree-node";
    if (node.color === "RED") {
      nodeClass += " red";
    }
    if (node.color === "BLACK") {
      nodeClass += " black";
    }
    if (compare.visitedKeys.has(node.key)) {
      nodeClass += " sim-visited";
    }
    if (compare.activeKeys.has(node.key)) {
      nodeClass += " sim-active";
    }
    nodeClass += getRotationNodeClass(node.key, options.rotationHint);

    svg += `<circle cx="${node.x}" cy="${node.y}" r="24" class="${nodeClass}" />`;
    svg += `<text x="${node.x}" y="${node.y + 6}" text-anchor="middle" class="viz-tree-text">${hEscape(node.value)}</text>`;

    if (options.showBalanceFactor) {
      const feClass = node.balanceFactor >= -1 && node.balanceFactor <= 1 ? "viz-tree-fe ok" : "viz-tree-fe bad";
      svg += `<text x="${node.x + 25}" y="${node.y - 18}" class="${feClass}">fe:${hEscape(node.balanceFactor)}</text>`;
    } else if (node.height !== null && node.height !== undefined) {
      svg += `<text x="${node.x + 20}" y="${node.y - 18}" class="viz-tree-height">h:${hEscape(node.height)}</text>`;
    }
  });

  svg += "</svg>";
  return svg;
}

function buildTransitionData(previousRoot, nextRoot) {
  const fromNodes = flattenTree(previousRoot);
  const toNodes = flattenTree(nextRoot);
  if (!fromNodes.length || !toNodes.length) {
    return null;
  }

  const fromMap = new Map(fromNodes.map((node) => [node.key, node]));
  const toMap = new Map(toNodes.map((node) => [node.key, node]));
  const keys = new Set([...fromMap.keys(), ...toMap.keys()]);

  const items = [];
  keys.forEach((key) => {
    const from = fromMap.get(key) || null;
    const to = toMap.get(key) || null;

    const startX = from ? from.x : (to ? to.x : 0);
    const startY = from ? from.y : (to ? to.y - 46 : 0);
    const endX = to ? to.x : (from ? from.x : 0);
    const endY = to ? to.y : (from ? from.y - 46 : 0);

    items.push({
      key,
      value: to ? to.value : from.value,
      colorFrom: from ? from.color : null,
      colorTo: to ? to.color : null,
      heightFrom: from ? from.height : null,
      heightTo: to ? to.height : null,
      balanceFrom: from ? from.balanceFactor : null,
      balanceTo: to ? to.balanceFactor : null,
      startX,
      startY,
      endX,
      endY,
      startOpacity: from ? 1 : 0,
      endOpacity: to ? 1 : 0,
      leftKey: to ? to.leftKey : null,
      rightKey: to ? to.rightKey : null,
      existsInTarget: Boolean(to),
    });
  });

  return {
    progress: 0,
    items,
  };
}

function renderTreeTransitionSvg(transitionData, options = {}) {
  const p = Math.max(0, Math.min(1, transitionData.progress));
  const interpolatedNodes = transitionData.items.map((item) => {
    const x = item.startX + (item.endX - item.startX) * p;
    const y = item.startY + (item.endY - item.startY) * p;
    const opacity = item.startOpacity + (item.endOpacity - item.startOpacity) * p;
    return {
      key: item.key,
      value: item.value,
      x,
      y,
      opacity,
      color: p < 0.5 ? item.colorFrom : item.colorTo,
      height: p < 0.5 ? item.heightFrom : item.heightTo,
      balanceFactor: p < 0.5 ? item.balanceFrom : item.balanceTo,
      leftKey: item.leftKey,
      rightKey: item.rightKey,
      existsInTarget: item.existsInTarget,
    };
  });

  if (!interpolatedNodes.length) {
    return "<p class=\"viz-empty\">Estructura vacia.</p>";
  }

  const nodeMap = new Map(interpolatedNodes.map((node) => [node.key, node]));
  let maxX = 0;
  let maxY = 0;
  interpolatedNodes.forEach((node) => {
    maxX = Math.max(maxX, node.x);
    maxY = Math.max(maxY, node.y);
  });

  const compare = comparisonHighlight(options.compareState);

  let svg = `<svg class="viz-tree-svg" width="${maxX + 90}" height="${maxY + 70}" viewBox="0 0 ${maxX + 90} ${maxY + 70}" xmlns="http://www.w3.org/2000/svg">`;

  interpolatedNodes.forEach((node) => {
    if (!node.existsInTarget) {
      return;
    }
    if (node.leftKey && nodeMap.has(node.leftKey)) {
      const left = nodeMap.get(node.leftKey);
      svg += `<line x1="${node.x}" y1="${node.y + 18}" x2="${left.x}" y2="${left.y - 18}" class="viz-tree-edge" />`;
    }
    if (node.rightKey && nodeMap.has(node.rightKey)) {
      const right = nodeMap.get(node.rightKey);
      svg += `<line x1="${node.x}" y1="${node.y + 18}" x2="${right.x}" y2="${right.y - 18}" class="viz-tree-edge" />`;
    }
  });

  interpolatedNodes.forEach((node) => {
    let nodeClass = "viz-tree-node";
    if (node.color === "RED") {
      nodeClass += " red";
    }
    if (node.color === "BLACK") {
      nodeClass += " black";
    }
    if (compare.visitedKeys.has(node.key)) {
      nodeClass += " sim-visited";
    }
    if (compare.activeKeys.has(node.key)) {
      nodeClass += " sim-active";
    }
    nodeClass += getRotationNodeClass(node.key, options.rotationHint);

    svg += `<circle cx="${node.x}" cy="${node.y}" r="24" class="${nodeClass}" style="opacity:${node.opacity};" />`;
    svg += `<text x="${node.x}" y="${node.y + 6}" text-anchor="middle" class="viz-tree-text" style="opacity:${node.opacity};">${hEscape(node.value)}</text>`;

    if (options.showBalanceFactor) {
      const feClass = node.balanceFactor >= -1 && node.balanceFactor <= 1 ? "viz-tree-fe ok" : "viz-tree-fe bad";
      svg += `<text x="${node.x + 25}" y="${node.y - 18}" class="${feClass}" style="opacity:${node.opacity};">fe:${hEscape(node.balanceFactor)}</text>`;
    } else if (node.height !== null && node.height !== undefined) {
      svg += `<text x="${node.x + 20}" y="${node.y - 18}" class="viz-tree-height" style="opacity:${node.opacity};">h:${hEscape(node.height)}</text>`;
    }
  });

  svg += "</svg>";
  return svg;
}

function renderHeapArray(arrayValues) {
  if (!arrayValues || !arrayValues.length) {
    return "<p class=\"viz-empty\">Arreglo vacio.</p>";
  }
  const chips = arrayValues
    .map((value, index) => `<span class="viz-array-chip">[${index}] ${hEscape(value)}</span>`)
    .join(" ");
  return `<div class="viz-array-wrap">${chips}</div>`;
}

function renderHeapArrayFrame(arrayValues, frame) {
  if (!arrayValues || !arrayValues.length) {
    return "<p class=\"viz-empty\">Arreglo vacio.</p>";
  }

  const visited = new Set(frame && Array.isArray(frame.visitedIndices) ? frame.visitedIndices : []);
  const active = new Set(frame && Array.isArray(frame.activeIndices) ? frame.activeIndices : []);

  const chips = arrayValues
    .map((value, index) => {
      let className = "viz-array-chip";
      if (visited.has(index)) {
        className += " sim-visited";
      }
      if (active.has(index)) {
        className += " sim-active";
      }
      return `<span class="${className}">[${index}] ${hEscape(value)}</span>`;
    })
    .join(" ");

  return `<div class="viz-array-wrap">${chips}</div>`;
}

function heapArrayToTreeNode(arrayValues, index = 0) {
  if (!arrayValues || index >= arrayValues.length) {
    return null;
  }
  return {
    value: arrayValues[index],
    heap_index: index,
    left: heapArrayToTreeNode(arrayValues, 2 * index + 1),
    right: heapArrayToTreeNode(arrayValues, 2 * index + 2),
  };
}

function buildHeapInsertFrames(previousArray, value) {
  if (!Number.isFinite(value)) {
    return [];
  }

  const array = [...previousArray];
  const frames = [];
  const visited = new Set();
  array.push(value);
  let current = array.length - 1;

  visited.add(current);
  frames.push({
    array: [...array],
    activeIndices: [current],
    visitedIndices: [...visited],
    note: `Se inserta ${value} al final y comienza a subir.`,
  });

  while (current > 0) {
    const parent = Math.floor((current - 1) / 2);
    visited.add(parent);
    visited.add(current);
    if (array[parent] <= array[current]) {
      frames.push({
        array: [...array],
        activeIndices: [parent, current],
        visitedIndices: [...visited],
        note: `Comparacion final: ${array[parent]} <= ${array[current]}.`,
      });
      break;
    }
    const oldParent = array[parent];
    const oldCurrent = array[current];
    [array[parent], array[current]] = [array[current], array[parent]];
    frames.push({
      array: [...array],
      activeIndices: [parent, current],
      visitedIndices: [...visited],
      note: `Intercambio ${oldParent} <-> ${oldCurrent}.`,
    });
    current = parent;
  }

  return frames;
}

function buildHeapExtractFrames(previousArray) {
  const array = [...previousArray];
  if (!array.length) {
    return [];
  }

  const frames = [];
  const visited = new Set([0]);
  const extracted = array[0];

  if (array.length === 1) {
    frames.push({
      array: [],
      activeIndices: [],
      visitedIndices: [0],
      note: `Se extrae la raiz ${extracted}. El monticulo queda vacio.`,
    });
    return frames;
  }

  const last = array.pop();
  array[0] = last;
  frames.push({
    array: [...array],
    activeIndices: [0],
    visitedIndices: [0],
    note: `Se extrae la raiz ${extracted}. El ultimo valor ${last} sube a la raiz.`,
  });

  let current = 0;
  while (true) {
    const left = 2 * current + 1;
    const right = 2 * current + 2;
    let smallest = current;

    if (left < array.length && array[left] < array[smallest]) {
      smallest = left;
    }
    if (right < array.length && array[right] < array[smallest]) {
      smallest = right;
    }

    if (smallest === current) {
      frames.push({
        array: [...array],
        activeIndices: [current],
        visitedIndices: [...visited],
        note: "La propiedad de min-heap ya se cumple.",
      });
      break;
    }

    visited.add(smallest);
    const oldCurrent = array[current];
    const oldSmallest = array[smallest];
    [array[current], array[smallest]] = [array[smallest], array[current]];
    frames.push({
      array: [...array],
      activeIndices: [current, smallest],
      visitedIndices: [...visited],
      note: `Intercambio ${oldCurrent} <-> ${oldSmallest} para restaurar el heap.`,
    });
    current = smallest;
  }

  return frames;
}

function buildHeapOperationFrames(operationName, payload, previousArray) {
  if (!Array.isArray(previousArray)) {
    return [];
  }
  if (operationName === "insertar") {
    const rawValue = payload && payload.value !== undefined ? payload.value : null;
    const value = Number(rawValue);
    return buildHeapInsertFrames(previousArray, value);
  }
  if (operationName === "extraer_raiz") {
    return buildHeapExtractFrames(previousArray);
  }
  return [];
}

function formatHierResult(lastExecution) {
  if (!lastExecution || lastExecution.result === undefined) {
    return "";
  }

  const result = lastExecution.result;
  if (Array.isArray(result)) {
    return `<p><strong>Resultado:</strong> ${hEscape(result.join(" -> "))}</p>`;
  }
  if (typeof result === "boolean") {
    return `<p><strong>Resultado:</strong> ${result ? "Verdadero" : "Falso"}</p>`;
  }
  if (result === null) {
    return "";
  }
  return `<p><strong>Resultado:</strong> ${hEscape(JSON.stringify(result))}</p>`;
}

function renderHierState(
  modelId,
  state,
  container,
  lastExecution,
  transitionData,
  compareState,
  rotationVisualHint,
  rotationTextHint,
  heapFrame,
) {
  if (!state || !container) {
    return;
  }

  const treeOptions = {
    showBalanceFactor: modelId === "avl",
    compareState,
    rotationHint: rotationVisualHint,
  };

  let html = `<div class="viz-canvas"><div class="viz-meta"><strong>${hEscape(state.title)}</strong> | Tamano: ${hEscape(state.size ?? 0)}</div>`;

  if (typeof state.validation === "boolean") {
    html += `<div class="viz-validation">Validacion: ${state.validation ? "OK" : "ERROR"}</div>`;
  }
  if (modelId === "avl") {
    html += "<div class=\"viz-meta\">Regla AVL: cada nodo debe tener fe en {-1, 0, 1}.</div>";
    const rotationText = rotationHintText(rotationTextHint);
    if (rotationText) {
      html += `<div class="viz-rotation-note">${hEscape(rotationText)}</div>`;
    }
  }

  if (modelId === "binary_heap" || state.kind === "heap") {
    const heapArray = heapFrame && Array.isArray(heapFrame.array) ? heapFrame.array : (state.array || []);
    const heapRoot = heapArrayToTreeNode(heapArray, 0);
    const heapCompareState = heapFrame ? {
      pathKeys: (heapFrame.visitedIndices || []).map((index) => `idx-${index}`),
      index: Math.max(0, (heapFrame.visitedIndices || []).length - 1),
      activeKeys: (heapFrame.activeIndices || []).map((index) => `idx-${index}`),
    } : treeOptions.compareState;
    html += "<h4>Representacion en arreglo</h4>";
    html += renderHeapArrayFrame(heapArray, heapFrame);
    if (heapFrame && heapFrame.note) {
      html += `<p class="viz-sim-note">${hEscape(heapFrame.note)}</p>`;
    }
    html += "<h4>Representacion en arbol</h4>";
    html += transitionData
      ? renderTreeTransitionSvg(transitionData, { ...treeOptions, compareState: heapCompareState })
      : drawTreeSvgFromNodes(flattenTree(heapRoot), { ...treeOptions, compareState: heapCompareState });
  } else {
    html += transitionData
      ? renderTreeTransitionSvg(transitionData, treeOptions)
      : drawTreeSvgFromNodes(flattenTree(state.root), treeOptions);
  }

  if (state.traversals) {
    html += "<div class=\"viz-traversals\">";
    Object.keys(state.traversals).forEach((name) => {
      html += `<p><strong>${hEscape(name)}:</strong> ${hEscape(JSON.stringify(state.traversals[name]))}</p>`;
    });
    const lastResult = formatHierResult(lastExecution);
    if (lastResult) {
      html += lastResult;
    }
    html += "</div>";
  }

  html += "</div>";
  container.innerHTML = html;
}

function showHierMessage(text, success) {
  const box = hById("message-box");
  if (!box) {
    return;
  }
  box.textContent = text || "";
  box.className = success ? "message ok" : "message error";
}

function updateHierDidacticPanel(model, operationName) {
  const recordBox = hById("tad-record");
  const pseudoTitle = hById("op-pseudocode-title");
  const pseudoBox = hById("op-pseudocode");
  if (!recordBox || !pseudoTitle || !pseudoBox) {
    return;
  }

  const didactic = model && model.didactic ? model.didactic : {};
  const opMap = didactic.operations || {};
  const fallback = didactic.default_operation || "Seudocodigo no disponible para esta operacion.";
  const selectedOp = operationName || "";
  const selectedMeta = (model.operations || []).find((item) => item.name === selectedOp);
  const selectedLabel = selectedMeta ? selectedMeta.label : selectedOp;

  recordBox.textContent = didactic.record || "Estructura no documentada.";
  pseudoTitle.textContent = selectedLabel ? `Seudocodigo: ${selectedLabel}` : "Seudocodigo";
  pseudoBox.textContent = opMap[selectedOp] || fallback;
}

function summarizeHierPayload(payload) {
  if (!payload || typeof payload !== "object") {
    return "";
  }
  const parts = Object.entries(payload)
    .filter(([, value]) => String(value).trim() !== "")
    .map(([key, value]) => `${key}=${value}`);
  return parts.join(", ");
}

function extractHierSubroutineName(pseudoCode, fallback) {
  if (!pseudoCode) {
    return fallback;
  }
  const firstLine = String(pseudoCode).split("\n").find((line) => String(line).trim()) || "";
  const match = firstLine.match(/(?:SubProceso|Funcion|Procedimiento|Proceso)\s+([A-Za-z_][A-Za-z0-9_]*)/i);
  if (match && match[1]) {
    return match[1];
  }
  return fallback;
}

function getHierSubroutineName(model, operationName, fallback) {
  const didactic = model && model.didactic ? model.didactic : {};
  const opMap = didactic.operations || {};
  const pseudoCode = opMap[operationName] || "";
  return extractHierSubroutineName(pseudoCode, fallback || operationName || "Operacion");
}

function createHierHistoryEntry(subroutine, payloadText, resultText) {
  return {
    subroutine: subroutine || "Operacion",
    payload: payloadText || "-",
    result: resultText || "-",
  };
}

function renderHierHistory(history, container) {
  if (!container) {
    return;
  }
  if (!history.length) {
    container.innerHTML = "<li class=\"didactic-history-item empty\">Sin acciones ejecutadas.</li>";
    return;
  }
  container.innerHTML = history.map((item, index) => {
    if (typeof item === "string") {
      return (
        "<li class=\"didactic-history-item\">" +
        `<div class="didactic-history-head">Paso ${index + 1}: Historial</div>` +
        `<div class="didactic-history-line"><span class="k">Salida:</span> ${hEscape(item)}</div>` +
        "</li>"
      );
    }
    return (
      "<li class=\"didactic-history-item\">" +
      `<div class="didactic-history-head">Paso ${index + 1}: ${hEscape(item.subroutine || "Operacion")}</div>` +
      `<div class="didactic-history-line"><span class="k">Entrada:</span> ${hEscape(item.payload || "-")}</div>` +
      `<div class="didactic-history-line"><span class="k">Salida:</span> ${hEscape(item.result || "-")}</div>` +
      "</li>"
    );
  }).join("");
}

function initHierPage(model) {
  const form = hById("operation-form");
  const operationSelect = hById("operation-select");
  const inputsContainer = hById("operation-inputs");
  const resetButton = hById("reset-button");
  const visualContainer = hById("visual-state");
  const historyBox = hById("action-history");

  if (!form || !operationSelect || !inputsContainer || !visualContainer) {
    return;
  }

  const pageState = {
    modelId: model.id,
    visualState: model.visual_state,
    lastExecution: null,
    compareState: null,
    rotationVisualHint: null,
    rotationTextHint: null,
    heapAnimation: {
      active: false,
      frame: null,
    },
    treeTransition: {
      active: false,
      data: null,
      rafId: null,
    },
  };

  const operations = model.operations || [];
  let selected = operations[0] || null;
  const operationLabel = new Map(operations.map((op) => [op.name, op.label]));
  const actionHistory = [];

  operations.forEach((operation) => {
    const option = document.createElement("option");
    option.value = operation.name;
    option.textContent = operation.label;
    operationSelect.appendChild(option);
  });

  buildOperationInputs(selected, inputsContainer);
  updateHierDidacticPanel(model, selected ? selected.name : "");
  (model.history || []).forEach((step) => {
    const opName = String(step.operation || "");
    const label = operationLabel.get(opName) || opName;
    const subroutine = getHierSubroutineName(model, opName, label);
    const payloadText = summarizeHierPayload(step.payload || {});
    actionHistory.push(createHierHistoryEntry(subroutine, payloadText || "-", "Operacion aplicada."));
  });
  renderHierHistory(actionHistory, historyBox);

  function stopTreeTransition() {
    if (pageState.treeTransition.rafId) {
      cancelAnimationFrame(pageState.treeTransition.rafId);
      pageState.treeTransition.rafId = null;
    }
    pageState.treeTransition.active = false;
    pageState.treeTransition.data = null;
  }

  function stopHeapAnimation() {
    pageState.heapAnimation.active = false;
    pageState.heapAnimation.frame = null;
  }

  function repaint() {
    const transitionData = pageState.treeTransition.active ? pageState.treeTransition.data : null;
    renderHierState(
      pageState.modelId,
      pageState.visualState,
      visualContainer,
      pageState.lastExecution,
      transitionData,
      pageState.compareState,
      pageState.rotationVisualHint,
      pageState.rotationTextHint,
      pageState.heapAnimation.active ? pageState.heapAnimation.frame : null,
    );
  }

  function startTreeTransition(previousRoot, nextRoot, rotationHint) {
    const transitionData = buildTransitionData(previousRoot, nextRoot);
    if (!transitionData) {
      return;
    }

    stopTreeTransition();
    pageState.treeTransition.active = true;
    pageState.treeTransition.data = transitionData;
    pageState.rotationVisualHint = rotationHint || null;

    const duration = 700;
    const startTs = performance.now();

    function tick(now) {
      if (!pageState.treeTransition.active || !pageState.treeTransition.data) {
        return;
      }

      const elapsed = now - startTs;
      const progress = Math.min(1, elapsed / duration);
      pageState.treeTransition.data.progress = progress;
      repaint();

      if (progress < 1) {
        pageState.treeTransition.rafId = requestAnimationFrame(tick);
      } else {
        stopTreeTransition();
        pageState.rotationVisualHint = null;
        repaint();
      }
    }

    pageState.treeTransition.rafId = requestAnimationFrame(tick);
  }

  function applyState(visualState, lastExecution) {
    const previousRoot = pageState.visualState ? pageState.visualState.root : null;
    const shouldAnimateRotations =
      (pageState.modelId === "avl" || pageState.modelId === "red_black")
      && lastExecution
      && (lastExecution.operation === "insertar" || lastExecution.operation === "eliminar");

    stopTreeTransition();
    stopHeapAnimation();

    pageState.visualState = visualState;
    pageState.lastExecution = lastExecution;
    pageState.compareState = null;
    pageState.rotationTextHint = lastExecution ? lastExecution.rotation_hint || null : null;
    pageState.rotationVisualHint = null;

    if (shouldAnimateRotations && previousRoot && visualState && visualState.root) {
      startTreeTransition(previousRoot, visualState.root, pageState.rotationTextHint);
    } else {
      repaint();
    }
  }

  async function animateComparison(pathKeys) {
    if (!pathKeys || !pathKeys.length) {
      return;
    }

    pageState.compareState = {
      pathKeys: [...pathKeys],
      index: -1,
    };
    repaint();

    for (let index = 0; index < pathKeys.length; index += 1) {
      pageState.compareState.index = index;
      repaint();
      await sleep(380);
    }
  }

  async function animateHeapFrames(frames) {
    if (!frames || !frames.length) {
      return;
    }

    stopHeapAnimation();
    pageState.heapAnimation.active = true;

    for (let index = 0; index < frames.length; index += 1) {
      pageState.heapAnimation.frame = frames[index];
      repaint();
      await sleep(340);
    }

    await sleep(120);
    stopHeapAnimation();
    repaint();
  }

  repaint();

  operationSelect.addEventListener("change", () => {
    selected = operations.find((op) => op.name === operationSelect.value) || null;
    buildOperationInputs(selected, inputsContainer);
    updateHierDidacticPanel(model, selected ? selected.name : "");
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const current = operations.find((op) => op.name === operationSelect.value);
    if (!current) {
      showHierMessage("Debes seleccionar una operacion valida.", false);
      return;
    }

    const payload = {};
    current.inputs.forEach((field) => {
      const element = hById(`h-field-${field.name}`);
      payload[field.name] = element ? element.value : "";
    });

    let comparePath = [];
    let rotationHint = null;
    let heapFrames = [];
    if (
      isSearchLikeStructure(pageState.modelId)
      && (current.name === "insertar" || current.name === "eliminar" || current.name === "buscar")
    ) {
      const targetValue = normalizeCompareValue(payload.value);
      if (targetValue !== null) {
        const compareResult = buildComparisonPath(pageState.visualState.root, targetValue);
        comparePath = compareResult.pathKeys;
        if (pageState.modelId === "avl" && current.name === "insertar") {
          rotationHint = inferAvlInsertionRotation(pageState.visualState.root, targetValue);
        }
        if (pageState.modelId === "avl" && current.name === "eliminar") {
          rotationHint = inferAvlDeletionRotation(pageState.visualState.root, targetValue);
        }
      }
    }
    if (pageState.modelId === "binary_heap") {
      heapFrames = buildHeapOperationFrames(
        current.name,
        payload,
        pageState.visualState && Array.isArray(pageState.visualState.array)
          ? pageState.visualState.array
          : [],
      );
    }

    const response = await fetch(form.dataset.operateUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ operation: current.name, payload }),
    });
    const data = await response.json();
    showHierMessage(data.message, Boolean(data.success));
    updateHierDidacticPanel(model, current.name);
    const payloadText = summarizeHierPayload(payload);
    const subroutine = getHierSubroutineName(model, current.name, current.label);
    actionHistory.push(createHierHistoryEntry(subroutine, payloadText || "-", data.message));
    renderHierHistory(actionHistory, historyBox);
    if (data.visual_state) {
      const effectiveRotationHint = data.success ? rotationHint : null;
      const execution = {
        operation: current.name,
        result: data.result,
        rotation_hint: effectiveRotationHint,
      };
      if (comparePath.length) {
        await animateComparison(comparePath);
      }
      if (data.success && heapFrames.length) {
        await animateHeapFrames(heapFrames);
      }
      applyState(data.visual_state, execution);
    }
  });

  resetButton?.addEventListener("click", async () => {
    stopTreeTransition();
    stopHeapAnimation();
    const response = await fetch(form.dataset.resetUrl, { method: "POST" });
    const data = await response.json();
    showHierMessage(data.message, Boolean(data.success));
    updateHierDidacticPanel(model, selected ? selected.name : "");
    actionHistory.length = 0;
    renderHierHistory(actionHistory, historyBox);
    if (data.visual_state) {
      applyState(data.visual_state, null);
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  if (window.HIER_VIEW_MODEL) {
    initHierPage(window.HIER_VIEW_MODEL);
  }
});
