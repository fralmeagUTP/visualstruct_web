﻿"""Adapter for the priority queue TAD."""

from __future__ import annotations

from typing import Any

from app.adapters.base_adapter import BaseAdapter
from app.domain.sequential import ColaPrioridad


class PriorityQueueAdapter(BaseAdapter):
    """Adapt `ColaPrioridad` to the generic adapter contract."""

    def __init__(self) -> None:
        self._structure: ColaPrioridad[int] | None = None
        self.create()

    def create(self) -> None:
        self._structure = ColaPrioridad()

    def execute(self, operation_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        if operation_name == "encolar":
            valor = self._require_int(payload, "value", "valor")
            prioridad = self._require_int(payload, "priority", "prioridad")
            self._structure.encolar(valor, prioridad)
            return {
                "message": (
                    f"Se encolÃ³ '{valor}' con prioridad {prioridad} "
                    "(menor nÃºmero = mayor prioridad)."
                )
            }
        if operation_name == "desencolar":
            valor = self._structure.desencolar()
            return {
                "message": f"Se atendiÃ³ '{valor}' desde la cola de prioridad.",
                "result": valor,
            }
        if operation_name == "frente":
            valor = self._structure.frente()
            return {"message": f"El frente actual es '{valor}'.", "result": valor}
        if operation_name == "limpiar":
            self._structure.limpiar()
            return {"message": "La cola de prioridad se limpiÃ³ correctamente."}
        raise ValueError(f"OperaciÃ³n no soportada: {operation_name}.")

    def to_visual_state(self) -> dict[str, Any]:
        items = self._structure.a_lista()
        return {
            "kind": "priority",
            "title": "Cola de prioridad (orden interno del heap)",
            "items": [{"value": value, "priority": priority} for value, priority in items],
            "size": self._structure.tamano(),
            "empty": self._structure.vacia(),
        }

    def reset(self) -> None:
        self._structure.limpiar()

    def get_supported_operations(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "encolar",
                "label": "Encolar",
                "mutates": True,
                "inputs": [
                    {"name": "value", "label": "Valor", "type": "number"},
                    {"name": "priority", "label": "Prioridad", "type": "number"},
                ],
            },
            {"name": "desencolar", "label": "Desencolar", "mutates": True, "inputs": []},
            {"name": "frente", "label": "Ver frente", "mutates": False, "inputs": []},
            {"name": "limpiar", "label": "Limpiar", "mutates": True, "inputs": []},
        ]

