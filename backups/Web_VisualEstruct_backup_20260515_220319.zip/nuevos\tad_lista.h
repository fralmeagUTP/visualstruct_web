#ifndef TAD_LISTA_H
#define TAD_LISTA_H

/**
 * @file tad_lista.h
 * @brief TAD Lista simplemente enlazada de enteros.
 */

/** @brief Nodo de la lista enlazada. */
typedef struct NodoLista {
    int nro;                    /**< Valor almacenado. */
    struct NodoLista *sgte;     /**< Nodo siguiente. */
} *Tlista;

/**
 * @brief Inserta al inicio.
 * @param[in,out] lista Lista destino.
 * @param[in] valor Valor a insertar.
 */
void lista_insertar_inicio(Tlista *lista, int valor);

/**
 * @brief Inserta al final.
 * @param[in,out] lista Lista destino.
 * @param[in] valor Valor a insertar.
 */
void lista_insertar_final(Tlista *lista, int valor);

/**
 * @brief Solicita al usuario insercion antes o despues de una posicion.
 * @return -1 para antes, 0 para despues.
 */
int lista_insertar_antes_despues(void);

/**
 * @brief Inserta en una posicion relativa.
 * @param[in,out] lista Lista destino.
 * @param[in] valor Valor a insertar.
 * @param[in] pos Posicion base.
 */
void lista_insertar_elemento(Tlista *lista, int valor, int pos);

/**
 * @brief Busca e imprime posiciones de un valor.
 * @param[in] lista Lista origen.
 * @param[in] valor Valor buscado.
 */
void lista_buscar_elemento(Tlista lista, int valor);

/**
 * @brief Imprime todos los elementos de la lista.
 * @param[in] lista Lista a mostrar.
 */
void lista_mostrar(Tlista lista);

/**
 * @brief Elimina la primera ocurrencia de un valor.
 * @param[in,out] lista Lista origen.
 * @param[in] valor Valor a eliminar.
 */
void lista_eliminar_elemento(Tlista *lista, int valor);

/**
 * @brief Elimina todas las ocurrencias de un valor.
 * @param[in,out] lista Lista origen.
 * @param[in] valor Valor a eliminar.
 */
void lista_eliminar_repetidos(Tlista *lista, int valor);

#endif
